# -*- coding: utf-8 -*-

"""
author: Rodrigo Medinilla
company: PipelinePro Software S.L.
date: 2023/08/09
"""

from PyQt5.QtWidgets import QApplication
import sys
import os
# from setproctitle import setproctitle
import threading

from src.kraken import Kraken
from src.install.update_kraken import ckeck_version, update_kraken_version

if __name__ == "__main__":

    #nombramos el proceso
    # setproctitle('Kraken')

    os.environ['QTWEBENGINE_DISABLE_SANDBOX'] = '1'
    app = QApplication(sys.argv)

    # Inicializa y muestra la ventana Kraken
    kraken = Kraken()
    if ckeck_version(kraken.version):
        try:
            update_kraken_version(kraken)
        except Exception as e:
            print(f"Error al actualizar Kraken: {e}")
        kraken.ui.show()
        sys.exit(app.exec_())
    else:
        kraken.ui.show()

        # Ejecuta la aplicación principal
        sys.exit(app.exec_())