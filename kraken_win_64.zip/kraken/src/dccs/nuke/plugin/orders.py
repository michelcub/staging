# -*- coding: utf-8 -*-

import nuke
import json
import threading
import ast


def on_message(ws_client, message):
    try:
        #print(f"Received message: {message}")
        message = ast.literal_eval(message)
        #print('aqui--------------------', message)
        dcc = message['dcc']
        command = message['command']
        action = ''
        if 'action' in message:
            action = message['action']
        if dcc == 'nuke':

            nuke.tprint("Received command for Nuke, starting thread to execute...")
            nuke.executeInMainThreadWithResult(execute_command_in_main_thread, command)

        elif dcc == 'hiero' and ws_client.is_hiero_connected or dcc == 'nuke_studio':
            import hiero
            #print(ws_client.is_hiero_connected)
            #print(ws_client.is_nuke_connected)
            global result
            result = []
            print('aqui el action-----',action)
            hiero.core.executeInMainThreadWithResult(execute, command, ws_client, action)
            print('aqui el result-----')
            # hilo = threading.Thread(target=execute, args=(command, ws_client, action))
            # hilo.start()
            # hilo.join()
    except Exception as e:
        pass

# Suponiendo que tengas configurado un cliente WebSocket para usar esta función

def execute(command, ws_client, action=''):
    nuke.tprint("Attempting to execute command...")
    try:
        # Es importante usar exec en el contexto global para que afecte a la instancia de Nuke actual.
        exec(command, globals())
        if 'result' in globals():
            global result
            print('aqui el global result-----', globals()['result'])
            print('aqui el result-----',result)
            print('aqui el action-----',action)

            if action != '':
                print('aqui el action-----',action)
                ws_client.send_message(json.dumps({
                    'order': 'command_result',
                    'tracks': result,
                    'dcc': 'kraken',
                    'action': action,
                }))
        nuke.tprint('Command executed successfully.')
    except Exception as e:
        #nuke.tprint(f'Error executing command: {e}')
        pass


def execute_command_in_main_thread(command):
    exec(command)





