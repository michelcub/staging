# -*- coding: utf-8 -*-
"""
authors: Michel
company: PipelinePro Software S.L.
date: 2023/08/12
"""
import json
import threading
import ast
import importlib
import time
import sys
import orders as nuke_orders
import uuid

class WebSocketClient:

    def __init__(self, uri="ws://localhost:18765", websocket_path=''):
        self.websocket_path = websocket_path
        #self.add_websocket_path()

        websockets_path = websocket_path
        sys.path.append(websockets_path)

        self.uri = uri
        self.ws = None
        self.websocket_path = websocket_path

        self.is_hiero_connected = False
        self.is_nuke_connected = False

        self.last_file_title = None
        self.file_title = None

        self.uuid = uuid.uuid4()

    def on_connect(self, ws):
        import nuke


        exec(script_get_name, globals())

        while not dcc:
            time.sleep(6)
            exec(script_get_name, globals())
        if dcc == 'hiero':
            self.is_hiero_connected = True
            self.is_nuke_connected = False
            self.dcc = 'hiero'
            file_title = nuke.root().name()
            #print("Nombre del proyecto actual en Nuke:", project_title)
            self.file_title = file_title.split('/')[-1]
            print("Connected with Hiero")
            message = {'type': 'register', 'dcc': 'hiero', 'file': self.file_title, 'uuid': str(self.uuid)}
            try:
                ws.send(message)
            except:
                ws.send(json.dumps(message))
            hiero.core.events.registerInterest("kAfterProjectLoad", self.on_project_load)
        if dcc == 'NukeStudio':
            self.dcc = 'nuke s'
            self.is_hiero_connected = True
            self.is_nuke_connected = False
            file_title = nuke.root().name()
            #print("Nombre del proyecto actual en Nuke:", project_title)
            self.file_title = file_title.split('/')[-1]
            print("Connected with NukeStudio")
            message = {'type': 'register', 'dcc': 'nuke s', 'file': self.file_title, 'uuid': str(self.uuid)}
            try:
                ws.send(message)
            except:
                ws.send(json.dumps(message))
            hiero.core.events.registerInterest("kAfterProjectLoad", self.on_project_load)

        elif dcc == 'nuke':
            self.dcc = 'nuke'
            self.is_hiero_connected = False
            self.is_nuke_connected = True
            print("Connected with Nuke")
            file_title = nuke.root().name()
            self.file_title = file_title.split('/')[-1]

            message = {'type': 'register', 'dcc': 'nuke', 'file': self.file_title, 'uuid': str(self.uuid)}
            try:
                ws.send(message)
            except:
                ws.send(json.dumps(message))
            nuke.addOnScriptLoad(self.on_script_load)
        #try:
            #import hiero
            #hiero.core.pluginPath()
            #self.is_hiero_connected = True
            #self.is_nuke_connected = False
            #print("Conectado al servidor WebSocket como Hiero")
            #ws.send('type|hiero')
        #except Exception as e:
            #self.is_hiero_connected = False
            #self.is_nuke_connected = True
            #print("Conectado al servidor WebSocket como Nuke")
            #ws.send('type|nuke')

    def on_disconnect(self, ws, close_status_code, close_msg):
        print("Desconectado del servidor WebSocket")

    def on_message(self, ws, message):
        if not self.check_order_by_file(message):
            return

        if self.is_nuke_connected:
            self.get_proyect_name_nuke(message, ws)
        else:
            self.get_proyect_name(message, ws)
        importlib.reload(nuke_orders)

        nuke_orders.on_message(self, message)

    def check_order_by_file(self, message):
        message_parsed = json.loads(message)
        if 'uuid' in message_parsed:
            if str(message_parsed['uuid']) == '':
                return True
            elif str(message_parsed['uuid']) != str(self.uuid):
                # print("El archivo no coincide")
                return False
        return True



    def run(self):
        import websocket
        import websocket
        while True:
            try:
                self.ws = websocket.WebSocketApp(self.uri,
                                                 on_open=self.on_connect,
                                                 on_close=self.on_disconnect,
                                                 on_message=self.on_message)
                self.ws.run_forever()
            except Exception as e:
                pass
                #print(f"Error en la conexión WebSocket: {e}")
            print("Intentando reconectar en 5 segundos...")
            time.sleep(5)

    def on_script_load(self):
        import nuke
        # Obtener el nombre del proyecto actualmente abierto en Nuke
        file_title = nuke.root().name()
        file_title = file_title.split('/')[-1]

        if file_title and file_title != "Root" and file_title != self.file_title:
            self.last_file_title = self.file_title
            self.file_title = file_title.split('/')[-1]
            # Imprimir el nombre del proyecto
            #print("Nuevo proyecto cargado en Nuke:", project_title)
        # Enviar el nombre del proyecto al servidor WebSocket
            self.send_message(json.dumps({'type': 'register', 'dcc': 'nuke', 'file': self.file_title, 'last_file': self.last_file_title, 'uuid': str(self.uuid)}))

    def get_proyect_name(self, message, ws):
        import hiero.core
        parsed_message = json.loads(message)
        if 'order' in parsed_message:
            if parsed_message['order'] == 'get_task_by_dcc':
                route = hiero.core.projects()[0].path()
                file_title = route.replace("\\", "/").split('/')[-1]
                self.last_file_title = self.file_title
                self.file_title = file_title

                result = {'type': 'file', 'dcc': self.dcc, 'file': self.file_title, 'last_file': self.last_file_title, 'uuid': str(self.uuid)}
                ws.send(json.dumps(result))
                return

    def get_proyect_name_nuke(self, message, ws):
        import nuke
        parsed_message = json.loads(message)
        if 'order' in parsed_message:
            if parsed_message['order'] == 'get_task_by_dcc':
                route = nuke.root().name()
                file_title = route.replace("\\", "/").split('/')[-1]
                self.last_file_title = self.file_title
                self.file_title = file_title

                result = {'type': 'file', 'dcc': self.dcc, 'file': self.file_title, 'last_file': self.last_file_title, 'uuid': str(self.uuid)}
                ws.send(json.dumps(result))
                return





    def send_message(self, message):
        if self.ws:
            self.ws.send(message)
            #print(f"Enviado: {message}")
        else:
            print("No se ha establecido una conexión WebSocket")

def start_websocket_client(websocket_path):
    uri = "ws://localhost:18765"  # Cambia esto por la dirección de tu servidor WebSocket
    client = WebSocketClient(uri, websocket_path)
    client.run()

def main(websocket_path):
    if not hasattr(sys.modules[__name__], 'client_thread'):
        # Crear un subproceso para ejecutar el cliente WebSocket
        client_thread = threading.Thread(target=start_websocket_client, args=(websocket_path,))
        client_thread.daemon = True  # Establecer el subproceso como daemon

        # Guardar el subproceso en el módulo para mantener el estado
        sys.modules[__name__].client_thread = client_thread

        # Iniciar el subproceso del cliente WebSocket
        client_thread.start()
    else:
        pass






script_get_name = """
from PySide2 import QtWidgets

app = QtWidgets.QApplication.instance()

# Buscar todas las ventanas principales (debería haber solo una en la aplicación)
main_windows = [window for window in app.topLevelWidgets() if isinstance(window, QtWidgets.QMainWindow)]

# Suponiendo que solo hay una ventana principal, obtener su título
window_title = main_windows[0].windowTitle() if main_windows else "No main window found"

# Ahora puedes imprimir o comprobar el título
#print(window_title)
dcc = None
# Para determinar si estás en Hiero o Nuke, puedes buscar en el título
if "NukeStudio" in window_title:
    dcc = 'NukeStudio'
elif "Hiero" in window_title:
    dcc = 'hiero'
elif "Nuke" in window_title:
    dcc = 'nuke'
else:
    pass

"""

