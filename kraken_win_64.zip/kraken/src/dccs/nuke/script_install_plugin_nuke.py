# -*- coding: utf-8 -*-

import os

# from src.dccs.install_plugins import remove_content_between_markers
from src.libraries.file_basic import remove_content_between_markers

def remove_content_between_markers(file_path, start_marker="# _______________ PipelinePro Setup ___", end_marker="# _______________ end setting ___"):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.readlines()
        new_content = ''
        borrando = False
        for i, line in enumerate(content):
            if start_marker in line:
                borrando = True
            elif end_marker in line and borrando:
                borrando = False
            if not borrando:
                new_content = new_content + line
                print(new_content)

        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(new_content)
        print("Contenido reemplazado exitosamente.")

    except Exception as e:
        print(f"Ocurrió un error: {e}")

def agregar_plugin_a_nuke_auto(ruta_plugin, nombre_archivo_plugin):
    # Directorio de configuración de Nuke para el usuario actual
    nuke_dir = os.path.join(os.path.expanduser('~'), '.nuke')
    hiero_dir = os.path.join(os.path.expanduser('~'), '.nuke', 'Python', 'StartupUI').replace("\\", "/")
    root_kraken = os.path.dirname(os.getcwd())
    directorio_packages = os.path.join(root_kraken, 'venv_kraken', 'Lib', 'site-packages').replace("\\", "/")

    # Asegurarse de que el directorio .nuke existe
    if not os.path.exists(nuke_dir):
        os.makedirs(nuke_dir)
    #Asegurarse de que el directorio .nuke/Python/StartupUI existe
    if not os.path.exists(hiero_dir):
        os.makedirs(hiero_dir)

    # ================== NUKE
    init_nuke_py = os.path.join(nuke_dir, 'init.py')
    remove_content_between_markers(init_nuke_py)  # Limpia la configuracion previa
    with open(init_nuke_py, "a+") as file:
        file.seek(0)
        file.write("\n")
        file.write("# _______________ PipelinePro Setup ___")
        file.write("\n")
        file.write("try:\n")
        file.write("    import nuke\n")
        file.write(f"    nuke.pluginAddPath('{ruta_plugin}')\n")
        file.write("except:\n")
        file.write("    import hiero.core\n")
        file.write("    hiero.core.addPluginPath('{ruta_plugin}')\n")

        file.write("try:\n")
        file.write(f"    import {nombre_archivo_plugin}\n")
        file.write(f"    {nombre_archivo_plugin}.main('{directorio_packages}')\n")
        file.write("except:\n")
        file.write("    pass\n")
        file.write("# _______________ end setting ___")
    # ========================

    # ================== HIERO
    init_hiero_py = os.path.join(hiero_dir, 'init.py')
    remove_content_between_markers(init_hiero_py)  # Limpia la configuracion previa
    with open(init_hiero_py, "a+") as file:
        file.seek(0)
        file.write("\n")
        file.write("# _______________ PipelinePro Setup ___")
        file.write("\n")
        file.write("try:\n")
        file.write("    import nuke\n")
        file.write(f"    nuke.pluginAddPath('{ruta_plugin}')\n")
        file.write("except:\n")
        file.write("    import hiero.core\n")
        file.write("    hiero.core.addPluginPath('{ruta_plugin}')\n")

        file.write("try:\n")
        file.write(f"    import {nombre_archivo_plugin}\n")
        file.write(f"    {nombre_archivo_plugin}.main('{directorio_packages}')\n")
        file.write("except:\n")
        file.write("    pass\n")
        file.write("# _______________ end setting ___")
    # ========================


# Uso del script
# directorio_actual = os.getcwd()
# addon_path = os.path.join(directorio_actual, 'src', 'dccs', 'nuke', 'plugin').replace('\\', '/')
# nombre_archivo_plugin = 'pipelinepro_connector'  # Sin la extensión .py
#
# agregar_plugin_a_nuke_auto(addon_path, nombre_archivo_plugin)
