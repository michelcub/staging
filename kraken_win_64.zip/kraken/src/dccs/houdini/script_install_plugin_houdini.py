# -*- coding: utf-8 -*-

import os

from src.dccs.install_plugins import remove_content_between_markers

def find_directory(env_file_name, script_directory):
    print('Buscando directorio de instalacion de Houdini')
    home_directory = os.path.expanduser('~')
    if os.name == 'nt':  # Windows
        config_directory = f"{home_directory}\\Documents\\"
        list_files = os.listdir(config_directory)
        houdini_folder = None
        for file in list_files:
            if file.startswith('houdini'):
                houdini_folder = file
                break
        if houdini_folder:
            config_directory = f"{home_directory}\\Documents\\{houdini_folder}\\scripts\\"
            edit_or_create(config_directory, env_file_name, script_directory)

    elif os.name == 'posix':  # macOS y Linux
        config_directory = f"{home_directory}/"
        list_files = os.listdir(config_directory)
        houdini_folder = None
        for file in list_files:
            if file.startswith('houdini'):
                houdini_folder = file
                break
        if houdini_folder:
            config_directory = f"{home_directory}/{houdini_folder}/scripts/"
            edit_or_create(config_directory, env_file_name, script_directory)



def edit_or_create(config_directory, file_name, script_directory):
    # ruta al fichero de arranque de houdini
    file_path = os.path.join(config_directory, file_name)
    directorio_actual = os.getcwd()
    root_kraken = os.path.dirname(directorio_actual)
    print(root_kraken)
    directorio_packages = os.path.join(root_kraken, 'venv_kraken', 'Lib', 'site-packages').replace("\\", "/")

    # Comprobar si el archivo  existe, crearlo si no
    if not os.path.exists(file_path):
        open(file_path, 'w').close()
    remove_content_between_markers(file_path)  # Limpia la configuracion previa

    # Añadir o modificar la variable de entorno
    with open(file_path, "a") as file:
        file.write("\n")
        file.write("# _______________ PipelinePro Setup ___")
        file.write("\nimport sys\n")
        file.write("try:\n")
        file.write(f"    sys.path.insert(0,'{script_directory}')\n")
        file.write(f"    import pipelinepro_connector\n")
        file.write(f"    pipelinepro_connector.main('{directorio_packages}')\n")
        file.write("except:\n")
        file.write("    pass\n")
        file.write("# _______________ end setting ___")

    pipelinepro_connector = os.path.join(script_directory, 'pipelinepro_connector.py')
    with open(pipelinepro_connector, 'r') as file:
        lines = file.readlines()

    # Modificar las primeras tres líneas
    lines[0:3] = ["import sys\n", f"sys.path.insert(0,'{script_directory}')\n", "import orders\n"]

    # Reescribir el archivo con las líneas modificadas
    with open(pipelinepro_connector, 'w') as file:
        file.writelines(lines)

    print(f"Agregado inicializacion del script al arranque de houdini en : {file_name}")


def install_plugin():
    print('Instalando plugin en Houdini')
    directorio_actual = os.getcwd()
    script_directory = os.path.join(directorio_actual, 'src', 'dccs', 'houdini', 'plugin').replace("\\","/")

    env_file_name = "123.py"

    find_directory(env_file_name, script_directory)
    print('Instalacion completada')


install_plugin()