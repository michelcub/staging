import hou
import json
import threading
import ast


def on_message(message):
    try:
        message = ast.literal_eval(message)
        dcc = message['dcc']
        if dcc == 'houdini':
            comando = message['command']
            #print('Comando recibido:', comando)

            exec(comando, globals())
    except Exception as e:
        pass
