import sys
sys.path.insert(0,'C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Kraken/kraken/src/dccs/unreal/plugin')
import orders

# -*- coding: utf-8 -*-
"""
authors: Michel
company: PipelinePro Software S.L.
date: 2023/08/12
"""

import unreal

import time
import sys
import importlib

# Agrega la ruta al directorio que contiene la librería websockets a sys.path
import queue
import threading
#import websocket
import importlib





import threading

class WebSocketClient:
    def __init__(self, uri="ws://localhost:18765", websocket_path=''):
        self.uri = uri
        self.ws = None
        self.websocket_path = websocket_path
        websockets_path = websocket_path
        sys.path.append(websockets_path)

        self.command_queue = queue.Queue()


    def on_connect(self, ws):
        print("Conectado al servidor WebSocket")
        ws.send('type|unreal')


    def on_disconnect(self, ws, close_status_code, close_msg):
        print("Desconectado del servidor WebSocket")

    def on_message(self, ws, message):
        #print(f"Respuesta del servidor: {message}")
        #importlib.reload(orders)
        #orders.on_message(message)
        self.command_queue.put(message)
    def run(self):
        import websocket
        while True:
            try:
                self.ws = websocket.WebSocketApp(self.uri,
                                                 on_open=self.on_connect,
                                                 on_close=self.on_disconnect,
                                                 on_message=self.on_message)
                self.ws.run_forever()
            except Exception as e:
                print(f"Error en la conexión WebSocket: {e}")
            print("Intentando reconectar en 5 segundos...")
            time.sleep(5)

    def send_message(self, message):
        if self.ws:
            self.ws.send(message)
            # print(f"Enviado: {message}")
        else:
            print("No se ha establecido una conexión WebSocket")

def start_websocket_client(websocket_path, command_queue):
    uri = "ws://localhost:18765"
    client = WebSocketClient(uri, websocket_path)
    client.command_queue = command_queue
    client.run()

def main(websocket_path):
    command_queue = queue.Queue()

    client_thread = threading.Thread(target=start_websocket_client, args=(websocket_path, command_queue))
    client_thread.daemon = True
    client_thread.start()

    while True:
        try:
            command = command_queue.get_nowait()
            importlib.reload(orders)
            orders.on_message(command)
        except queue.Empty:  # Cambiar 'Queue.Empty' por 'queue.Empty'
            # Aquí puedes hacer otras tareas, o simplemente pasar
            pass




