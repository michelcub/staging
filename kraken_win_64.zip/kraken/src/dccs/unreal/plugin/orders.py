
import json
import ast


def on_message(message):
    try:
        print(type(message))
        message = ast.literal_eval(message)
        dcc = message['dcc']
        if dcc == 'unreal':
            print('Mensaje recibido para unreal')
            comando = message['command']
            print('Comando recibido:', comando)
            # Programa el comando para que se ejecute en el hilo principal
            #hay que crear una funcion en blueprint que ejecute el comando
            #exec(comando, globals())
    except Exception as e:
        print(f'Error al procesar el mensaje: {e}')

