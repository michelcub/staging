import bpy
import addon_utils
import subprocess
import os
import zipfile
# Nombre del módulo del add-on tal como aparece en el archivo __init__.py en el diccionario bl_info

addon_name = 'blender_connector'


def remove_content_between_markers(file_path, start_marker="# _______________ PipelinePro Setup ___", end_marker="# _______________ end setting ___"):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.readlines()
        new_content = ''
        borrando = False
        for i, line in enumerate(content):
            if start_marker in line:
                borrando = True
            elif end_marker in line and borrando:
                borrando = False
            if not borrando:
                new_content = new_content + line
                print(new_content)

        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(new_content)
        print("Contenido reemplazado exitosamente.")

    except Exception as e:
        print(f"Ocurrió un error: {e}")



# Ruta al archivo del add-on. Esta debe ser la ruta completa o relativa desde el directorio actual donde se ejecuta Blender

directorio_actual = os.getcwd()
ruta_addon_py = os.path.join(directorio_actual, 'src', 'dccs', 'blender',  'plugin', 'blender_connector.py')
ruta_pipeline_connector = os.path.join(os.getcwd(), 'src', 'dccs', 'blender',  'plugin').replace("\\", "/")
root_kraken = os.path.dirname(directorio_actual)
print(ruta_addon_py)
print(root_kraken)
directorio_packages = os.path.join(root_kraken, 'venv_kraken', 'Lib', 'site-packages').replace("\\", "/")

try:
    # Leer las líneas del archivo
    with open(ruta_addon_py, 'r') as file:
        lineas = file.readlines()

    # Extender la lista de líneas si es más corta de lo necesario
    while len(lineas) < 20:
        lineas.append("")

    # remove_content_between_markers(ruta_addon_py)  # Limpia la configuracion previa
    # # Reemplazar (o añadir) las líneas
    # lineas[10] = "\n"
    # lineas[11] = "# _______________ PipelinePro Setup ___"
    # lineas[12] = "\n"
    # lineas[12] = "import sys\n"
    # lineas[13] = "try:\n"
    # lineas[14] = f"    sys.path.insert(0, '{directorio_packages}')\n"
    # lineas[15] = f"    sys.path.insert(0, '{ruta_pipeline_connector}')\n"
    # lineas[16] = "    import pipelinepro_connector\n"
    # lineas[17] = "except:\n"
    # lineas[18] = "    pass\n"
    #
    # lineas[19] = "def register():\n"
    # lineas[20] = "    pipelinepro_connector.main()\n"
    # lineas[21] = "def unregister():\n"
    # lineas[22] = "    pass\n"
    # lineas[23] = "if __name__ == '__main__':\n"
    # lineas[24] = "    register()\n"
    # lineas[25] = "# _______________ end setting ___"
    # # Reescribir el archivo con las líneas modificadas
    #
    # with open(ruta_addon_py, 'w') as file:
    #     file.writelines(lineas)

    # ================== NUKE
    remove_content_between_markers(ruta_addon_py)  # Limpia la configuracion previa
    with open(ruta_addon_py, "a+") as file:
        file.seek(0)
        file.write("\n")
        file.write("# _______________ PipelinePro Setup ___")
        file.write("\n")
        file.write("import sys\n")
        file.write("try:\n")
        file.write(f"    sys.path.insert(0, '{directorio_packages}')\n")
        file.write(f"    sys.path.insert(0, '{ruta_pipeline_connector}')\n")
        file.write("    import pipelinepro_connector\n")
        file.write("except:\n")
        file.write("    pass\n")

        file.write("def register():\n")
        file.write("    pipelinepro_connector.main()\n")
        file.write("def unregister():\n")
        file.write("    pass\n")
        file.write("if __name__ == '__main__':\n")
        file.write("    register()\n")
        file.write("# _______________ end setting ___")
    # ========================


except IOError as e:
    print(f"Error al abrir o escribir en el archivo: {e}")



#crear el zip para instalar
addon_path = os.path.join(directorio_actual, 'src', 'dccs', 'blender',  'plugin', 'blender_connector.zip')

if os.path.exists(addon_path):
    os.remove(addon_path)
    print('zip antiguo eliminado')

with zipfile.ZipFile(addon_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipf.write(ruta_addon_py, os.path.basename(ruta_addon_py))



print('contenido : ', addon_path)
print('directorio_actual', directorio_actual)

def desactive_addon():
    # Desactivar el add-on si ya está instalado y activado
    addon_utils.disable(addon_name, default_set=True)

def install_addon():
    # Instalar el add-on
    bpy.ops.preferences.addon_install(overwrite=True, filepath=addon_path)

def active_new_addon():
    # Activar el add-on
    bpy.ops.preferences.addon_enable(module=addon_name)

def save_change():
    # Guardar las preferencias del usuario para mantener el add-on activo después de cerrar Blender
    bpy.ops.wm.save_userpref()

def open_blender():
    ruta_escritorio = os.path.join(os.path.expanduser("~"), "Desktop")

    # Buscar en el escritorio
    for archivo in os.listdir(ruta_escritorio):
        if archivo.endswith(".lnk") and 'blender' in archivo:
            # Construir la ruta completa al archivo de acceso directo
            ruta_acceso_directo = os.path.join(ruta_escritorio, archivo)
            subprocess.Popen([ruta_acceso_directo])
            
def install_new_addon():
    desactive_addon()
    install_addon()
    active_new_addon()
    save_change()
    #open_blender()
    
install_new_addon()