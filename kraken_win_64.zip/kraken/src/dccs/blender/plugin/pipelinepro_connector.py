import os
import sys
sys.path.insert(0, 'D:/workspace/kraken/venv_kraken/Lib/site-packages')
sys.path.insert(0, 'C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Kraken/venv_kraken/Lib/site-packages')
orders_root = os.path.join(os.getcwd(), 'src', 'dccs', 'blender',  'plugin')
sys.path.insert(0, orders_root)
import json
import bpy
import websocket
import threading
import time
import importlib
import orders as blender_orders
import uuid



# Agrega la ruta al directorio que contiene la librería websockets a sys.path
websockets_path = r'D:\workspace\kraken\venv_kraken\Lib\site-packages'
sys.path.append(websockets_path)




class WebSocketClient:
    def __init__(self, uri="ws://localhost:18765"):
        self.uri = uri
        self.ws = None
        self.last_file_title = None
        self.file_title = None
        self.uuid = uuid.uuid4()

    def on_connect(self, ws):
        #print("Connected to Manager")
        file_title = bpy.data.filepath
        self.file_title = file_title.replace("\\", "/").split('/')[-1]
        message = {'type': 'register', 'dcc': 'blender', 'file': self.file_title, 'uuid': str(self.uuid)}
        ws.send(json.dumps(message))
        bpy.app.handlers.load_post.append(self.imprimir_nombre_proyecto)

    def on_disconnect(self, ws, close_status_code, close_msg):
        print("Disconnected to Manager")

    def on_message(self, ws, message):
        if not self.check_order_by_file(message):
            return

        self.get_proyect_name(message, ws)

        importlib.reload(blender_orders)

        blender_orders.on_message(self, message)

    def check_order_by_file(self, message):
        message_parsed = json.loads(message)
        if 'uuid' in message_parsed:
            if str(message_parsed['uuid']) == '':
                return True
            elif str(message_parsed['uuid']) != str(self.uuid):
                # print("El archivo no coincide")
                return False
        return True

    def get_proyect_name(self, message, ws):
        message_parsed = json.loads(message)
        #print("message_parsed", message_parsed)
        if 'order' in message_parsed:
            if message_parsed['order'] == 'get_task_by_dcc':
                #print("get_task_by_dcc")
                file_title= bpy.path.basename(bpy.context.blend_data.filepath)
                #print("file_title_title", file_title)
                self.last_file_title = self.file_title
                self.file_title = file_title
                result = {'type': 'file', 'dcc': 'blender', 'file': self.file_title,
                          'last_file': self.last_file_title, 'uuid': str(self.uuid)}
                ws.send(json.dumps(result))
            return

    def imprimir_nombre_proyecto(self, scene):
        # Obtiene el nombre del archivo actualmente abierto en Blender
        file_title = bpy.path.basename(bpy.context.blend_data.filepath)
        if file_title != self.file_title:
            self.last_file_title = self.file_title
            self.file_title = file_title
            message = {'type': 'file', 'dcc': 'blender', 'file': file_title, 'last_file': self.last_file_title}
            self.send_message(json.dumps(message))
            #print("Proyecto actual:", project_title)


    def run(self):
        import websocket
        while True:
            try:
                self.ws = websocket.WebSocketApp(self.uri,
                                                 on_open=self.on_connect,
                                                 on_close=self.on_disconnect,
                                                 on_message=self.on_message)
                self.ws.run_forever()
            except Exception as e:
                print(f"Error en la conexión WebSocket: {e}")
            print("Intentando reconectar en 5 segundos...")
            time.sleep(5)

    def send_message(self, message):
        if self.ws:
            self.ws.send(message)
        else:
            print("No se ha establecido una conexión WebSocket")

def start_websocket_client():
    uri = "ws://localhost:18765"
    client = WebSocketClient(uri)
    client.run()

def main():
    client_thread = threading.Thread(target=start_websocket_client)
    client_thread.daemon = True
    client_thread.start()
    print('blender is connected')






if __name__ == "__main__":
    main()



