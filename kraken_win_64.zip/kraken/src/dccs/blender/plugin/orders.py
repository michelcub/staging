import bpy
import json

def execute_in_main_thread(command, ws_client, action=''):
    try:
        # Ejecutar el comando en el contexto adecuado
        exec(command, globals())

        if 'result' in globals():
            global result
            if "Get Assets" in action:
                ws_client.send_message(json.dumps({
                    'order': 'command_result',
                    'assets': 'Objects Selected: ' + str(len(result)),
                    'dcc': 'kraken',
                    'action': action,
                }))
    except Exception as e:
        pass
        #print(f"Error al ejecutar el comando: {e}")

def schedule_command_for_main_thread(comando, ws_client, action=''):
    # Envuelve la función y el comando en una lambda para retrasar la ejecución
    bpy.app.timers.register(lambda: execute_in_main_thread(comando, ws_client, action=action))

def on_message(ws_client, message):
    try:
        message = json.loads(message)
        dcc = message['dcc']
        if not 'action' in message:
            message['action'] = ''
        if dcc == 'blender':
            comando = message['command']
            #print('Comando recibido:', comando)

            schedule_command_for_main_thread(comando, ws_client, action=message['action'])

    except Exception as e:
        pass
        #print(f'Error al procesar el mensaje: {e}')
