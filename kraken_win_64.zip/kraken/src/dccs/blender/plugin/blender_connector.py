bl_info = {
    "name": "PipelinePro Addons",
    "author": "PipelinePro Software S.L.",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "description": "Blender Connector with PipelinePro Platform",
    "category": "Development"
}

# _______________ PipelinePro Setup ___
import sys
try:
    sys.path.insert(0, 'C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Kraken/venv_kraken/Lib/site-packages')
    sys.path.insert(0, 'C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Kraken/kraken/src/dccs/blender/plugin')
    import pipelinepro_connector
except:
    pass
def register():
    pipelinepro_connector.main()
def unregister():
    pass
if __name__ == '__main__':
    register()
# _______________ end setting ___