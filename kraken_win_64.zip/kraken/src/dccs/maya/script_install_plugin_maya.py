import os

from src.libraries.file_basic import remove_content_between_markers

directorio_actual = os.getcwd()
path_directory = os.path.join(directorio_actual, 'src', 'dccs', 'maya', 'plugin').replace("\\", "/")
root_kraken = os.path.dirname(directorio_actual)
directorio_packages = os.path.join(root_kraken, 'venv_kraken', 'Lib', 'site-packages').replace("\\", "/")


def find_folder_user_maya():
    user_folder = os.path.expanduser("~")
    maya_folder = os.path.join(user_folder, "Documents", "maya")
    maya_versions = []

    if os.path.exists(maya_folder):
        for item in os.listdir(maya_folder):
            version_path = os.path.join(maya_folder, item, "scripts")
            if os.path.isdir(version_path) and item.isdigit():
                maya_versions.append(version_path)

    return maya_versions


def edit_or_create_user_setup():
    maya_versions = find_folder_user_maya()
    for version_folder in maya_versions:
        user_setup = os.path.join(version_folder, "userSetup.py").replace("\\", "/")
        remove_content_between_markers(user_setup)  # Limpia la configuracion previa
        with open(user_setup, "a+") as file:
            file.seek(0)
            file.write("\n")
            file.write("# _______________ PipelinePro Setup ___")
            file.write("\n")
            file.write("import sys\n")
            file.write("try:\n")
            file.write(f"    sys.path.insert(0, '{path_directory}')\n")
            file.write("    import maya_pipelinepro\n")
            file.write("    import maya.cmds as cmds\n")
            file.write("    def main_wrapper():\n")
            file.write(f"        maya_pipelinepro.main('{directorio_packages}')\n")
            file.write(f'    cmds.scriptJob(event=["idle", main_wrapper], runOnce=True)\n')
            file.write("except:\n")
            file.write("    pass\n")
            file.write("# _______________ end setting ___")

# def install_plugin():
#     edit_or_create_user_setup()
    # print("UserSetup.py edited or created in all Maya versions.")


# if __name__ == "__main__":
#     install_plugin()
