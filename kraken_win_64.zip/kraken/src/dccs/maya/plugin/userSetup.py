import sys

sys.path.insert(0, 'D:/workspace/kraken/kraken/src/dccs/maya/plugin')

import maya_pipelinepro
import maya.cmds as cmds

import maya.cmds as cmds

cmds.scriptJob(event=["idle", maya_pipelinepro.main], runOnce=True)