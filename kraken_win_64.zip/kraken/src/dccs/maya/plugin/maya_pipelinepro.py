# -*- coding: utf-8 -*-

import threading
import json
import importlib
import time
import orders as maya_orders
import uuid

class WebSocketClient:
    def __init__(self, uri="ws://localhost:18765", websocket_path=''):
        self.websocket_path = websocket_path
        self.add_websocket_path()
        import websocket

        self.websocket = websocket
        self.uri = uri
        self.ws = None
        self.file_title = None
        self.last_file_title = None
        self.uuid = uuid.uuid4()

    def add_websocket_path(self):
        import sys
        websockets_path = self.websocket_path
        sys.path.insert(0, websockets_path)

    def on_connect(self, ws):
        print("Connected to Manager")
        import maya.cmds as cmds
        file_title = cmds.file(query=True, sceneName=True)
        self.file_title = file_title.replace("\\", "/").split('/')[-1]
        ws.send(json.dumps({'type': 'register', 'dcc': 'maya', 'file': self.file_title, 'uuid': str(self.uuid)}))


    def on_disconnect(self, ws, close_status_code, close_msg):
        print("Disconnected to Manager")

    def on_message(self, ws, message):
        #print("Message from Manager: ", message)
        if not self.check_order_by_file(message):
            return

        self.get_proyect_name(message, ws)
        importlib.reload(maya_orders)
        # if 'project' in message and message['project'] != self.project_title:
        #     return

        maya_orders.on_message(self, message)

    def check_order_by_file(self, message):
        try:
            message_parsed = json.loads(message)
        except json.JSONDecodeError:
            pass
        if 'uuid' in message_parsed:
            if str(message_parsed['uuid']) == '':
                return True
            elif str(message_parsed['uuid']) != str(self.uuid):
                #print("El archivo no coincide")
                return False
        return True


    def get_proyect_name(self, message, ws):
        message_parsed = json.loads(message)
        if 'order' in message_parsed:
            if message_parsed['order'] == 'get_task_by_dcc':
                import maya.cmds as cmds
                file_title = cmds.file(query=True, sceneName=True)
                self.last_file_title = self.file_title
                self.file_title = file_title.replace("\\", "/").split('/')[-1]
                if self.last_file_title == '':
                    self.last_file_title = self.file_title

                result = {'type': 'file', 'dcc': 'maya', 'file': self.file_title,
                          'last_file': self.last_file_title, 'uuid': str(self.uuid)}

                ws.send(json.dumps(result))
            return



    def run(self):
        #TODO: Creo que esta sobra
        import websocket
        while True:
            try:
                self.ws = websocket.WebSocketApp(self.uri,
                                                 on_open=self.on_connect,
                                                 on_close=self.on_disconnect,
                                                 on_message=self.on_message)
                self.ws.run_forever()
            except Exception as e:
                print(f"Error en la conexión WebSocket: {e}")
            print("Intentando reconectar en 5 segundos...")
            time.sleep(5)

    def send_message(self, message):
        if self.ws:
            self.ws.send(message)
        else:
            print("No se ha establecido una conexión WebSocket")

def start_websocket_client(websocket_path):
    uri = "ws://localhost:18765"  # Cambia esto por la dirección de tu servidor WebSocket
    client = WebSocketClient(uri,websocket_path)
    client.run()

def main(websocket_path):
    client_thread = threading.Thread(target=start_websocket_client, args=(websocket_path,))
    client_thread.daemon = True
    client_thread.start()


