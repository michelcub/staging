# -*- coding: utf-8 -*-

import json
import maya.utils

def on_message(ws_client, message):
    #print(f"Received message: {message}")
    try:
        message = json.loads(message)
        dcc = message['dcc']
        command = message['command']
        if not 'action' in message:
            message['action'] = ''
        if dcc == 'maya':
            # Definir 'result' en el ámbito global
            global result
            result = []
            maya.utils.executeInMainThreadWithResult(execute, command, ws_client, action=message['action'])
    except Exception as e:
        #print(f"Error: {e}")
        pass
def execute(command, ws_client, action=''):
    # Esta función será llamada en el hilo principal gracias a executeInMainThreadWithResult
    try:
        # Ejecutar el comando en el contexto adecuado
        exec(command, globals())

        # Imprimir el resultado si está definido en el ámbito global
        if 'result' in globals():
            global result
            if "Get Assets" in action:
                ws_client.send_message(json.dumps({
                    'order': 'command_result',
                    'assets': 'Objects Selected: ' + str(len(result)),
                    'dcc': 'kraken',
                    'action': action,
                }))
    except Exception as e:
        #print(f"Error al ejecutar el comando: {e}")
        pass
