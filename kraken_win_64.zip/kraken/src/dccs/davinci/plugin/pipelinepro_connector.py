import sys
sys.path.insert(0,'D:/workspace/kraken/kraken/src/dccs/davinci/plugin')
import orders

import json
import sys
import time
import orders
import threading
import importlib
import uuid

class WebSocketClient:
    def __init__(self, uri="ws://localhost:18765", websocket_path=''):
        self.uri = uri
        self.ws = None
        self.websocket_path = websocket_path
        websockets_path = websocket_path
        sys.path.append(websockets_path)
        self.file_title = None
        self.last_file_title = None
        self.uuid = uuid.uuid4()

    def on_connect(self, ws):
        print("Conectado al servidor WebSocket")

        # project_title = hou.hipFile.name()
        # self.project_title = project_title.replace("\\", "/").split('/')[-1]
        # #print(f"Proyecto: {self.project_title}")
        ws.send(json.dumps({'type': 'register', 'dcc': 'davinci', 'file': 'test', 'uuid': self.uuid}))


    def on_disconnect(self, ws, close_status_code, close_msg):
        print("Desconectado del servidor WebSocket")

    def on_message(self, ws, message):
        #print(f"Respuesta del servidor: {message}")
        self.check_order_by_file(message)
        # self.get_proyect_name(message, ws)
        importlib.reload(orders)
        orders.on_message(message)

    def check_order_by_file(self, message):
        message_parsed = json.loads(message)
        if 'uuid' in message_parsed:
            if str(message_parsed['uuid']) == '':
                return True
            elif str(message_parsed['uuid']) != str(self.uuid):
                # print("El archivo no coincide")
                return False
        return True

    def run(self):
        import websocket
        while True:
            try:
                self.ws = websocket.WebSocketApp(self.uri,
                                                 on_open=self.on_connect,
                                                 on_close=self.on_disconnect,
                                                 on_message=self.on_message)
                self.ws.run_forever()
            except Exception as e:
                print(f"Error en la conexión WebSocket: {e}")
            print("Intentando reconectar en 5 segundos...")
            time.sleep(5)

    def send_message(self, message):
        if self.ws:
            self.ws.send(message)
            #print(f"Enviado: {message}")
        else:
            print("No se ha establecido una conexión WebSocket")

    # def get_proyect_name(self, message, ws):
    #     message_parsed = json.loads(message)
    #     if 'order' in message_parsed:
    #         if message_parsed['order'] == 'get_task_by_dcc':
    #             import hou
    #             project_title = hou.hipFile.name()
    #             self.last_project_title = self.project_title
    #             self.project_title = project_title.replace("\\", "/").split('/')[-1]
    #             self.ws.send(json.dumps({'type': 'register', 'dcc': 'nuke', 'project': self.project_title,
    #                                      'last_project': self.last_project_title}))
    #             return


def start_websocket_client(websocket_path):
    uri = "ws://localhost:18765"  # Cambia esto por la dirección de tu servidor WebSocket
    client = WebSocketClient(uri, websocket_path)
    client.run()

def main(websocket_path):
    print("Iniciando cliente WebSocket...")
    if not hasattr(sys.modules[__name__], 'client_thread'):
        start_websocket_client(websocket_path)
        # Crear un subproceso para ejecutar el cliente WebSocket
        #client_thread.daemon = True  # Establecer el subproceso como daemon

        # Guardar el subproceso en el módulo para mantener el estado
        #sys.modules[__name__].client_thread = client_thread

        # Iniciar el subproceso del cliente WebSocket
        #client_thread.start()
    else:
        pass
        #print("Ya existe una conexión WebSocket. No se iniciará una nueva.")
