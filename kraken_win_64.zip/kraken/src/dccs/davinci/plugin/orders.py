
import json
import threading
import ast


def on_message(message):
    try:
        message = ast.literal_eval(message)
        dcc = message['dcc']
        if dcc == 'davinci':
            comando = message['command']
            #print('Comando recibido:', comando)

            exec(comando, globals())
    except Exception as e:
        pass
