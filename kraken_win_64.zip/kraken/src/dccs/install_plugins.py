# -*- coding: utf-8 -*-
import os.path
import shutil
import subprocess
import os

from src.libraries.file_basic import remove_content_between_markers

from src.dccs.maya.script_install_plugin_maya import edit_or_create_user_setup
from src.dccs.nuke.script_install_plugin_nuke import agregar_plugin_a_nuke_auto

def install_maya(kraken, path_installation_maya):
    # ruta_script = kraken.pwd + '/src/dccs/maya/script_install_plugin_maya.py'
    # python_exec = os.path.dirname(kraken.pwd) + '/venv_kraken/Scripts/python.exe'
    if os.path.isfile(path_installation_maya.text()) and path_installation_maya.text().endswith('maya.exe'):
        print("Blender encontrado.")
    else:
        print("Directorio no encontrado.")
        kraken.btn_install_maya.setStyleSheet("QPushButton { background-color: red; }")
        path_installation_maya.setText("Bad path, try again.")
        path_installation_maya.setStyleSheet("QLineEdit { border: 1px solid red; }")
        return
    edit_or_create_user_setup()
    # comando = [python_exec, ruta_script]
    # subprocess.run(comando, check=True)
    print("Add-on instalado correctamente.")
    kraken.btn_install_maya.setStyleSheet("QPushButton { background-color: green; }")
    path_installation_maya.setStyleSheet("QLineEdit { border: 1px solid green; }")


def install_blender_go(kraken, path_installation_blender):
    # ruta_script = kraken.pwd + '/src/dccs/connector_dccs/blender_connector/script_blender_connector/script_install_addons.py'
    ruta_script = kraken.pwd + '/src/dccs/blender/script_install_addons.py'
    if os.path.isfile(kraken.path_installation_blender) and kraken.path_installation_blender.endswith('blender.exe'):
        print("Blender encontrado.")
    else:
        print("Directorio no encontrado.")
        kraken.btn_install_blender.setStyleSheet("QPushButton { background-color: red; }")
        path_installation_blender.setText("Bad path, try again.")
        path_installation_blender.setStyleSheet("QLineEdit { border: 1px solid red; }")
        return
    comando = [kraken.path_installation_blender, '--background', '--python', ruta_script]
    subprocess.run(comando, check=True)
    print("Add-on instalado correctamente.")
    kraken.btn_install_blender.setStyleSheet("QPushButton { background-color: green; }")


def install_unreal_go(kraken, path_installation_unreal):
    print("Instalando add-on...")
    root_plugin = kraken.pwd + '/src/dccs/unreal/plugin'
    installation_plugin_root = "/".join(path_installation_unreal.text().split('/')[:-4]) + '/Engine/Plugins/Experimental/PythonScriptPlugin/Content/Python/'

    if os.path.exists(installation_plugin_root):
        print("Directorio encontrado.")
    else:
        print("Directorio no encontrado.")
        kraken.btn_install_unreal.setStyleSheet("QPushButton { background-color: red; }")
        path_installation_unreal.setText("Bad path, try again.")
        path_installation_unreal.setStyleSheet("QLineEdit { border: 1px solid red; }")
        return

    init_unreal = os.path.join(installation_plugin_root, 'init_unreal.py')
    directorio_actual = os.getcwd()
    root_kraken = os.path.dirname(directorio_actual)
    print(root_kraken)
    directorio_packages = os.path.join(root_kraken, 'venv_kraken', 'Lib', 'site-packages').replace("\\", "/")

    remove_content_between_markers(init_unreal)  # Limpia la configuracion previa
    with open(init_unreal, 'a') as file:
        file.write("\n")
        file.write("# _______________ PipelinePro Setup ___")
        file.write("\nimport sys\n")
        file.write("try:\n")
        file.write(f"    sys.path.insert(0,'{root_plugin}')\n")
        file.write(f"    import pipelinepro_connector\n")
        file.write(f"    pipelinepro_connector.main('{directorio_packages}')\n")
        file.write("except:\n")
        file.write("    pass\n")
        file.write("# _______________ end setting ___")

    pipelinepro_connector = os.path.join(root_plugin, 'pipelinepro_connector.py')
    with open(pipelinepro_connector, 'r') as file:
        lines = file.readlines()

    # Modificar las primeras tres líneas
    lines[0:3] = ["import sys\n", f"sys.path.insert(0,'{root_plugin}')\n", "import orders\n"]

    # Reescribir el archivo con las líneas modificadas
    with open(pipelinepro_connector, 'w') as file:
        file.writelines(lines)

    print("Add-on instalado correctamente.")
    kraken.btn_install_unreal.setStyleSheet("QPushButton { background-color: green; }")


def install_houdini(kraken, path_installation_houdini):
    ruta_script = kraken.pwd + '/src/dccs/houdini/script_install_plugin_houdini.py'
    python_exec = os.path.dirname(kraken.pwd) + '/venv_kraken/Scripts/python.exe'
    print(ruta_script)
    print(python_exec)
    if os.path.isfile(path_installation_houdini.text()) and path_installation_houdini.text().endswith('houdini.exe'):
        print("Blender encontrado.")
    else:
        print("Directorio no encontrado.")
        kraken.btn_install_maya.setStyleSheet("QPushButton { background-color: red; }")
        path_installation_houdini.setText("Bad path, try again.")
        path_installation_houdini.setStyleSheet("QLineEdit { border: 1px solid red; }")
        return
    comando = [python_exec, ruta_script]
    subprocess.run(comando, check=True)
    print("Add-on instalado correctamente.")
    kraken.btn_install_houdini.setStyleSheet("QPushButton { background-color: green; }")


def install_nuke(kraken, path_installation_nuke):
    ruta_script = kraken.pwd + '/src/dccs/nuke/script_install_plugin_nuke.py'
    python_exec = os.path.dirname(kraken.pwd) + '/venv_kraken/Scripts/python.exe'
    if os.path.isfile(path_installation_nuke.text()) and path_installation_nuke.text().endswith('.exe'):
        print("Nuke encontrado.")
    else:
        # print("Directorio no encontrado.")
        kraken.btn_install_maya.setStyleSheet("QPushButton { background-color: red; }")
        path_installation_nuke.setText("Bad path, try again.")
        path_installation_nuke.setStyleSheet("QLineEdit { border: 1px solid red; }")
        return

    directorio_actual = os.getcwd()
    addon_path = os.path.join(directorio_actual, 'src', 'dccs', 'nuke', 'plugin').replace('\\', '/')
    agregar_plugin_a_nuke_auto(addon_path, 'pipelinepro_connector')
    # comando = [python_exec, ruta_script]
    # subprocess.run(comando, check=True)
    print("Add-on instalado correctamente.")
    kraken.btn_install_nuke.setStyleSheet("QPushButton { background-color: green; }")


def check_installs():
    pass


def edit_file(filepath, originalText, newText):
    # print(filepath)
    with open(filepath, 'r') as archivo:
        contenido = archivo.read()
    texto_modificado = contenido.replace(originalText, newText)
    with open(filepath, 'w') as archivo:
        archivo.write(texto_modificado)

