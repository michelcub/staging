import json
import ast
import websocket
import threading
import importlib
import uuid
import os
from src.operations import orders
from src.dccs.client_connections import client_connections

class KrakenClient:
    def __init__(self, uri="ws://localhost:18765/", listen_messages=None, kraken=None):
        self.uri = uri
        self.ws = None
        self.connected = False
        self.thread = None
        self.listen_messages = listen_messages
        self.kraken = kraken
        self.reconnecting = False
        self.uuid = uuid.uuid4()
    def on_message(self, ws, message):
        importlib.reload(client_connections)
        if type(message) == str:
            message = ast.literal_eval(message)
        if self.listen_messages:
            self.listen_messages(message, self.kraken)

    def on_connect(self, ws):
        print("Kn --- KnMan: Connected")
        self.connected = True
        message = {'type': 'register', 'dcc': 'kraken', 'file': 'Kraken', 'uuid': str(self.uuid)}
        # print(message)
        self.send_message(message)
        #self.ws.send('type|kraken')
        self.kraken.mannager_is_connected = True

    def on_disconnect(self, ws, close_status_code, close_msg):
        print("Kn -x- KnMan_ Disconnected")
        self.connected = False
        self.kraken.mannager_is_connected = False

        if self.kraken.pid_manager is not None and self.kraken.mannager_is_connected is False and self.kraken.pid_manager == 3:
            try:
                self.kraken.terminate_process_by_pid(self.kraken.pid_manager)
                root = os.getcwd()
                exec_manager = os.path.join(f'{root}', 'run_kraken_Manager.bat')
                if os.path.isfile(exec_manager):
                    os.startfile(exec_manager)
                else:
                    print(exec_manager)
            except:
                print('Error al intentar matar el proceso')
                pass

        elif self.kraken.mannager_is_connected is False and self.kraken.pid_manager is None:
            root = os.getcwd()
            exec_manager = os.path.join(f'{root}', 'run_kraken_Manager.bat')
            if os.path.isfile(exec_manager):
                os.startfile(exec_manager)
            else:
                print(exec_manager)

        self.kraken.connect_to_kraken_mannager()


        self.kraken.connect_to_kraken_mannager()


    def run(self):
        def run_websocket():
            self.ws = websocket.WebSocketApp(self.uri,
                                             on_open=self.on_connect,
                                             on_close=self.on_disconnect,
                                             on_message=self.on_message)
            self.ws.run_forever()

        if not self.thread or not self.thread.is_alive():
            self.thread = threading.Thread(target=run_websocket)
            self.thread.daemon = True
            self.thread.start()
        else:
            print("Connection running")


    def send_message(self, message):
        if self.connected:
            #print('>>>>>>>>>>>>>')
            #print(message)
            message = json.dumps(message)
            self.ws.send(message)
        else:
            print("Cant sent message")