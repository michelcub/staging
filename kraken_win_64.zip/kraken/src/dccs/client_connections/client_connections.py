import json
import ast
def listen_messages(message, kraken):
    # print(f"Message received in listen_messages: {message}")

    if type(message) == str:
        message = json.loads(message)
    if 'type' in message and message['type'] == 'dcc_list':
        dcc_list = message['dcc_list']
        # print(f"Received dcc_list: {dcc_list}")
        all_dccs = message['connections']
        kraken.pid_manager = message['pid_manager']
        print(f"Received pid_manager: {kraken.pid_manager}")
        kraken.all_dccs = all_dccs


        #dcc_list = kraken.all_dccs
        update_connections_list(dcc_list, kraken.all_dccs, kraken)







    if "order" in message and "dcc" in message:
        if message["order"] == "command_result" and message["dcc"] == "kraken":

            if "action" in message:
                # print('action', message)
                if "get_tracks" in message["action"]:
                    kraken.ws.send_message(json.dumps({
                        "message": {
                            "tracks": message["tracks"],
                            "action": "get_tracks",
                            "order": "command_result"
                        }
                    }))
                elif "export" in message["action"]:
                    # print("Sending copy_reference to kraken")
                    kraken.ws.send_message(json.dumps({
                        "message": {
                            "result": message["tracks"],
                            "action": "export",
                            "order": "command_result"
                        }
                    }))

                elif "Get Assets" in message["action"]:
                    kraken.ws.send_message(json.dumps({
                        "message": {
                            "assets": message["assets"],
                            "action": message["action"],
                            "order": "command_result"
                        }
                    }))
    # TODO: convertir todos los message a json strucuture
    # type = message['type'] == ''




def update_connections_list(dcc_list, connections, kraken):
    print('updating connections list')
    print(f"Received dcc_list: {dcc_list}")
    kraken.connection_list = dcc_list
    print(f"Updating connections list: {dcc_list}")

    kraken.ws.send_message(json.dumps({
        "message": {
            "list": connections,
            "order": "get_task_by_dcc_result"
        }
    }))
    if 'blender' in dcc_list and kraken.status_blender:
        kraken.status_blender.setStyleSheet("background-color: green")
        kraken.status_blender.setText('ON')

    else:
        kraken.status_blender.setStyleSheet("background-color: red")
        kraken.status_blender.setText('OFF')


    if 'maya' in dcc_list and kraken.status_maya:
        kraken.status_maya.setStyleSheet("background-color: green")
        kraken.status_maya.setText('ON')

    else:
        kraken.status_maya.setStyleSheet("background-color: red")
        kraken.status_maya.setText('OFF')


    if 'houdini' in dcc_list and kraken.status_houdini:
        kraken.status_houdini.setStyleSheet("background-color: green")
        kraken.status_houdini.setText('ON')

    else:
        kraken.status_houdini.setStyleSheet("background-color: red")
        kraken.status_houdini.setText('OFF')

    if 'unreal' in dcc_list and kraken.status_unreal:
        kraken.status_unreal.setStyleSheet("background-color: green")
        kraken.status_unreal.setText('ON')

    else:
        kraken.status_unreal.setStyleSheet("background-color: red")
        kraken.status_unreal.setText('OFF')

    if 'nuke' in dcc_list and kraken.status_nuke:
        kraken.status_nuke.setStyleSheet("background-color: green")
        kraken.status_nuke.setText('ON')

    else:
        kraken.status_nuke.setStyleSheet("background-color: red")
        kraken.status_nuke.setText('OFF')


    print('finished updating connections list')
    # print(f"Registering list: {dcc_list}")
