import socket
import traceback


class Socket_Connect():
    BUFFER_SIZE = 4096
    HOST = '127.0.0.1'
    PORT = 20201
    # HOST = 'staging.pipelinepro.io'
    # PORT = 5000

    def __init__(self,
                 host=HOST,
                 port=PORT,
                 buffer_size=4096):
        self.host = host
        self.port = port
        self.buffer_size = buffer_size
        self.maya_socket = None

    def connect(self, port=-1):
        try:
            self.maya_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # self.maya_socket.connect((self.__class__.HOST, self.__class__.PORT))
            # server_address = ('staging.pipelinepro.io', 5000)
            server_address = ((self.host, self.port))
            self.maya_socket.connect(server_address)
            # hostname = 'DESKTOP-4EDBERS'
            # self.maya_socket.bind((hostname, self.port))
            # self.maya_socket.listen(5)
        except ConnectionError:
            traceback.print_exc()
            return False

        return True

    def disconnect(self):
        try:
            self.maya_socket.close()
        except ConnectionError:
            traceback.print_exc()
            return False

        return True

    def send(self, cmd=None):
        try:
            self.maya_socket.sendall(cmd.encode())

        except ConnectionError:
            traceback.print_exc()
            return None

        return self.recv()

    def recv(self):
        try:
            data = self.maya_socket.recv(Socket_Connect.BUFFER_SIZE)
        except ConnectionError:
            traceback.print_exc()
            return None

        return data.decode().replace('\x00', '')

    def send_maya_command(self, cmd_str):
        cmd = "eval(\"'{0}'\")".format(cmd_str)
        return self.send(cmd)


if __name__ == "__main__":
    maya_client = Socket_Connect()
    if maya_client.connect():
        print("Connected Successfully")
        #
        # # create a new scene
        # maya_client.send_maya_command("cmds.file(new=True, force=True)")
        # # create a cube
        # maya_client.send_maya_command("cmds.polyCube()")

        if maya_client.disconnect():
            print("Disconnected Successfully")

    else:
        print("Failed to connect")