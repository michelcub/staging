# -*- coding: utf-8 -*-

import json

from src.api.graphql import api_call

def validate_apiKey(self, apiKey):
    api_response = None
    query_connect = '''
                  {
                    apikeyAuth(key: "{apiKey}") {
                        key
                        code
                        name
                        folderName
                    }
                  }
                '''
    query_connect = query_connect.replace('{apiKey}', apiKey)
    try:
        api_response = api_call(self, self.http_url, query_connect)
        apiKey = json.loads(api_response)
        apiKey = apiKey['data']['apikeyAuth']
    except:
        print('  ERROR: Connection fail to server')
        self.ui.print_console('  Error Validando apikey')

    if not api_response:
        print('   Desconectar y pedir nuevas credenciales')
        self.ui.print_console('  NO Connected to Server')
        return False
    else:
        if apiKey is not None and "name" in apiKey:
            self.project_name = apiKey["name"]
            self.project_code = apiKey["code"]
            self.project_key = apiKey["key"]
            self.project_folderName = apiKey["folderName"]

            # local kraken work Folders
            self.tempFolder = 'C:/Kraken/temp/'
            self.workFolder = 'C:/Kraken/'

            return True
        else:
            print('   Error, apiKey Invalida')
            self.ui.print_console('  Error, Invalid apiKey')

            return False