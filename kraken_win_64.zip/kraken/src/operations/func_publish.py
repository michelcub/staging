"""
Saber las salidas
Ejecutar Actions

Capturar previas
Escribir en local
Publicar a servidor
Cambios de estado

"""