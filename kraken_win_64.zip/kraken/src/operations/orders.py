# -*- coding: utf-8 -*-

from .ingestador import obtener_informacion_ruta, obtener_informacion_file
import requests
import os
import json
import importlib
import threading
import cv2
import time
import shutil
import glob
import ast

from concurrent.futures import ThreadPoolExecutor

import src.pipelinepro.settings as settings

# from src.pipelinepro.settings import
import src.libraries.file_encryp as file_encryp

# from src.ui.components.upload_kraken import UploadKraken

from src.operations import func_mockup
from src.libraries.file_encryp import folder_tree_of_file
import src.operations.download as download
# from src.operations.video import compress_sequence_video
from src.api.graphql import api_call

import src.operations.video as video
import src.operations.func_vfx_gallery as vfx_gallery
import src.operations.func_open_files as open_files
import src.operations.func_import_foldervideos as import_foldervideos

import src.libraries.windows as windows

from src.operations.task_queue import task_queue




def order_class(kraken, ws, response):
    order = response['order']
    queue = task_queue.TaskQueue()
    #print('response', response)


    if order == 'execute_command':
        dcc = response['dcc']
        #execute_command(kraken, response)
        run_in_thread(execute_command, kraken, response)
        kraken.print_console_ws.emit('    Execute in ' + str(dcc))



    # TODO: Deprecar
    elif order == 'command_to_dcc':
        dcc = response['dcc']
        command = response['command']
        execution = execute_command(kraken, dcc, command)
        kraken.print_console_ws.emit('    Command to: ' + str(dcc))

    elif order == 'open_folder':
        path = response['folderLocal']
        #open_folder(path)
        run_in_thread(open_folder, path)
        kraken.print_console_ws.emit('    Open Folder: ' + str(path))

    elif order == 'copy_folder':
        from_path = response['from_path']
        to_path = response['to_path']
        run_in_thread(copy_folder, from_path, to_path, kraken)
        kraken.print_console_ws.emit('    Copy Folder: ' + str(from_path) + ' >>> ' + str(to_path))

    elif order == 'download_project':
        project_key = response['key']
        file_include = response['include']
        file_exclude = response['exclude']
        print('download_project')
        #download_project(kraken, key)
        run_in_thread(download_project, kraken, project_key, file_include, file_exclude)
        kraken.print_console_ws.emit('    Downloading Project...')

    elif order == 'download_folder':
        key = response['key']
        run_in_thread(download_folder, kraken, key)
        kraken.print_console_ws.emit('    Download Folder: ' + str(key))


    elif order == 'download_dependence':
        key = response['key']
        run_in_thread(download_dependence, kraken, key)
        kraken.print_console_ws.emit('    Download Dependence: ' + str(key))


    elif order == 'download_file_direct':
        print(' +++++ download_file_direct')
        file_local = response['file_local']
        file_link = response['file_link']
        #download_file_direct(kraken, file_link, file_local)
        run_in_thread(download_file_direct, kraken, file_link, file_local)
        kraken.print_console_ws.emit('    Download File Direct: ' + str(file_local))

    elif order == 'open_file':
        key = response['key']
        # run_in_thread(open_file, kraken, key)
        run_in_thread(open_file, kraken, response)
        #kraken.print_console_ws.emit('    Open File: ' + str(fileLocal))
        kraken.print_console_ws.emit('    Open File')

    elif order == 'save_as':
        dcc = response['dcc']

        run_in_thread(save_as, kraken, response)
        # run_in_thread(execute_command, kraken, response)
        kraken.print_console_ws.emit('    Save as for ' + str(dcc))

    elif order == 'element_import_nuke':
        #element_import_nuke_in(kraken, response)
        run_in_thread(element_import_nuke_in, kraken, response)

        # kraken.print_console_ws.emit('    Import Nuke Library')

    elif order == 'ping_room':
        print('ping_room')
        code = response['code']
        print(code)
        kraken.print_console_ws.emit('    Open code: ' + str(code))
        mensaje = json.dumps({"message": "<<<<<<< Ping Room - " + str(code)})
        #ws.send(mensaje)
        run_in_thread(ws.send, mensaje)

    elif order == 'dcc_to_top':
        dcc = response['dcc']
        importlib.reload(windows)
        #windows.bring_to_front(dcc)
        run_in_thread(windows.bring_to_front, dcc)

    elif order == 'frompath_tojson':
        path = response['path']
        kraken.print_console_ws.emit('    frompath_tojson: ' + str(path))
        #frompath_tojson(kraken, path)
        run_in_thread(frompath_tojson, kraken, path)

    # ------------------ Create VFX Gallery
    elif order == 'read_folderpath_to_json':
        path = response['path']
        print(path)
        kraken.print_console_ws.emit('    read_folderpath_to_json: ' + str(path))
        #read_folderpath_to_json(kraken, path)
        run_in_thread(read_folderpath_to_json, kraken, path)

    elif order == 'convert_sequence':
        path = response['folderLocal']
        key = response['key']
        print(path)
        kraken.print_console_ws.emit('    convert_sequence: ' + str(path))
        if not queue.is_running:
            queue.start()
        queue.add_task(convert_sequence, kraken, path, key)
        print('    convert_sequence added to queue')
        #convert_sequence(kraken, path, key)
        #run_in_thread(convert_sequence, kraken, path, key)
    # -------------------------------------

    elif order == 'check_connection':
        print('    Test Connection OK')
        kraken.print_console_ws.emit('    Connect Client Ingest OK')
        #check_conection(kraken)
        run_in_thread(check_conection, kraken)
        return True

    elif order == 'register_kraken':
        print('    Register Kraken OK')
        kraken.print_console_ws.emit('    > Register Kraken OK')
        #register_kraken(kraken)
        run_in_thread(register_kraken, kraken)
        # register = RegisterKraken()
        # register.room = self.room
        # register.type = self.type
        # register.register_kraken(ws)
        return True

    elif order == 'select_folder':
        print('select_folder')
        kraken.select_folder()

    elif order == 'select_file':
        print('select_file')
        kraken.select_file()


    # ------------------ Import Episode Folder Videos
    elif order == 'read_folder_import_episode_toonboom':
        path = response['data']
        kraken.print_console_ws.emit('    Read Folder for import: ' + str(path))
        run_in_thread(read_folder_import_episode_toonboom, kraken, path)

    # elif order == 'import_episode_toonboom':
    elif order == 'file_operations':
        kraken.print_console_ws.emit('    File Operation')
        run_in_thread(file_operations, kraken, response)
    # -------------------------------------

    # ------------------ Mockup
    elif order == 'mockup':
        print('Response', response)
        kraken.print_console_ws.emit('Mockup Action')
        kraken.kraken_manager_client.send_message(response)

    # ------------------ background in dcc
    elif order == 'review_background_dcc':
        key = response['key']
        dcc = response['dcc']
        project = response['fileLocal'].split('/')[-1]
        command = response['command']

        #-------- Abrimos el fichero
        run_in_thread(open_file, kraken, response)
        kraken.print_console_ws.emit('    Open File')

        #-------- Ejecutamos el comando cuando se abra el dcc
        run_in_thread(execute_command_if_dcc_is_open, kraken, dcc, project, command)


        #-------- Obtenemos las tareas abiertas en dcc
    elif order == 'get_task_by_dcc':
        response['dcc'] = response['dcc'].lower()
        kraken.kraken_manager_client.send_message(response)

    elif order == 'render_clip_list':
        clip_list = response['clip_list']
        configuration = response['configuration']

        if response['dcc'] == 'kraken':
            run_in_thread(render_clip_list, kraken, clip_list, configuration)

    elif order == 'upload_kraken':
        print('upload_kraken')
        kraken.print_console_ws.emit('Upload Kraken')
        print(response)
        folder_key = response.get('folder_key', None)
        kraken.communicator.triggerOpenDropZoneKraken.emit(folder_key)

    elif order == 'execute_in_dcc':
        kraken.print_console_ws.emit('Execute in DCC')
        run_in_thread(execute_in_dcc, kraken, response)

# ------------------ EXECUTE IN DCC
def execute_in_dcc(kraken, response):
    dcc = response['dcc']
    file = response.get('file', None)
    dcc_list = kraken.all_dccs

    for dcc_object in dcc_list:
        if file is not None:
            if dcc_object['dcc'] == dcc and dcc_object['file'] == file:
                uuid = dcc_object['uuid']
                response['uuid'] = uuid
                kraken.kraken_manager_client.send_message(response)
                break
        else:
            if dcc_object['dcc'] == dcc:
                uuid = dcc_object['uuid']
                response['uuid'] = uuid
                kraken.kraken_manager_client.send_message(response)

    kraken.print_console_ws.emit('    Command to: ' + str(dcc))


# ------------------ OPEN UPLOAD
# def open_upload():
#     upload = UploadKraken()
#     upload.show()


# ------------------ EXECUTION COMMAND
def execute_command(kraken, response):
    # print('a - execute_command')
    dcc = response['dcc']
    command = response['command']
    if dcc == 'kraken' or dcc == 'photoshop':
        try:
            exec(command)
            kraken.print_console_ws.emit('    Execute in Kraken')
        except SyntaxError as err:
            print('+++ Error execute +++')
            print("Error message:", err.msg)
            print("Error at line:", err.lineno)
            print("Error text:", err.text.strip() if err.text else "No text available")
            pass
    else:
        kraken.kraken_manager_client.send_message(response)
    return True
# ---------------------------------------------------

def open_folder(path):
    # TODO: Comprobar que path es una folder para evitar ataques

    folder_to_server(path)

    if os.name == 'nt':
        if path.startswith('//'):
            path = path.replace('/', '\\')
        command = 'start ' + f'{path}'
    else:
        path = path.replace('\\', '/')
        command = 'xdg-open ' + f'{path}'
    os.system(command)
    return True


def copy_folder_overwrite(from_path, to_path):
    if not os.path.isdir(from_path):
        from_path = os.path.dirname(from_path)
    try:
        if os.path.exists(to_path):
            shutil.rmtree(to_path)
        shutil.copytree(from_path, to_path)
    except Exception as e:
        print(f"Error al copiar la carpeta: {e}")
    return True


def copy_folder(from_path, to_path, kraken):
    if not os.path.isdir(from_path):
        from_path = os.path.dirname(from_path)
    # kraken.print_console_ws.emit('    from_path: ' + str(from_path))
    # kraken.print_console_ws.emit('    to_path: ' + str(to_path))
    try:
        if not os.path.exists(to_path):
            os.makedirs(to_path)
        for item in os.listdir(from_path):
            s = os.path.join(from_path, item)
            d = os.path.join(to_path, item)
            s = s.replace('\\', '/')
            d = d.replace('\\', '/')
            kraken.print_console_ws.emit('    Copy: ' + str(d))
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                copy_folder(s, d)
            else:
                shutil.copy2(s, d)
    except Exception as e:
        kraken.print_console_ws.emit('' + str(e))
        print(f"Error al copiar la carpeta: {e}")

    return True




def download_project(kraken, key, file_include, file_exclude):
    """
    TODO Proceso ROTO
    La descarga viene para que la haga el server y al no tener credenciales de usuario no
    puede acceder a la api para hacer la consulta de lo que debe descargar.
    """
    importlib.reload(download)
    down = download.Download(kraken)
    print('key', key)
    down.download_project(key, file_include, file_exclude)
    return True


def download_folder(kraken, key):
    importlib.reload(download)
    down = download.Download(kraken)
    folder_list = key.split()
    down.download_folder_list(folder_list)
    return True


def download_dependence(kraken, key):
    importlib.reload(download)
    down = download.Download(kraken)
    down.download_dependence_list(key)
    return True


def download_file_direct(kraken, file_link, file_local):
    response = requests.get(file_link)
    importlib.reload(file_encryp)
    folder_tree_of_file(file_local)
    with open(file_local, 'wb') as archivo:
        archivo.write(response.content)
        # poner metadatos del original
        # self.print_console_download.emit('    Download', file_path)
        print('    Download', file_local)
    return True


def open_file(kraken, response):
    key = response['key']
    fileLocal = response['fileLocal']
    link = response['link']
    uuid = response.get('uuid', None)
    print(uuid, 'uuid==================================')
    importlib.reload(open_files)
    print('-- reload -- open_files')
    return open_files.run(kraken, key, fileLocal, link,  uuid)


def save_as(kraken, response):
    importlib.reload(open_files)
    upload_link = response['upload_link']
    file_path = response['save_path']
    file_key = response['file_key']
    folder_key = response['folder_key']
    folder_path = response['folder_path']
    command = response['command']
    print(command)

    # Creamos las folder si no existen
    upload = download.Download(kraken)
    upload.file_exist(file_path)

    kraken.kraken_manager_client.send_message(response)
    # while not open_files.file_exist(file_path):
    #     print('  sleep')
    #     time.sleep(2)
    time.sleep(3)
    # open_files.upload_file(kraken, file_path, upload_link, file_key)

    upload.upload_folder(folder_key, folder_path)

    return True




def element_import_nuke_in(kraken, response):
    importlib.reload(vfx_gallery)
    print('-- reload -- vfx_gallery')
    print('despues de recargar vfx_gallery')
    vfx_gallery.element_import_nuke(kraken, response)


def folder_to_server(dst_Folder):
    """
    Crea las carpetas si no estan ahi
    """
    if os.path.isdir(dst_Folder):
        return True
    else:
        os.makedirs(dst_Folder)
        return True


def frompath_tojson(self, path):
    data_json = {}
    if os.path.isdir(path):
        data_json = obtener_informacion_ruta(path)
    else:
        data_json = obtener_informacion_file(path)
    if self.ws:
        self.ws.send_message(json.dumps({
            "message": {
                "type": "frompath_tojson",
                "data": data_json
            }
        }))
    else:
        print("WebSocket connection not established. Unable to send data.")



# ------------------ Create VFX Gallery
def read_folderpath_to_json(self, path):
    data_json = obtener_informacion_ruta(path)
    if self.ws:
        self.ws.send(json.dumps({
            "message": {
                "type": "read_folderpath_to_json",
                "data": data_json
            }
        }))
    else:
        print("WebSocket connection not established. Unable to send data.")

def convert_sequence(kraken, path, key):
    importlib.reload(vfx_gallery)
    print('-- reload -- vfx_gallery')

    vfx_gallery.run(kraken, path, key)
# ---------------------------------------------------


def check_conection(self):
    if self.ws:
        self.ws.send(json.dumps({
            "message": {
                "type": "check_conection",
                "data": "Conection is OK"
            }
        }))
    else:
        print("WebSocket connection not established. Unable to send data.")


def register_kraken(self):
    pc_name = os.environ.get('HOSTNAME') or os.environ.get('COMPUTERNAME')
    logged_in_user = os.environ.get('USERNAME') or os.environ.get('USER')

    if self.ws:
        self.ws.send(json.dumps({
            "register": {
                "type": self.type,
                "mode": self.mode,
                "win_user": logged_in_user,
                "room": self.room,
                "kraken_id": settings.kraken_id,
                "pc_name": pc_name,
                "user_key": self.userKey if self.userKey else None,
                "file_Token_key": self.apiKey if self.apiKey else None,
            }
        }))
    else:
        print("WebSocket connection not established. Unable to send data.")




# ------------------ Import Episode from folder Videos
def read_folder_import_episode_toonboom(kraken, full_path):
    importlib.reload(import_foldervideos)
    import_foldervideos.read_folder_import_episode_toonboom(kraken, full_path)


def file_operations(kraken, response):
    importlib.reload(import_foldervideos)
    import_foldervideos.file_operations(kraken, response)
# ---------------------------------------------------



# ------------------ Thread
def run_in_thread(method, *args, **kwargs):
    """ Ejecuta un método en un nuevo hilo.

    Args:
        method: Método a ejecutar en el hilo.
        *args: Argumentos posicionales para el método.
        **kwargs: Argumentos con nombre para el método.
    """
    thread = threading.Thread(target=method, args=args, kwargs=kwargs)
    thread.start()

    return thread

# ------------------ execute_command if dcc is open
def execute_command_if_dcc_is_open(kraken, dcc, project, command):
    time.sleep(10)
    is_open_dcc = False

    while is_open_dcc is False:
        for dcc_object in kraken.all_dccs:
            if dcc_object['dcc'] == dcc and dcc_object['project'] == project:
                print(kraken.all_dccs)
                kraken.kraken_manager_client.send_message({'order': 'execute_command', 'dcc': dcc, 'project': project, 'command': command})
                is_open_dcc = True
                break
        time.sleep(5)
    
        if is_open_dcc is True:
            break

    #kraken.kraken_manager_client.send_message({'order': 'execute_command', 'dcc': dcc, 'project': project, 'command': command})
    kraken.print_console_ws.emit('    Open Review in Background')

def convert_video_to_jpeg_sequence_wrapper(args):
    kraken, video_path, start_frame, end_frame, fps, resolution, save_path, filename_prefix = args
    video.convert_video_to_jpeg_sequence(
        kraken,
        video_path=video_path,
        start_frame=start_frame,
        end_frame=end_frame,
        fps=fps,
        resolution=resolution,
        save_path=save_path,
        filename_prefix=filename_prefix
    )

def render_clip_list(kraken, clip_list, configuration):
    # Preparar los argumentos para cada llamada de función en una lista
    tasks = [
        (
            kraken,
            clip["path"],
            clip["start"],
            clip["end"],
            configuration["fps"],
            configuration["resolution"],
            configuration["output_path"],
            clip["name"]
        ) for clip in clip_list
    ]

    # Usar ThreadPoolExecutor para ejecutar las tareas en paralelo con 5 hilos
    with ThreadPoolExecutor(max_workers=5) as executor:
        executor.map(convert_video_to_jpeg_sequence_wrapper, tasks)