import queue
import threading

class TaskQueue:
    def __init__(self):
        self.task_queue = queue.Queue()
        self.is_running = False

    def add_task(self, task, *args):
        self.task_queue.put((task, args))

    def start(self):
        self.is_running = True
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        while self.is_running:
            task, args = self.task_queue.get()
            try:
                task(*args)
                print("Tarea ejecutada.")
            except Exception as e:
                print(f"Error al ejecutar la tarea: {e}")
            self.task_queue.task_done()
