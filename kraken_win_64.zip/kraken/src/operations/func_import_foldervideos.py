# -*- coding: utf-8 -*-

import os
import shutil
import json
import cv2
import subprocess
import threading
from queue import Queue
from moviepy.editor import *
from PIL import Image

from src.libraries.file_basic import termina_en_barra
from src.operations.download import file_exist, Download

# ------------------ Import Episode from folder Videos
def read_folder_import_episode_toonboom(kraken, full_path):
    print('read_folder_import_episode_toonboom')
    data_json = register_folderpath_for_import_episode(full_path)

    if kraken.ws:
        kraken.ws.send_message(json.dumps({
            "message": {
                "type": "folder_import_episode_toonboom",
                "data": data_json
            }
        }))
    else:
        print("WebSocket connection not established. Unable to send data.")


def register_folderpath_for_import_episode(full_path):
    file_list = os.listdir(full_path)
    full_path = termina_en_barra(full_path)

    shot_list = []
    shot_id = 10
    in_frame = 0
    out_frame = 0
    for file in file_list:
        media_file = full_path + file
        if not os.path.isfile(media_file):
            continue
        file_extension = file.split('.')[-1:][0]
        if file_extension in ['mov', 'avi', 'mp4']:
            video = cv2.VideoCapture(media_file)
            video_duration = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
            video_fps = video.get(cv2.CAP_PROP_FPS)

            step_frame = 10
            out_frame = in_frame + int(video_duration)

            shot = {
                'shot_number': shot_id,
                'duration': video_duration,
                'framerate': video_fps,
                'in_frame': in_frame,
                'out_frame': out_frame,
                'extension': file_extension,
                'filename': file,
                'file_size': os.path.getsize(media_file)
            }
            shot_id += step_frame
            in_frame += video_duration

            shot_list.append(shot)
    json_response = json.dumps(shot_list)

    return json_response



# ------------------ file Operations
# def file_operations(kraken, response):
    # operation = response['operation']
    # import_episode_toonboom(kraken, response)
    # if operation == 'import_episode_toonboom':
    #     import_episode_toonboom(kraken, response)
    # elif operation == 'upload_folder_video_to_maintask':
    #     print('Meter datos')
    #     import_episode_toonboom(kraken, response)


# def import_episode_toonboom(kraken, response):
def file_operations(kraken, response):
    operation = response['operation']
    folderLocal = response['folderLocal']
    data = response['data']
    data = json.loads(data)

    if not kraken.q_up_episode:
        kraken.upload_episode = Thread_Upload_Episode(kraken)
    kraken.upload_episode.threader_up(amount=10)

    work_folder = folderLocal + '/_work/'
    if not os.path.exists(work_folder):
        os.makedirs(work_folder)

    for task in data:
        if task['extension'] in ['mov', 'avi', 'mp4']:
            if operation == 'import_episode_toonboom':
                job = {
                    'operation': operation,
                    'work_folder': work_folder,

                    'file_original': folderLocal + '/' + task['filename'],
                    'file_name': task['file_name'],
                    'shot_key': task['shot_key'],
                    'shot_code': str(task['shot_number']),

                    'image_local': task['file_name'] + '.jpg',
                    'image_uploadLink': task['image_uploadLink'],
                    'image_uploadLink_XXS': task['image_uploadLink_XXS'],
                    'image_uploadLink_XS': task['image_uploadLink_XS'],
                    'image_uploadLink_S': task['image_uploadLink_S'],
                    'image_uploadLink_M': task['image_uploadLink_M'],
                    'image_uploadLink_L': task['image_uploadLink_L'],
                    'image_cloud': task['image_cloud'],

                    'preview_local': task['file_name'] + '.mp4',
                    'preview_uploadLink': task['preview_uploadLink'],
                    'preview_cloud': task['preview_cloud'],

                    'video_local': folderLocal + task['filename'],
                    'video_uploadLink': task['video_uploadLink'],
                    'video_cloud': task['video_cloud'],
                }
            elif operation == 'upload_folder_video_to_maintask':
                job = {
                    'operation': operation,
                    'work_folder': work_folder,

                    'file_original': folderLocal + '/' + task['filename'],
                    'file_name': task['file_name'],
                    'file_key': task['file_key'],
                    'file_size': task['file_size'],
                    'shot_key': task['shot_key'],

                    'maintask_key': str(task['maintask_key']),
                    'folder_key': str(task['folder_key']),
                    'file_uploadLink': task['file_uploadLink'],
                }
            kraken.q_up_episode.put(job)

    kraken.q_up_episode.join()
    print('------------------- COMPLETED -----------------')
    clean_temporals(work_folder)
    kraken.print_console_ws.emit('  Upload completed')

    # Matar threads al acabar
    for thread_file in kraken.threads_files:
        print(thread_file)
        thread_file.join()
        # thread_file.stop
# ---------------------------------------------------




# ===================  THREAD UPLOAD EPISODE
class Thread_Upload_Episode:
    def __init__(self, kraken):
        self.kraken = kraken
        self.print_lock = threading.Lock()
        self.kraken.q_up_episode = Queue()

    # -------------------- INICIADOR THREADS -------------------
    def threader_up(self, amount=20):
        threads_workers = contar_threads_por_nombre(threading.enumerate(), 'threader_upload_episode')
        # print('    TH all: ' + str(threading.active_count()))
        # print('    TH workers: ' + str(threads_workers))
        # print('    Queue: ' + str(self.kraken.q_up_episode.qsize()))

        self.kraken.threads_files = []
        if threads_workers < amount:
            for x in range(amount):
                t = threading.Thread(target=self.threader_upload_episode)
                t.daemon = True
                t.start()
                self.kraken.threads_files.append(t)
    # ----------------------------------------------------------



    def threader_upload_episode(self):
        while True:
            job = self.kraken.q_up_episode.get()
            self.threader_upload_episode_Job(job)
            self.kraken.q_up_episode.task_done()

    # TODO: HAcer que esto sea generico para todas las operaciones empaquetadas
    def threader_upload_episode_Job(self, job):
        if job['operation'] == 'import_episode_toonboom':
            # print(job['shot_code'] + ' | ' + job['file_original'] + ' >>>> ' + job['preview_local'])
            preview_local = compress_video(self.kraken, job['file_original'], job['work_folder'] + job['file_name'] + '.mp4')

            # print(job['shot_code'] + ' | ' + job['file_original'] + ' >>>> ' + job['image_local'])
            image_local = save_image_from_video(job['file_original'], job['work_folder'] + job['file_name'])

            # print(job['shot_code'] + ' | ' + job['preview_local'] + ' >>>> ' + job['preview_cloud'])
            upload = Download(self.kraken)
            upload.upload_file_link(preview_local, job['preview_uploadLink'])

            # print(job['shot_code'] + ' | ' + job['image_local']   + ' >>>> ' + job['image_cloud'])
            upload.upload_file_link(image_local, job['image_uploadLink'])
            upload.upload_file_link(image_local + '_XXS.webp', job['image_uploadLink_XXS'])
            upload.upload_file_link(image_local + '_XS.webp', job['image_uploadLink_XS'])
            upload.upload_file_link(image_local + '_S.webp', job['image_uploadLink_S'])
            upload.upload_file_link(image_local + '_M.webp', job['image_uploadLink_M'])
            upload.upload_file_link(image_local + '_L.webp', job['image_uploadLink_L'])

            # print(job['shot_code'] + ' | ' + job['file_original'] + ' >>>> ' + job['video_cloud'])
            upload.upload_file_link(job['file_original'], job['video_uploadLink'])
        elif job['operation'] == 'upload_folder_video_to_maintask':
            upload = Download(self.kraken)
            upload.upload_file_link(job['file_original'], job['file_uploadLink'])


        self._running = False
        with self.print_lock:
            print(job['file_name'] + ' ok')
            pass
    # ----------------------------------------------------------



def save_image_from_video(in_path, out_path):
    image_name = out_path + '.jpg'

    clip = VideoFileClip(in_path)
    clip.save_frame(image_name, t=0.5)
    clip.reader.close()

    reSizeImageWebp(image_name)
    return image_name



def compress_video(kraken, in_path, out_path):
    if file_exist(out_path):
        os.remove(out_path)
    comando = [
        kraken.ffmpeg_exe,
        '-i', in_path,
        '-c:v', 'libx264',
        '-crf', '20',
        '-preset', 'medium',
        '-c:a', 'copy',
        '-acodec', 'aac',
        out_path
    ]
    proceso = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    salida, error = proceso.communicate()
    if proceso.returncode != 0:
        print(error.decode('utf-8'))
    return out_path


#------------------------------ Resize
def reSizeImageWebp(imagePath):
    if not imagePath.split('.')[-1].lower() in ['jpg', 'jpeg', 'png', 'tiff', 'tif', 'tga', 'bmp', 'webp']:
        return False
    im = Image.open(imagePath)

    resolution_list = {
        '_XXS.webp': 60,
        '_XS.webp': 140,
        '_S.webp': 500,
        '_M.webp': 1200,
        '_L.webp': 1920
    }

    for name, sizeX in resolution_list.items():
        imagePath_Out = str(imagePath) + str(name)

        sizeY = int(sizeX * (float(im.height) / float(im.width)))
        im_resized = im.resize((int(sizeX), int(sizeY)))
        im_resized.save(imagePath_Out, format="webp")
    im.close()


def contar_threads_por_nombre(lista_threads, nombre_buscado):
    contador = 0
    for thread in lista_threads:
        if nombre_buscado in str(thread.name):
            contador += 1
    return contador


def clean_temporals(folderpath):
    if os.path.exists(folderpath):
        shutil.rmtree(folderpath)