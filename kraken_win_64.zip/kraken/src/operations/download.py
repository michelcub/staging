# -*- coding: utf-8 -*-

from PyQt5.QtCore import QObject, pyqtSignal

import requests
import json
import os
import threading
from botocore.exceptions import ClientError

from src.api.graphql import api_call, loging
from src.operations.download_block.download_project import Download_project
from src.libraries.file_basic import folder_file_list


class Download(QObject, Download_project):
    # print_console_download = pyqtSignal(str)
    def __init__(self, kraken):
        self.kraken = kraken
        self.url = kraken.http_url
        self.username = kraken.username
        self.password = kraken.password
        if not kraken.token_auth:
            kraken.token_auth = loging(self, self.url)
        self.token_auth = kraken.token_auth

    def download_task_list(self, task_list):
        for task_key in task_list:
            folder_list = self.depencence_files(task_key)
            # print(folder_list)
            for folder in folder_list:
                # print(folder)
                folder_target = folder['files']
                for file in folder_target:
                    print(file['fileLocal'])
                    self.order_file(file)
            print('---------------------------------------')

    def project_folders(self, key):
        query_folder = '''
              query {
                  project(token: "{token}",
                        key:"{key}") {
                    dependenceTree {
                      key
                    }
                  }
                }
            '''
        query_folder = query_folder.replace('{key}', key)
        folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
        folder_response = json.loads(folder_response)
        file_list = folder_response['data']['task']['dependenceTree']

        return file_list


    def depencence_folders(self, key):
        query_folder = '''
              query {
                  task(token: "{token}",
                        key:"{key}") {
                    dependenceTree {
                      key
                    }
                  }
                }
            '''
        query_folder = query_folder.replace('{key}', key)
        folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
        folder_response = json.loads(folder_response)
        file_list = folder_response['data']['task']['dependenceTree']

        return file_list

    def depencence_files(self, key):
        query_files = '''
              query {
                  task(token: "{token}",
                        key:"{key}") {
                    dependenceTree {
                      files {
                        fileName
                        fileSize
                        fileLocal
                        link
                      }
                    }
                  }
                }
            '''
        query_files = query_files.replace('{key}', key)
        folder_response = api_call(self.kraken, self.url, query=query_files, token=self.token_auth)
        folder_response = json.loads(folder_response)
        file_list = folder_response['data']['task']['dependenceTree']

        return file_list

    def folder_files(self, key):
        query_folder = '''
              query {
                folder(token: "{token}",
                        key:"{key}") {
                  name
                  folderLocal
                  files {
                      fileName
                      fileSize
                      fileLocal
                      link
                    }
                }
              }
            '''
        query_folder = query_folder.replace('{key}', key)

        folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
        folder_response = json.loads(folder_response)
        folderLocal = folder_response['data']['folder']['folderLocal']
        file_list = folder_response['data']['folder']['files']

        return folderLocal, file_list


    def dependence_folder_files(self, key):
        query_folder = '''
            query {
                task(token: "{token}",
                        key:"{key}") {
                    name
                    dependenceTree {
                        name 
                        key
                    }
                }
            }
            '''
        query_folder = query_folder.replace('{key}', key)

        folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
        folder_response = json.loads(folder_response)

        folder_list = folder_response['data']['task']['dependenceTree']

        return folder_list


    def order_file(self, file):
        # Si el fichero no existe lo copia
        if not self.file_exist(file['fileLocal']):
            self.download_file(file['link'], file['fileLocal'])
        else:
            file_size = os.path.getsize(file['fileLocal'])
            # if file_size != file['fileSize']:
            #     print(' from ', file_size, ' >> ', file['fileSize'])
            #     print('--- Sobreescribo ---')
            #     self.download_file(file['link'], file_path)
            # else:
            #     print(file['fileName'], '--- It´s correct ---')
        return file['fileLocal']

    def download_file(self, file_link, file_path):
        folder_path = os.path.dirname(file_path)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        response = requests.get(file_link)
        try:
            with open(file_path, 'wb') as archivo:
                archivo.write(response.content)
                # poner metadatos del original
                # self.print_console_download.emit('    Download', file_path)
                print('    Download', file_path)
        except:
            print('    Error in download_file', file_path)

        return file_path


    def detect_new_files(self, folderLocal, file_list):
        # Mira si hay ficheros en folderLocal(local) que no estan en file_list(cloud) para poder subirlos
        file_list_folder = os.listdir(folderLocal)
        file_list_cloud = []
        for file_object in file_list:
            valor_deseado = file_object.get("fileName")
            file_list_cloud.append(valor_deseado)

        file_list_local = []
        for lf in file_list_folder:
            if os.path.isfile(folderLocal + lf):
                file_list_local.append(lf)

        new_files = [archivo for archivo in file_list_local if archivo not in file_list_cloud]
        return new_files


    def download_folder_list(self, folder_list):
        if threading.active_count() < self.kraken.thread_amount:
            self.threader_up(amount=self.kraken.thread_amount - threading.active_count())

        for folder_key in folder_list:
            folderLocal, file_list = self.folder_files(folder_key)

            # Ver lo que contiene la folder nuevo
            self.folder_exist(folderLocal)
            upload_file_list = self.detect_new_files(folderLocal, file_list)

            if upload_file_list:
                print('  detected new filer for upload:')
                for file_name in upload_file_list:
                    print('    ' + folderLocal + file_name)
                    self.upload_file(folder_key, file_name)

                    # filePath_up_Dream = folder_key + '>>>>>>>>' + file_name
                    # self.kraken.q_up.put(filePath_up_Dream)

            for file in file_list:
                # Comprobar si existe en disco
                if not self.file_exist(file['fileLocal']):
                    # self.download_file(file['link'], file['fileLocal'])
                    # self.order_file(file)

                    filePath_Dream = file['link'] + '>>>>>>>>' + file['fileLocal']
                    self.kraken.q.put(filePath_Dream)

        self.kraken.q.join()
        print('------------ DOWNLOAD COMPLETED ------------')


    def download_dependence_list(self, key):
        if threading.active_count() < self.kraken.thread_amount:
            self.threader_up(amount=self.kraken.thread_amount - threading.active_count())

        folder_list = self.dependence_folder_files(key)

        for folder in folder_list:
            folder_key = folder['key']
            print(folder_key)
            folderLocal, file_list = self.folder_files(folder_key)
            print(file_list)
            self.folder_exist(folderLocal)
            upload_file_list = self.detect_new_files(folderLocal, file_list)

            for file in file_list:
                # Comprobar si existe en disco
                print(file['fileLocal'])
                if not self.file_exist(file['fileLocal']):

                    filePath_Dream = file['link'] + '>>>>>>>>' + file['fileLocal']
                    self.kraken.q.put(filePath_Dream)

        self.kraken.q.join()
        print('------------ DOWNLOAD COMPLETED ------------')




    def folder_exist(self, folder_path):
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)


    def file_exist(self, file_path):
        # file_path = file['fileLocal']
        folder_path = os.path.dirname(file_path)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # Si el fichero no existe lo copia
        if os.path.exists(file_path):
            return True
        else:
            return False

    def upload_file(self, folder_key, file_name):

        def new_file(folder_key, file_name):
            query_folder = '''
                mutation{
                    newFile(token: "{token}",
                            key: "{folder_key}",
                            fileName: "{file_name}"){
                        file{
                            uploadLink
                            key
                            fileLocal
                        }
                    }
                }
                '''
            query_folder = query_folder.replace('{folder_key}', folder_key)
            query_folder = query_folder.replace('{file_name}', file_name)

            folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
            folder_response = json.loads(folder_response)
            uploadLink = folder_response['data']['newFile']['file']['uploadLink']
            file_key = folder_response['data']['newFile']['file']['key']
            fileLocal = folder_response['data']['newFile']['file']['fileLocal']
            # file = folder_response['data']['newFile']['file']
            return uploadLink, file_key, fileLocal


        def upload_completed(file_key, fileSize):
            query = '''
                mutation{
                    completedFile(token: "{token}",
                            key: "{file_key}",
                            fileSize: {fileSize}){
                            file{
                              key
                            }
                    }
                }
                '''
            query = query.replace('{file_key}', file_key)
            query = query.replace('{fileSize}', fileSize)

            folder_response = api_call(self.kraken, self.url, query=query, token=self.token_auth)
            return file_key


        uploadLink, file_key, fileLocal = new_file(folder_key, file_name)

        if '/' in file_name:
            fileSize = self.upload_file_link(file_name, uploadLink)
        else:
            fileSize = self.upload_file_link(fileLocal, uploadLink)

        upload_completed(file_key, str(fileSize))
        self.kraken.print_console_ws.emit('    Uploaded File: ' + str(file_name))
        return file_key


    def upload_folder(self, folder_key, folder_path):
        file_list = folder_file_list(folder_path)
        for file in file_list:
            self.upload_file(folder_key, file)


    def upload_file_link(self, fileLocal, uploadLink):
        with open(fileLocal, 'rb') as file_data:
            response: requests.Response = requests.put(uploadLink, data=file_data)
        self.kraken.print_console_ws.emit('    Uploaded File: ' + str(fileLocal))
        return os.path.getsize(fileLocal)


def file_exist(file_path):
    folder_path = os.path.dirname(file_path)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # Si el fichero no existe lo copia
    if os.path.exists(file_path):
        return True
    else:
        return False