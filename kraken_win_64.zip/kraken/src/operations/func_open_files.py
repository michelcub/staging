# -*- coding: utf-8 -*-

import os
import json
import subprocess
import threading
import requests

import src.pipelinepro.settings as settings
from src.api.graphql import api_call
from src.operations.download import file_exist, Download


def run(kraken, key, fileLocal, link, uuid=None):
    # hacerlo en un hilo separado
    hilo = threading.Thread(target=open_file, args=(kraken, key, fileLocal, link, uuid))
    print('+++ Start del thread open_file')
    hilo.start()
    hilo.join()
    print('--- End del thread open_file')


def open_file(kraken, key, fileLocal, link, uuid=None):
    print('open_file')
    print('=============================================')

    print('uuid', uuid)
    print('=============================================')
    url = kraken.http_url
    if not file_exist(fileLocal):
        down = Download(kraken)
        down.download_file(link, fileLocal)
    # if not file_exist(fileLocal):
    #     query = '''
    #           query {
    #               file(token: "{token}",
    #                     key:"{key}") {
    #                 key
    #                 fileExtension
    #                 fileLocal
    #                 link
    #               }
    #             }
    #         '''
    #     query = query.replace('{key}', key)
    #     response = api_call(kraken, url, query=query)
    #     response = json.loads(response)
    #     link = response['data']['file']['link']
    #     fileLocal = response['data']['file']['fileLocal']
    #
    #     # TODO: Hacer comparacion de version, fecha o tamaño.
    #     if not os.path.exists(fileLocal):
    #         down = Download(kraken)
    #         down.download_file(link, fileLocal)
    #     extension = response['data']['file']['fileExtension']
    #     extension = extension.replace('.', '')

    _, extension = os.path.splitext(fileLocal)
    extension = extension.replace('.', '')

    message = {}
    print('uuid ==================================== >>>>>>>>>>>>>>>>>>>', uuid)
    if uuid is not None and uuid != '':
        print('uuid ============>>>>>>>>>>>>>>>>>>======================== >>>>>>>>>>>>>>>>>>>', uuid)
        message['uuid'] = uuid
    else:
        print('uuid ==============xxxxxxxxxxxxxxxxxxxxx====================== >>>>>>>>>>>>>>>>>>>', uuid)
        uuid = None




    if extension in settings.EXTENSION_MAYA:
        if kraken.dcc_is_activated('maya') and uuid is not None:
            print('Comando por ws')

            message['dcc'] = 'maya'
            # message['command'] = f'import maya; maya.cmds.file("{fileLocal}", open=True)'
            message['command'] = f'import maya; maya.cmds.file("{fileLocal}", open=True, force=True)'

            print(message)
            kraken.kraken_manager_client.send_message(message)
        else:
            print('Comando por os.system')
            maya = kraken.maya
            subprocess.run([maya, '-file', fileLocal])

    elif extension in settings.EXTENSION_BLENDER:
        print('== kn 2.c orders.py --- blender.open')
        if kraken.dcc_is_activated('blender') and uuid is not None:
            print('Comando por ws')

            message['dcc'] = 'blender'
            message['command'] = f"import bpy; bpy.ops.wm.open_mainfile(filepath='{fileLocal}')"
            print('message>>>>>>>>>>>>>>>>>', message, '======>>>>>>>>>>>>>>>>>>>>')
            kraken.kraken_manager_client.send_message(message)
        else:
            print('Comando por os.system')
            blender = kraken.blender

            subprocess.run([blender, fileLocal])

    elif extension in settings.EXTENSION_NUKE and uuid is not None:
        print('== kn 2.c orders.py --- nuke.open')
        if kraken.dcc_is_activated('nuke'):
            print('Comando por ws')

            message['dcc'] = 'nuke'
            message['command'] = f'import nuke; nuke.scriptOpen("{fileLocal}")'
            print(message)
            kraken.kraken_manager_client.send_message(message)
        else:
            print('Comando por os.system')
            nuke = kraken.nuke
            subprocess.run([nuke, fileLocal])
        pass

    elif extension in settings.EXTENSION_HOUDINI:
        print('== kn 2.c orders.py --- nuke.open')
        if kraken.dcc_is_activated('houdini') and uuid is not None:
            print('Comando por ws')

            message['dcc'] = 'houdini'
            message['command'] = f'import hou; hou.hipFile.load("{fileLocal}", suppress_save_prompt=True, ignore_load_warnings=True)'
            print(message)
            kraken.kraken_manager_client.send_message(message)
        else:
            print('Comando por os.system')
            houdini = kraken.houdini
            subprocess.run([houdini, fileLocal])
        pass

    elif extension in settings.EXTENSION_UNREAL:
        print('== kn 2.c orders.py --- unreal.open')
        if kraken.dcc_is_activated('unreal') and uuid is not None:
            print('Comando por ws')

            message['dcc'] = 'unreal'
            message['command'] = f'import unreal; unreal.EditorLoadingAndSavingUtils.load_map("{fileLocal}")'
            print(message)
            kraken.kraken_manager_client.send_message(message)
        else:
            print('Comando por os.system')
            unreal = kraken.unreal
            subprocess.run([unreal, fileLocal])
        pass

    elif extension in settings.EXTENSION_PHOTOSHOP:
        print('== kn 2.c orders.py --- photoshop.open')

        print('Comando por os.system')
        #unreal = kraken.unreal
        import win32com.client
        app = win32com.client.Dispatch("Photoshop.Application")
        app.Open(fileLocal)

def pedir_wip(kraken, folder_key):
    query = '''
        mutation{
            newWip(token: "{token}",
                    key: "{folder_key}"){
                file{
                    uploadLink
                    key
                    fileLocal
                }
            }
        }
        '''
    query = query.replace('{folder_key}', folder_key)

    folder_response = api_call(kraken, kraken.http_url, query=query)
    folder_response = json.loads(folder_response)
    uploadLink = folder_response['data']['newWip']['file']['uploadLink']
    file_key = folder_response['data']['newWip']['file']['key']
    fileLocal = folder_response['data']['newWip']['file']['fileLocal']
    return uploadLink, file_key, fileLocal

# from src.operations.download import file_exist
# def comando_save_as(kraken, fileLocal):
#     if file_exist(fileLocal):
#         pass
#     message = {}
#     message['dcc'] = 'maya'
#     message['command'] = f'import maya; maya.cmds.file(rename="{fileLocal}"); maya.cmds.file(save=True, type="mayaBinary")'
#
#     print(message)
#     kraken.kraken_manager_client.send_message(message)


def upload_file(kraken, fileLocal, uploadLink, file_key):
    with open(fileLocal, 'rb') as file_data:
        response: requests.Response = requests.put(uploadLink, data=file_data)

        if response.status_code == 200:
            print(' upload finnish')
        else:
            print(' upload error:', response.text)

    fileSize = os.path.getsize(fileLocal)
    upload_completed(kraken, file_key, str(fileSize))
    kraken.print_console_ws.emit('    Uploaded Wip File: ' + str(fileLocal))


def upload_completed(kraken, file_key, fileSize):
    query = '''
        mutation{
            completedFile(token: "{token}",
                    key: "{file_key}",
                    fileSize: {fileSize}){
                    file{
                      key
                    }
            }
        }
        '''
    query = query.replace('{file_key}', file_key)
    query = query.replace('{fileSize}', fileSize)

    folder_response = api_call(kraken, kraken.http_url, query=query)
    return True


