def nuke_import_exr(kraken, folderLocal, code, input_amount, sequence_name, resolution, width, height, custom_format_name):
    exr_script = f"""
import nuke

# URL a la secuencia de imágenes
url_secuencia = "{folderLocal}{code}/frames/{sequence_name}"
first_frame = 1001
last_frame = {1000 + int(input_amount)}  # Asegúrate de ajustar estos valores según la secuencia
orig_first_frame = 1001
orig_last_frame = {1000 + int(input_amount)}
resolution = "{resolution}"  # La resolución pasada como '2400x1300'

# Desglosar la resolución en ancho y alto


# Crear un formato personalizado en Nuke con la resolución dada

custom_format = nuke.addFormat(f"{width} {height} 1.0 {custom_format_name}")

# Crea el nodo Read y establece los parámetros
nodo_read = nuke.createNode("Read")
nodo_read["file"].setValue(url_secuencia)
nodo_read["first"].setValue(first_frame)
nodo_read["last"].setValue(last_frame)
nodo_read["origfirst"].setValue(orig_first_frame)
nodo_read["origlast"].setValue(orig_last_frame)

# Ajustar el rango de frames del proyecto y el formato
nuke.root()["first_frame"].setValue(first_frame)
nuke.root()["last_frame"].setValue(last_frame)
nuke.root()["format"].setValue(custom_format.name())


print(f'Formato de video personalizado establecido a: {width}x{height}')
    """
    return exr_script


def nuke_import_mov(file_path, resolution, width, height, custom_format_name, first_frame, last_frame):
    mov_script = f"""
import nuke

# Ruta al archivo de video .mov
video_file_path = "{file_path}"
resolution = "{resolution}"  # La resolución pasada como '2400x1300'

# Crear un formato personalizado en Nuke con la resolución dada
custom_format = nuke.addFormat(f"{width} {height} 1.0 {custom_format_name}")

# Ajustar el formato del proyecto en Nuke
nuke.root()["format"].setValue(custom_format.name())

# Crea el nodo Read y establece los parámetros para el archivo .mov
nodo_read = nuke.createNode("Read")
nodo_read["file"].setValue(video_file_path)
nodo_read["first"].setValue({first_frame})
nodo_read["last"].setValue({last_frame})
nodo_read["origfirst"].setValue({first_frame})
nodo_read["origlast"].setValue({last_frame})

print(f'Archivo .mov importado: {file_path}')
print(f'Formato de video personalizado establecido a: {width}x{height}')
print(f'Rango de frames establecido de {first_frame} a {last_frame}')
    """
    return mov_script