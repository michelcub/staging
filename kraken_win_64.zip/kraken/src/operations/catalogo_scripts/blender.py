def get_all_objects():
    return """
import bpy

# Obtén una referencia a la escena actual
scene = bpy.context.scene

# Obtén la lista de objetos seleccionados en la escena actual
selected_objects = bpy.context.selected_objects

# Itera a través de la lista de objetos seleccionados e imprime sus nombres
for obj in selected_objects:
    print("Objeto seleccionado:", obj.name)
"""