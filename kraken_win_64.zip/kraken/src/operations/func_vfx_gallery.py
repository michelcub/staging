# -*- coding: utf-8 -*-

import os
import shutil
import json
import importlib
import threading
import ast

from src.api.graphql import api_call
from src.operations.download import Download
from src.operations.catalogo_scripts import nuke
import src.operations.video as video


def run(kraken, path, key):
    # hacerlo en un hilo separado
    hilo = threading.Thread(target=import_new_vfx_secuence, args=(kraken, path, key))
    hilo.start()
    hilo.join()



def import_new_vfx_secuence(kraken, path, key):
    importlib.reload(video)

    url = kraken.http_url
    query = '''
          query {
              element(token: "{token}",
                    key:"{key}") {
                key
                name
                folderCloud
                folderLocal
                videoCloud
                imageCloud
                code
                data
                folders {
                    key
                }
              }
            }
        '''
    # query = query.replace('{token}', kraken.token_auth)
    query = query.replace('{key}', key)
    response = api_call(kraken, url, query=query, token=kraken.token_auth)
    response = json.loads(response)

    folderLocal = response['data']['element']['folderLocal']
    upload_path_video = response['data']['element']['videoCloud']
    upload_path_image = response['data']['element']['imageCloud']
    code = response['data']['element']['code']
    folder = response['data']['element']['folders'][0]
    folder_key = folder['key']

    compress_method = 'black'
    try:
        response_dict = ast.literal_eval(response['data']['element']['data'])
        compress_method = response_dict.get('compress_method')
    except:
        pass

    if not folderLocal:
        folderLocal = None

    folder_output_path = folderLocal
    video_name = code + '.webm'
    ruta_webm = video.compress_sequence_video(kraken, path, folder_output_path, video_name, fps=30, compress_method=compress_method)

    if os.path.isdir(path):
        jpg_converted = video.convert_exr_to_jpg_image(path, folderLocal, kraken)

        if jpg_converted:
            metadata = video.extract_jpg_metadata(jpg_converted, kraken, key)
    if path.endswith('.mov'):
        jpg_converted = video.convert_mov_to_jpg_image(path,folder_output_path, kraken, key)
        if jpg_converted:
            frames = video.get_video_frame_count(kraken,path)
            metadata = video.extract_jpg_metadata(jpg_converted, kraken, key, frames)
            # print(metadata)

    upload = Download(kraken)
    if ruta_webm:
        upload.upload_file_link(ruta_webm, upload_path_video)
    #if ruta_webm and ruta_gif:
        #upload.upload_file_link(ruta_gif, upload_path_image)



    kraken.print_console_ws.emit('    Copy files to library: ' + str(folder_output_path))

    folder_output_path = folder_output_path.replace('\\', '/')



    if path.endswith('.mov'):
        mov_copy(path, folder_output_path, code)
    else:
        secuence_copy(path, folder_output_path + 'frames', code)

    # ------ Subir los ficheros a S3



# -------------------------------------





def secuence_copy(folder_origen, folder_dest, name):
    if not os.path.exists(folder_dest):
        os.makedirs(folder_dest)

    contador = 1001

    if os.path.isfile(folder_origen):
        folder_origen = os.path.dirname(folder_origen)

    if os.path.isdir(folder_dest):
        # Copiar el contenido de la carpeta origen a la carpeta destino con nombres secuenciales
        for archivo in os.listdir(folder_origen):
            _, extension = os.path.splitext(archivo)
            ruta_origen = os.path.join(folder_origen, archivo)
            nombre_nuevo = f"{name}_{contador:04d}{extension}"  # Modifica 'ext' con la extensión real

            ruta_destino = os.path.join(folder_dest, nombre_nuevo)
            # if video.file_exist(ruta_destino):
            #     os.remove(ruta_destino)
            # shutil.copy2(ruta_origen, ruta_destino)  # copy2 conserva metadatos como timestamps
            # contador += 1

            if not video.file_exist(ruta_destino):
                shutil.copy2(ruta_origen, ruta_destino)  # copy2 conserva metadatos como timestamps
            contador += 1

def mov_copy(folder_origen, folder_dest, name):

    if not os.path.exists(folder_dest):
        os.makedirs(folder_dest)
    mov_dir = folder_origen
    contador = 1001

    if os.path.isfile(folder_origen):
        folder_origen = os.path.dirname(folder_origen)

    if os.path.isdir(folder_dest):
        # Copiar el contenido de la carpeta origen a la carpeta destino con nombres secuenciales
        for archivo in os.listdir(folder_origen):
            _, extension = os.path.splitext(archivo)
            ruta_origen = os.path.join(folder_origen, archivo)
            if extension == '.mov' and archivo == os.path.basename(mov_dir):
                nombre_nuevo = f"{name}{extension}"  # Modifica 'ext' con la extensión real
            else:
                nombre_nuevo = archivo
            ruta_destino = os.path.join(folder_dest,'frames', nombre_nuevo)
            # if video.file_exist(ruta_destino):
            #     os.remove(ruta_destino)
            # shutil.copy2(ruta_origen, ruta_destino)  # copy2 conserva metadatos como timestamps
            # contador += 1

            if not video.file_exist(ruta_destino):
                shutil.copy2(ruta_origen, ruta_destino)  # copy2 conserva metadatos como timestamps
            contador += 1

def element_import_nuke(kraken, response):
    key = response['key']
    folderLocal = response['folderLocal']
    folderLocal = folderLocal.replace('\\', '/')
    object_data = ast.literal_eval(response['data'])
    input_amount = object_data['input_amount']
    input_from = object_data['input_from']
    code = response['code']
    resolution = object_data['resolution']
    width, height = resolution.split('x')
    custom_format_name = "Custom_Format_" + resolution

    if not input_from.endswith('.mov'):
        kraken.print_console_ws.emit('    Import Nuke Library ' + str(input_amount) + ' ' + str(folderLocal))
        sequence_name = response['code'] + '_%04d.exr'
        response['command'] = nuke.nuke_import_exr(kraken, folderLocal, code, input_amount, sequence_name, resolution, width, height, custom_format_name)
        response['dcc'] = 'nuke'

    elif input_from.endswith('.mov'):
        file_path = os.path.join(folderLocal, code + "/", 'frames/', code + '.mov')
        kraken.print_console_ws.emit('    Import Nuke Library ' + str(folderLocal))
        first_frame = 1
        last_frame = int(object_data['frames'])
        response['command'] = nuke.nuke_import_mov(file_path, resolution, width, height, 'custom_format_name', first_frame, last_frame)
        response['dcc'] = 'nuke'

    kraken.kraken_manager_client.send_message(response)
    print('enviado mensaje a manager')
