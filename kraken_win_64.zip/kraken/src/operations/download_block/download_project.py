# -*- coding: utf-8 -*-

import json
import threading

from src.api.graphql import api_call
from src.performance.threads import Thread_Download


class Download_project(Thread_Download):
    def download_project(self, key, file_include, file_exclude):
        if threading.active_count() < self.kraken.thread_amount:
            print('Wake up th')
            self.threader_up(amount=self.kraken.thread_amount - threading.active_count())

        self.count_thread_download()
        print('download_project', key)
        full_list = self.full_list(key)
        for asset in full_list:
            # print('asset', asset['name'])
            for task in asset['tasks']:
                # print('    task', task['key'])
                # print('    task')
                # for folder in self.folder_list(task['key']):
                for folder in task['folders']:
                    # print('        folder', task['folder'])
                    # print('        folder')
                    for file in folder['files']:
                        # print('            file', file['fileLocal'])
                        # self.order_file(file)

                        """
                        Discriminamos si esta para inclusion o no
                        TODO: Esto debe estar integrado en al api para que no pueda ser alterado por el usuario
                        """

                        send_file = True
                        if file_include:
                            include_list = file_include.split(" ")
                            send_file = False
                            for tag in include_list:
                                if tag in file['fileLocal']:
                                    print('In-clude for ', tag)
                                    send_file = True
                                    break
                        if file_exclude:
                            # Exclusion expresion
                            exclude_list = file_exclude.split(" ")
                            for tag in exclude_list:
                                if tag in file['fileLocal']:
                                    print('Ex-clude for ', tag)
                                    send_file = False
                                    break

                        if send_file == True:
                            filePath_Dream = file['link'] + '>>>>>>>>' + file['fileLocal']
                            self.kraken.q.put(filePath_Dream)

        self.kraken.q.join()
        self.kraken.print_console_ws.emit('  Download Completed')
        print('------------ DOWNLOAD COMPLETED ------------')
        return True

    def full_list(self, key):
        query = '''
            query {
                project(token: "{token}", key:"{key}") {
                    relAssetProject {
                        name
                        tasks{
                            folders{
                                files{
                                    fileLocal
                                    link
                                }
                            }
                        }
                    }
                }
            }
            '''
        # print(query)
        query = query.replace('{key}', key)
        response = api_call(self.kraken, self.url, query=query, token=self.token_auth)
        response = json.loads(response)
        task_list = response['data']['project']['relAssetProject']
        return task_list
