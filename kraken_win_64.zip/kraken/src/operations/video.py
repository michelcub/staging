# -*- coding: utf-8 -*-
import os
import subprocess
import cv2
import re
import requests
import json

from moviepy.editor import *
from PIL import Image
from PIL import ExifTags

from src.operations.download import file_exist
from src.api.graphql import api_call

def reSizeImageWebp(imagePath):
    if not imagePath.split('.')[-1].lower() in ['jpg', 'jpeg', 'png', 'tiff', 'tif', 'tga', 'bmp', 'webp']:
        return False
    im = Image.open(imagePath)

    resolution_list = {
        '_XXS.webp': 60,
        '_XS.webp': 140,
        '_S.webp': 500,
        '_M.webp': 1200,
        '_L.webp': 1920
    }

    for name, sizeX in resolution_list.items():
        imagePath_Out = str(imagePath) + str(name)

        sizeY = int(sizeX * (float(im.height) / float(im.width)))
        im_resized = im.resize((int(sizeX), int(sizeY)))
        im_resized.save(imagePath_Out, format="webp")
    im.close()


def save_image_from_video(media_file):
    # try:
    image_name = media_file + '.jpg'

    clip = VideoFileClip(media_file)
    clip.save_frame(image_name, t=0.5)
    clip.reader.close()

    reSizeImageWebp(image_name)
    # except:
    #     return False


def compress_video(media_file):
    video = cv2.VideoCapture(media_file)
    frame_width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    video2 = cv2.VideoWriter(media_file + '.mp4', cv2.VideoWriter_fourcc(*'X264'), int(video.get(cv2.CAP_PROP_FPS)), (frame_width, frame_height))
    while True:
        has_frame, frame = video.read()
        if not has_frame:
            break

        video2.write(frame)

        cv2.imshow('frame', frame)
        key = cv2.waitKey(3)
        if key == 27:
            print('Pressed Esc')
            break

    video.release()
    video2.release()
    cv2.destroyAllWindows()



def compress_sequence_video(kraken, folder_path, folder_output_path, video_name='video_out.webm', fps=30, compress_method='black'):
    try:
        name = ''
        extension = ''

        print('folder_path: --------------------------------------', folder_path)

        if os.path.isdir(folder_path):
            file_list = sorted(os.listdir(folder_path))
            first_file = file_list[0]

            first_file = first_file.replace('\\', '/')
            name, extension = os.path.splitext(first_file)
            print('name: --------------------------------------', name)
            file_name = name + extension

        if os.path.isfile(folder_path) and folder_path.endswith('.mov'):
            folder_path = folder_path.replace('\\', '/')
            print('folder_path: --------------------------------------', folder_path)
            name = os.path.basename(folder_path).split('.')[0]
            extension = '.mov'
            file_name = name + extension

        if folder_path.endswith('.R3D'):
            folder_path = folder_path.replace('\\', '/')
            print('folder_path: --------------------------------------', folder_path)
            name = os.path.basename(folder_path).split('.')[0]
            extension = '.R3D'
            file_name = name + extension

        # TODO: Datos adicionales
        # Resolucion
        # Alfa
        # Colors

        if os.path.isdir(folder_path):
            print('name: --------------------------------------', name)
            return convert_ffmpeg(kraken, folder_path, name, extension, folder_output_path, video_name, fps, crf=10, compress_method=compress_method)
        elif extension == '.mov':
            print('name: --------------------------------------', name)
            return convert_mov_to_webm(kraken, folder_path, name, extension, folder_output_path, video_name, fps, compress_method=compress_method)
        elif extension == '.R3D':
            print('name: --------------------------------------', name)
            return convert_r3d_to_webm(kraken, folder_path, extension, folder_output_path, video_name, fps, crf=10, compress_method=compress_method)

        #else:
            #return convert_cv2(kraken, folder_path, first_file, folder_output_path, video_name, fps)
    except Exception as e:
        kraken.print_console_ws.emit(f"Error compressing video: {e}")

def convert_cv2(kraken, folder_path, first_file, folder_output_path, video_name='video_out.mp4', fps=30):
    archivos = sorted(os.listdir(folder_path))
    img_path = os.path.join(folder_path, archivos[0])
    img = cv2.imread(img_path)
    alto, ancho, _ = img.shape

    codec = cv2.VideoWriter_fourcc(*'mp4v')  # Codec para MP4
    output_path = folder_output_path + video_name
    video_salida = cv2.VideoWriter(output_path, codec, fps, (ancho, alto))

    for archivo in archivos:
        img_path = os.path.join(folder_path, archivo)
        img = cv2.imread(img_path)
        video_salida.write(img)

    video_salida.release()
    # cv2.destroyAllWindows()

    return output_path


def convert_ffmpeg(kraken, folder_exr, name, extension, folder_output_path, video_name='salida.webm', fps=30, crf=18,
                   compress_method='black'):
    try:
        file_name = name
        expresion_regular = r'(\d+)$'
        print('file_name: --------------------------------------', file_name)
        parte_numerica = re.search(expresion_regular, file_name)
        if parte_numerica:
            primer_valor = parte_numerica.group()
            longitud_numerica = len(parte_numerica.group())
            expresion_regular = file_name.replace(parte_numerica.group(), f"%0{longitud_numerica}d")
        else:
            primer_valor = '0'

        files = os.path.join(folder_exr, expresion_regular + extension).replace('\\', '/')

        # Crear carpeta de salida si no existe
        if not os.path.exists(folder_output_path):
            os.makedirs(folder_output_path)
            print(f"Carpeta de salida creada: {folder_output_path}")

        output_path = os.path.join(folder_output_path, video_name).replace('\\', '/')
        if os.path.exists(output_path):
            os.remove(output_path)

        alfa = os.path.join(kraken.pwd, 'src', 'operations',
                            'alfa_black.png' if compress_method == 'black' else 'alfa_white.png')
        ancho_deseado = 560

        comando = [
            kraken.ffmpeg_exe,
            '-i', alfa,
            '-start_number', primer_valor,
            '-r', str(fps),
            '-i', files,
            '-filter_complex',
            f"[0:v]scale={ancho_deseado}:-1[bg];"
            f"[1:v]eq=gamma=1.5:brightness=0.08:contrast=1:saturation=3,scale={ancho_deseado}:-1[outv];"
            "[bg][outv]overlay=(W-w)/2:(H-h)/2",
            '-crf', str(crf),
            '-c:v', 'libvpx-vp9',
            '-pix_fmt', 'yuva420p',
            '-auto-alt-ref', '0',
            output_path
        ]

        proceso = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        salida, error = proceso.communicate()

        if proceso.returncode != 0:
            print(error.decode('utf-8'))

        return output_path
    except Exception as e:
        kraken.print_console_ws.emit(f"Error converting EXR to WebM: {e}")

def convert_mov_to_webm(kraken, folder_input_path, input_video_name, extension, folder_output_path, video_name='salida.webm', fps=30, crf=18, compress_method='black'):
    try:
        # Asegurarse de que las rutas de entrada y salida son correctas
        input_path = folder_input_path.replace('\\', '/')
        output_path = os.path.join(folder_output_path, video_name).replace('\\', '/')
        alfa_path = os.path.join(kraken.pwd, 'src', 'operations', 'alfa_black.png' if compress_method == 'black' else 'alfa_white.png').replace('\\', '/')

        if not os.path.isfile(input_path):
            print(f"Error: El archivo de entrada no existe - {input_path}")
            return

            # Verificar si existe el archivo de salida y eliminar si es necesario
        if os.path.exists(output_path):
            os.remove(output_path)

        if not os.path.exists(folder_output_path):
            os.makedirs(folder_output_path)
            print(f"Carpeta de salida creada: {folder_output_path}")

            # Comando FFmpeg para convertir el video MOV a WebM
        comando = [
            kraken.ffmpeg_exe,
            '-i', input_path,  # Ruta del video de entrada
            '-loop', '1',  # Loop para la imagen de fondo
            '-i', alfa_path,  # Ruta de la imagen de fondo
            '-filter_complex',
            "[1:v]scale=560:-1,loop=-1:1:0,setpts=N/FRAME_RATE/TB[bg];"  # Escalar el fondo y loop para coincidir con la duración del video
            "[0:v]scale=560:-1,eq=brightness=0.3:contrast=1.5:saturation=3,unsharp=lx=3:ly=3:la=0.5[v];"  # Escalar video, ajustar saturación y nitidez
            "[bg][v]overlay=(W-w)/2:(H-h)/2:shortest=1[out]",  # Colocar el video sobre el fondo
            '-map', '[out]',  # Mapear el stream de salida con los filtros aplicados
            '-c:v', 'libvpx-vp9',  # Códec de video
            '-r', str(fps),  # Frame rate
            '-crf', str(crf),  # CRF
            '-b:v', '0',  # Bitrate de video (0 para CRF)
            '-an',  # Eliminar el audio
            '-pix_fmt', 'yuva420p',  # Formato de píxeles con canal alfa
            output_path  # Archivo de salida
        ]

        # Ejecutar el comando FFmpeg
        proceso = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = proceso.communicate()

        # Manejo de errores
        if proceso.returncode != 0:
            print(f"FFmpeg Error: {stderr.decode('utf-8')}")
        else:
            print(f"Conversión exitosa. Salida en: {output_path}")

        return output_path

    except Exception as e:
        kraken.print_console_ws.emit(f"Error converting MOV to WebM: {e}")

def convert_r3d_to_webm(kraken, folder_input_path, input_video_name, folder_output_path, video_name='salida.webm', fps=30, crf=18, compress_method='black'):
    # Construir las rutas de entrada y salida
    input_path = folder_input_path
    output_path = os.path.join(folder_output_path, video_name).replace('\\', '/')
    alfa_path = os.path.join(kraken.pwd, 'src', 'operations', 'alfa_black.png' if compress_method == 'black' else 'alfa_white.png').replace('\\', '/')

    # Asegurarse de que el archivo de entrada existe
    if not os.path.isfile(input_path):
        print(f"Error: El archivo de entrada no existe - {input_path}")
        return

    # Crear la carpeta de salida si no existe
    if not os.path.exists(folder_output_path):
        os.makedirs(folder_output_path)
        print(f"Carpeta de salida creada: {folder_output_path}")

    print('input_path:', input_path)

    # Comando FFmpeg para convertir el video R3D a WebM
    comando = [
        kraken.ffmpeg_exe,
        '-i', input_path,  # Ruta del video de entrada
        # Agregar más configuraciones específicas para el archivo R3D si es necesario
        '-c:v', 'libvpx-vp9',  # Códec de video
        '-r', str(fps),  # Frame rate
        '-crf', str(crf),  # CRF
        '-b:v', '0',  # Bitrate de video (0 para CRF)
        '-an',  # Eliminar el audio
        output_path  # Archivo de salida
    ]

    # Ejecutar el comando FFmpeg
    proceso = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proceso.communicate()

    # Manejar errores
    if proceso.returncode != 0:
        print(f"FFmpeg Error: {stderr.decode('utf-8')}")
    else:
        print(f"Conversión exitosa. Salida en: {output_path}")

    return output_path


def convertir_mp4_a_gif_ffmpeg(kraken, ruta_video):
    try:
        ruta_gif = ruta_video.replace('.mp4', '.gif')
        if file_exist(ruta_gif):
            os.remove(ruta_gif)
        comando = [
            kraken.ffmpeg_exe,
            '-i', ruta_video,
            '-vf', 'fps=25,scale=320:-1:flags=lanczos',
            '-c:v', 'gif',
            '-b:v', '5M',
            # '-colors', '128',
            ruta_gif
        ]
        # print(comando)
        proceso = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        salida, error = proceso.communicate()
        # print(proceso)
        if proceso.returncode != 0:
            print(error.decode('utf-8'))
        return ruta_gif
    except Exception as e:
        kraken.print_console_ws.emit(f"Error converting to GIF: {e}")


def convertir_mp4_a_low_ffmpeg(kraken, ruta_video):
    ruta_low = ruta_video.replace('.mp4', '_low.mp4')
    if file_exist(ruta_low):
        os.remove(ruta_low)
    comando = [
        kraken.ffmpeg_exe,
        '-i', ruta_video,
        '-vf', 'scale=400:-1',
        '-c:v', 'libx264',
        '-crf', '20',
        '-preset', 'medium',
        '-c:a', 'copy',
        ruta_low
    ]
    # print(comando)
    proceso = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    salida, error = proceso.communicate()
    # print(proceso)
    if proceso.returncode != 0:
        print(error.decode('utf-8'))
    return ruta_low

def convert_exr_to_jpg_image(exr_folder_path, folder_output_path, kraken):
    exr_file_path = ''
    jpg_file_path = ''
    exr_folder_path = exr_folder_path.replace('\\', '/')
    if os.path.isdir(exr_folder_path):
        list_exr = os.listdir(exr_folder_path)
        middle_index = len(list_exr) // 2
        exr_file_path = os.path.join(exr_folder_path, list_exr[middle_index])
        jpg_file_path = os.path.join(folder_output_path, list_exr[middle_index].replace('.exr', '.jpg'))
    command = [
        kraken.ffmpeg_exe,
        '-i', exr_file_path,
        jpg_file_path
    ]

    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError:
        print(f"Error al convertir {exr_file_path} a JPG")
        kraken.print_console_ws.emit(f"Error converting {exr_file_path} to JPG")
        return None

    return jpg_file_path

def convert_mov_to_jpg_image(input_path, output_folder, kraken, key):
    # Ruta completa del archivo JPG de salida
    output_file_path = os.path.join(output_folder, 'output.jpg')
    if os.path.exists(output_file_path):
        os.remove(output_file_path)
    # Comando FFmpeg para convertir el video a una imagen JPG
    command = [
        kraken.ffmpeg_exe,
        '-i', input_path,
        '-q:v', '2',  # Calidad de la imagen JPG (ajustable)
        '-frames:v', '1',
        output_file_path
    ]

    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError:
        print(f"Error al convertir {input_path} a imagen JPG")
        return None

    return output_file_path


def extract_jpg_metadata(jpg_file_path, kraken, key, frames=None):
    try:
        image = Image.open(jpg_file_path)
        exif = image.getexif()
        metadata = {}

        # Convert EXIF tags to meaningful names
        for tag, value in exif.items():
            tag_name = ExifTags.TAGS.get(tag, f"EXIF_{tag}")
            metadata[tag_name] = value

        # Add image info
        metadata['mode'] = image.mode
        metadata['depth'] = image.getbands()
        metadata['format'] = image.format
        metadata['format_description'] = image.format_description
        metadata['palette'] = image.palette
        metadata['bit_depth'] = len(image.getbands()) * 8
        metadata['frames'] = frames
        # Add other data
        resolution = metadata['size'] = image.size
        metadata['filename'] = image.filename
        try:
            metadata['date_time'] = image.info['datetime']
        except KeyError:
            metadata['date_time'] = None

    except IOError:
        print(f"No se pudo abrir la imagen: {jpg_file_path}")
        return None

    query = '''
            mutation{
                updateElement(token: "{token}",
                              key: "{element_key}",
                              resolution: "{resolution}",
                              frames: "{frames}"){
                    element{
                        key
                    }
                }
            }
            '''

    resolution_str = f"{resolution[0]}x{resolution[1]}"
    query = query.replace('{resolution}', resolution_str)
    query = query.replace('{frames}', str(frames))
    query = query.replace('{element_key}', key)

    response = api_call(kraken, kraken.http_url, query=query, token=kraken.token_auth)

    # Enviamos la solicitud


    print('response: --------------------------------------', response)
    return metadata


import re
import subprocess

def get_video_frame_count(kraken, video_path):
    # Comando para obtener información del video con FFmpeg
    try:
        cmd = [kraken.ffmpeg_exe, '-i', video_path]

        # Ejecutar el comando y capturar la salida de error, donde FFmpeg imprime la información
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = process.communicate()

        # Decodificar la salida de error usando 'latin-1' para evitar UnicodeDecodeError
        decoded_err = err.decode('latin-1')

        # Buscar la cantidad de frames por segundo (FPS) usando una expresión regular
        match = re.search(r'(\d+(\.\d+)?) fps', decoded_err)
        if match:
            # Obtener la duración del video en segundos
            duration_match = re.search(r'Duration: (\d+):(\d+):(\d+\.\d+)', decoded_err)
            if duration_match:
                hours, minutes, seconds = map(float, duration_match.groups())
                total_seconds = hours * 3600 + minutes * 60 + seconds

                # Calcular el número total de fotogramas
                fps = float(match.group(1))
                total_frames = int(total_seconds * fps)
                print(f"Total frames: {total_frames}")
                return total_frames

        return None
    except Exception as e:
        kraken.print_console_ws.emit(f"Error to get fps: {e}")



def convert_video_to_jpeg_sequence(kraken, video_path, start_frame, end_frame, fps, resolution, save_path, filename_prefix):
    """
    Convierte un video a una secuencia de imágenes JPEG.

    Parámetros:
    - video_path: Ruta al archivo de video de entrada.
    - start_frame: Frame de inicio para comenzar la conversión.
    - end_frame: Último frame para la conversión.
    - fps: Frames por segundo en el resultado.
    - resolution: Resolución de salida de las imágenes, en formato 'anchoxalto' (ej. '640x480').
    - save_path: Ruta de la carpeta donde se guardarán las imágenes.
    - filename_prefix: Prefijo para el nombre de los archivos de imagen.
    """

    # Calcula la duración en segundos entre el frame de inicio y el de salida basado en los FPS
    duration_frames = end_frame - start_frame
    duration_seconds = duration_frames / float(fps)

    # Calcula el tiempo de inicio en formato hh:mm:ss
    start_seconds = start_frame / float(fps)
    start_time = f"{int(start_seconds // 3600)}:{int((start_seconds % 3600) // 60)}:{start_seconds % 60}"
    if not os.path.exists(f"{save_path}exportation/{filename_prefix}"):
        os.makedirs(f"{save_path}exportation/{filename_prefix}")
    # Comando ffmpeg para convertir el video
    command = [
        kraken.ffmpeg_exe,
        '-ss', start_time,  # Tiempo de inicio
        '-t', str(duration_seconds),  # Duración
        '-i', video_path,  # Archivo de entrada
        '-vf', f"fps={fps},scale={resolution}",  # Filtro de video para FPS y resolución
        '-q:v', '2',  # Calidad de la imagen, valores más bajos significan mejor calidad
        f"{save_path}exportation/{filename_prefix}/{filename_prefix}_%04d.jpg"  # Ruta de salida y nombre de archivo
    ]

    # Ejecuta el comando
    try:
        subprocess.run(command, check=True)
        print("Conversión completada exitosamente.")
    except subprocess.CalledProcessError as e:
        print("Error durante la conversión del video:", e)
        kraken.print_console_ws.emit(f"Error during video conversion: {e}")


def cut_video(video_in, output, start_frame_number, end_frame_number):
    file_exist(output)

    cap = cv2.VideoCapture(video_in)
    fps = cap.get(cv2.CAP_PROP_FPS)
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(start_frame_number))

    # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    fourcc = cv2.VideoWriter_fourcc(*'X264')
    # fourcc = cv2.VideoWriter_fourcc(*'avc1')
    out = cv2.VideoWriter(output, fourcc, fps, (int(cap.get(3)), int(cap.get(4))))
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        current_frame = cap.get(cv2.CAP_PROP_POS_FRAMES)
        if current_frame > int(end_frame_number):
            break
        out.write(frame)

    cap.release()
    out.release()



def call_webhook(enpoint, token, message):
    response = requests.post(enpoint + token + '/', json={'data': message})
    response_token = response.text
    response_token = json.loads(response_token)
    return response_token
