import importlib

from src.operations.catalogo_scripts import blender



def dcc_mockup(kraken, response):
    if response['dcc'] == 'blender':
        blender_mockup(kraken, response)



def blender_mockup(kraken, response):
    importlib.reload(blender)
    print('BLENDER MOCKUP')
    print(response)
    if response['action'] == 'get_objects':
        command = blender.get_all_objects()
        print(response)
        kraken.kraken_manager_client.send_message({"type": "hydra.message", "message": "Ejecutar codigo", "dcc": "blender", "order": "execute_command", "command": command})
