import sqlite3
import json

class KrakenDB:
    def __init__(self):
        self.db_name = 'kraken.db'

        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()


        #cramos la tabla si no existe
        self.create_task_queue_table()
        #reseteamos el status de las tareas cada ves que se instancie la clase
        self.reset_status()
        #cerramos conecxion
        self.close()

    def create_connection(self):
        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()

    def create_task_queue_table(self):
        self.create_connection()

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS task_queue (
                id INTEGER PRIMARY KEY,
                data TEXT,
                status TEXT CHECK(status IN ('pending', 'processing', 'completed', 'failed')),
                type TEXT CHECK(type IN ('upload', 'download')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                folder_key TEXT,
                file_key TEXT,
                upload_link TEXT,
                completed BOOLEAN DEFAULT FALSE
            )
        ''')
        self.conn.commit()
        self.close()

    def parse_data_to_json(self, data):
        print(data)
        data_parsed = []
        for register in data:
            data_parsed.append({
                "id": register[0],
                "data": json.loads(register[1]),
                "status": register[2],
                "type": register[3],
                "created_at": register[4],
                "folder_key": register[5],
                "file_key": register[6],
                "upload_link": register[7]
            })
        return data_parsed

    def insert_task(self, data):
        self.create_connection()
        self.cursor.execute('INSERT INTO task_queue (data, status) VALUES (?, ?)', (data, 'pending'))
        self.conn.commit()
        self.close()

    def insert_group_task(self, data_list, task_type=None, folder_key=None, file_key=None, upload_link=None):
        self.create_connection()
        tasks = [(json.dumps(data), 'pending', task_type, folder_key, file_key, upload_link) for data in data_list]
        self.cursor.executemany('INSERT INTO task_queue (data, status, type, folder_key, file_key, upload_link) VALUES (?, ?, ?, ?, ?, ?)', tasks)
        self.conn.commit()
        self.close()

    def get_pending_task(self):
        self.create_connection()
        self.cursor.execute('SELECT * FROM task_queue WHERE status = ? AND upload_link = Null', ('pending',))
        tasks = self.cursor.fetchall()
        self.close()
        return tasks

    def get_pending_task_by_type(self, task_type):
        self.create_connection()
        self.cursor.execute('SELECT * FROM task_queue WHERE status = ? AND type = ?', ('pending', task_type))
        tasks = self.cursor.fetchall()
        self.close()
        return tasks

    def fetch_pending_group_tasks(self, limit=200):
        self.create_connection()
        self.cursor.execute(f'''
            SELECT id, data, status, type, created_at 
            FROM task_queue 
            WHERE status = 'pending' 
            ORDER BY created_at 
            LIMIT {200}
        ''')
        tasks = self.cursor.fetchall()
        self.close()
        return tasks

    def fetch_pending_group_tasks_by_type(self, task_type, limit=200):
        self.create_connection()
        self.cursor.execute(f'''
            SELECT id, data, status, type, created_at, folder_key, file_key, upload_link
            FROM task_queue 
            WHERE status = 'pending' AND type = '{task_type}' AND upload_link IS NULL
            ORDER BY created_at 
            LIMIT {limit}
        ''')
        tasks = self.cursor.fetchall()
        self.close()
        return self.parse_data_to_json(tasks)

    def reset_status(self):
        self.create_connection()
        self.cursor.execute('UPDATE task_queue SET status = ?', ('pending',))
        self.conn.commit()
        self.close()

    def get_processing_task(self):
        self.create_connection()
        self.cursor.execute('SELECT * FROM task_queue WHERE status = ?', ('processing',))
        tasks = self.cursor.fetchall()
        self.close()
        return tasks

    def get_completed_task(self):
        self.create_connection()
        self.cursor.execute('SELECT * FROM task_queue WHERE status = ?', ('completed',))
        tasks = self.cursor.fetchall()
        self.close()
        return tasks

    def update_task_status(self, task_id, status):
        self.create_connection()
        self.cursor.execute('UPDATE task_queue SET status = ? WHERE id = ?', (status, task_id))
        self.conn.commit()
        self.close()

    def update_upload_links(self, links):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        for link in links:
            task_id = link['id']
            upload_link = link['upload_link']

            # Consulta SQL para actualizar el link de subida por ID
            query = '''
                UPDATE task_queue 
                SET upload_link = ?
                WHERE id = ?
            '''
            cursor.execute(query, (upload_link, task_id))

        # Confirmar la transacción y cerrar la conexión
        conn.commit()
        conn.close()


    def close(self):
        self.conn.close()
