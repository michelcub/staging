# -*- coding: utf-8 -*-

import os
import requests
# from PyQt5.QtCore import QProcess

from src.pipelinepro.settings import DEBUG

def ckeck_version(version):
    try:
        version = version.replace('.', '')
        if len(version) == 4:
            version = version[:3] + '0' + version[-1]
        version = int(version)
        if DEBUG:
            url = 'https://github.com/michelcub/staging/raw/main/version.txt'
        else:
            url = 'https://unlogic.io/static/kraken/version.txt'
        respuesta = requests.get(url)

        if respuesta.status_code == 200:
            last_version = int(respuesta.text)
        else:
            print(f"Error al leer el archivo. Código de estado: {respuesta.status_code}")
            return False
        # print(version, '>>>', last_version)
        if version < last_version:
            return True
        else:
            return False
    except:
        print('Cant check last version')
        return False


def download_update(installation_path):
    nombre_temporal = installation_path + "/update.py"
    if DEBUG:
        print(f"Descargando actualización en: {nombre_temporal}")
        url = 'https://github.com/michelcub/staging/raw/main/update.py'
    else:
        url = 'https://unlogic.io/static/kraken/update.py'

    # Descargar el archivo ZIP desde la URL
    response = requests.get(url, stream=True)

    # Guardar el contenido descargado en un archivo temporal
    with open(nombre_temporal, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:  # filter out keep-alive new chunks
                f.write(chunk)



def update_kraken_version(kraken, settings_ui=None):

    # # Descarga update
    download_update(kraken.pwd)
    # Rutas para el script del entorno virtual de Python y el script de actualización
    python_exe = os.path.join(os.path.dirname(kraken.pwd), 'venv_kraken', 'Scripts', 'python.exe').replace('\\', '/')
    update_script = os.path.join(os.path.dirname(kraken.pwd), 'kraken', 'update.py').replace('\\', '/')
    print(python_exe)
    print(update_script)



    # # Ruta y nombre para el archivo .bat temporal
    bat_file = os.path.join(os.path.dirname(kraken.pwd), 'run_update.bat')

    # # Crear el contenido del archivo .bat
    bat_content = f'@echo off\n'
    bat_content += f'set PYTHON_EXE="{python_exe}"\n'
    bat_content += f'set UPDATE_SCRIPT="{update_script}"\n'
    bat_content += f'%PYTHON_EXE% %UPDATE_SCRIPT%'


    # # Escribir el contenido al archivo .bat
    with open(bat_file, 'w') as file:
        file.write(bat_content)
    #
    # # Ejecutar el archivo .bat
    try:
        print(f"Ejecutando archivo .bat: {bat_file}")
        os.startfile(bat_file)
    except Exception as e:
        print(f"Error al ejecutar el archivo .bat: {e}")

    #
    # # ------- Rodrigo. Alternativa previa
    # # filepath = kraken.pwd + '/update.py'
    # # ruta_superior = os.path.dirname(kraken.pwd)
    # # venv = ruta_superior + '/venv_kraken/Scripts/python.exe'
    # # command = '"' + venv + '" "' + filepath + '"'
    # # QProcess().startDetached(command)

    # # ventana de settings
    if settings_ui:
        settings_ui.close()
    #
    # try:
    #     kraken.terminate_process_by_pid(kraken.pid_manager)
    # except:
    #     pass
    # # Cerrar aplicación
    kraken.ui.exit_app()
    print('Actualizando Kraken')


