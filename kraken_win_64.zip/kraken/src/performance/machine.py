# -*- coding: utf-8 -*-

import ctypes

def disk_space(workFolder):
    free_bytes = ctypes.c_ulonglong(0)
    ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(workFolder), None, None, ctypes.pointer(free_bytes))
    freeDisk = free_bytes.value / 1024 / 1024
    freeDisk = round(freeDisk / 1024, 1)
    return freeDisk