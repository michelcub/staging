import os
import sys
import threading
import requests
import json

from src.api.graphql import api_call

class Thread_Download:

    # -------------------- INICIADOR THREADS -------------------
    def threader_up(self, amount=20, threader_type='threader_download'):
        # print(' Hilos Activos', threading.active_count())
        for x in range(amount):
            t = threading.Thread(target=self.threader_download)
            if threader_type == 'threader_upload':
                t = threading.Thread(target=self.threader_upload)
            elif threader_type == 'threader_upload_episode':
                t = threading.Thread(target=self.threader_upload_episode)
            # else:
            #     t = threading.Thread(target=self.threader_download)
                # print(t.name)
            t.daemon = True
            t.start()
        # print(' Hilos Activos', threading.active_count())
    # ----------------------------------------------------------



    # =================== DOWNLOAD TH ===================
    def threader_download(self):
        while True:
            filePath_Queue = self.kraken.q.get()
            fragmentos = filePath_Queue.split('>>>>>>>>')
            file_link = fragmentos[0]
            file_path = fragmentos[1]

            self.execute_download_Job(file_link, file_path)
            self.kraken.q.task_done()

    def count_thread_download(self):
        amount = threading.active_count()
        print('th_DW: ', amount)
        return amount

    def execute_log_Job(self, filePath_Dream):
        pass
        with self.print_lock:
            print(threading.current_thread().name, filePath_Dream)
            pass


    def execute_download_Job(self, file_link, file_path):
        folder_path = os.path.dirname(file_path)
        if not os.path.exists(folder_path):
            # print('    Folder created')
            try: # Se deja porque puede que varios th esten haciendo lo mismo
                os.makedirs(folder_path)
            except:
                pass

        if not os.path.exists(file_path):
            print(file_path)
            try:
                response = requests.get(file_link)
                with open(file_path, 'wb') as archivo:
                    archivo.write(response.content)
                    # poner metadatos del original
                    # self.print_console('    Download', file_path)
                    # print('    Download', file_path)
            except:
                print('-- Error in download_file', file_path)

        self._running = False
        with self.kraken.print_lock:
            self.kraken.print_console_ws.emit('    Downloaded: ' + str(file_path))
            print('      Downloaded --> ' + str(file_path))
            # print(' Hilos Activos', threading.active_count())
            pass

    # ----------------------------------------------------------

    # ===================  MAIN DOWNLOAD
    def main_download_all(self, download_main_path):
        if threading.active_count() < self.thread_amount:
            self.threader_up(amount=self.thread_amount - threading.active_count())
        file_list = self.list_bucket_files(self.storage_bucket_name, main_path=download_main_path)
        for file in file_list:
            filePath_Dream = file.replace('project/' + self.project_key, '')
            if self.include:
                for expresion_in in self.include.split(','):
                    if expresion_in in file:
                        self.kraken.q.put(filePath_Dream)
            else:
                self.q.put(filePath_Dream)
        self.kraken.q.join()
        self.print_console_hydra.emit('  Download completed of ' + self.project_name)

    def file_exist_in_S3(self, filePath_Dream):
        path_cloud = self.path_local_to_cloud(filePath_Dream)
        try:
            obj = self.s3.head_object(Bucket=self.storage_bucket_name, Key=path_cloud)
            print('   File Size: ' + str(obj['ContentLength']))
            return obj['ContentLength']
        except self.s3 as exc:
            if exc.response['Error']['Code'] != '404':
                print('  ERROR 404: File not in S3', self.storage_bucket_name, path_cloud)
                raise
            print('  ERROR: File not in S3', self.storage_bucket_name, path_cloud)
            return False

    def list_bucket_files(self, bucket_name, main_path):
        my_bucket = self.r3.Bucket(bucket_name)
        file_list = []
        for file in my_bucket.objects.filter(Prefix=main_path):
            file_list.append(file.key)

        return file_list



class ProgressPercentage_download(object):
    def __init__(self, client, bucket, filename, print_console_hydra):
        self._filename = filename
        self._size = int(client.head_object(Bucket=bucket, Key=filename)['ResponseMetadata']['HTTPHeaders']['content-length'])
        self._seen_so_far = 0
        self._lock = threading.Lock()
        self.print_console_hydra = print_console_hydra

    def __call__(self, bytes_amount):
        # To simplify, assume this is hooked up to a single filename
        with self._lock:
            self._seen_so_far += bytes_amount
            percentage = (self._seen_so_far / self._size) * 100
            sys.stdout.write(
                "\r%s  %s / %s  (%.2f%%)" % (
                    self._filename, self._seen_so_far, self._size,
                    percentage))
            self.print_console_hydra.emit(
                "          %s / %s  (%.2f%%)" % (
                    self._seen_so_far, self._size,
                    percentage))
            sys.stdout.flush()





    # =================== UPLOAD TH ===================
    def threader_upload(self):
        while True:
            filePath_Queue = self.kraken.q_up.get()
            fragmentos = filePath_Queue.split('>>>>>>>>')
            folder_key = fragmentos[0]
            file_name = fragmentos[1]

            self.execute_upload_Job(folder_key, file_name)
            self.kraken.q.task_done()

    def count_thread_download(self):
        amount = threading.active_count()
        print('th_DW: ', amount)
        return amount

    def execute_log_Job(self, filePath_Dream):
        pass
        with self.print_lock:
            print(threading.current_thread().name, filePath_Dream)
            pass


    def execute_upload_Job(self, folder_key, file_name):
        def new_file(folder_key, file_name):
            query_folder = '''
                mutation{
                    newFile(token: "{token}",
                            key: "{folder_key}",
                            fileName: "{file_name}"){
                        file{
                            uploadLink
                            key
                            fileLocal
                        }
                    }
                }
                '''
            query_folder = query_folder.replace('{folder_key}', folder_key)
            query_folder = query_folder.replace('{file_name}', file_name)

            folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
            folder_response = json.loads(folder_response)
            uploadLink = folder_response['data']['newFile']['file']['uploadLink']
            file_key = folder_response['data']['newFile']['file']['key']
            fileLocal = folder_response['data']['newFile']['file']['fileLocal']
            # file = folder_response['data']['newFile']['file']
            return uploadLink, file_key, fileLocal

        def upload_completed(file_key, fileSize):
            query = '''
                mutation{
                    completedFile(token: "{token}",
                            key: "{file_key}",
                            fileSize: {fileSize}){
                            file{
                              key
                            }
                    }
                }
                '''
            query = query.replace('{file_key}', file_key)
            query = query.replace('{fileSize}', fileSize)

            folder_response = api_call(self.kraken, self.url, query=query, token=self.token_auth)
            # folder_response = json.loads(folder_response)
            return True

        uploadLink, file_key, fileLocal = new_file(folder_key, file_name)
        # try:
        with open(fileLocal, 'rb') as file_data:
            response: requests.Response = requests.put(uploadLink, data=file_data)

            if response.status_code == 200:
                print(' upload finnish')
            else:
                print(' upload error:', response.text)

        fileSize = os.path.getsize(fileLocal)
        upload_completed(file_key, str(fileSize))
        self.kraken.print_console_ws.emit('    Uploaded File: ' + str(file_name))





        folder_path = os.path.dirname(fileLocal)
        # if not os.path.exists(folder_path):
        #     # print('    Folder created')
        #     try: # Se deja porque puede que varios th esten haciendo lo mismo
        #         os.makedirs(folder_path)
        #     except:
        #         pass
        #
        # if not os.path.exists(file_path):
        #     try:
        #         response = requests.get(file_link)
        #         with open(file_path, 'wb') as archivo:
        #             archivo.write(response.content)
        #             # poner metadatos del original
        #             # self.print_console('    Download', file_path)
        #             # print('    Download', file_path)
        #     except:
        #         print('-- Error in download_file', file_path)

        self._running = False
        with self.kraken.print_lock:
            # self.print_console('      Downloaded --> ' + str(file_path))
            print('      Uploaded --> ' + str(file_path))
            # print(' Hilos Activos', threading.active_count())
            pass

    # ----------------------------------------------------------