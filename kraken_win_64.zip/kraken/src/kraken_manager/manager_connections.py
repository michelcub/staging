import websockets
import json
import ast
import os
import datetime


class WebSocketServer:
    def __init__(self, manager=None):
        self.connections = []
        self.dcc_list = []
        self.manager = manager

    async def on_connect(self, websocket, path):
        try:
            await self.handle_new_connection(websocket, path)
        except Exception as e:
            self.log_error("Error al conectar: " + str(e))
            pass
        finally:
            await self.cleanup_connection(websocket)

    async def handle_new_connection(self, websocket, path):
        try:
            command = await websocket.recv()
            #print(f'Comando recibido: {command}')

            # Simplifica la conversión de los mensajes
            try:
                command_dict = json.loads(command)
                # print(f"Comando reconocido: {command_dict}")
            except json.JSONDecodeError:
                command_dict = json.loads(command.replace("'", '"'))

            if command_dict.get('type') == 'register' and 'dcc' in command_dict:
                await self.register_client(websocket, command_dict, path)
            else:
                print(f"Comando no reconocido: {command}")

            await self.listen_for_messages(websocket, command_dict)
        except Exception as e:
            self.log_error("Error al manejar la nueva conexión: " + str(e))
            pass

    async def register_client(self, websocket, command_dict, path):
        try:
            dcc = command_dict['dcc']
            self.log_message(f"{dcc} - Proyecto: {command_dict['file']} conectado ===")
            self.dcc_list.append(dcc)
            # print(f"Conectado: {command_dict} en ruta: {path}")
            connection = {'dcc': dcc, 'ws': websocket, 'file': command_dict['file'], 'uuid': command_dict['uuid']}
            self.connections.append(connection)
            await websocket.send(f"Conectado: {command_dict} en ruta: {path}")

            await self.broadcast_connections()
        except Exception as e:
            self.log_error("Error al registrar el cliente: " + str(e))
            pass

    async def listen_for_messages(self, websocket, command_dict):
        try:
            dcc = command_dict['dcc']
            #try:
            async for message in websocket:
                #print(f"Mensaje recibido: {message}")
                if message == "quit":
                    if self.manager:
                        self.manager.close_app()
                    return
                try:
                    await self.handle_client_message(message, dcc)
                    #print('=============================================')
                except Exception as e:
                    print(f"Error al manejar el mensaje: {e}")
            #except websockets.exceptions.ConnectionClosed:
                #pass
        except Exception as e:
            print(f"Error al escuchar mensajes: {e}")
            pass

    async def handle_client_message(self, message, dcc):
        try:
            try:
                message_dict = json.loads(message)
            except json.JSONDecodeError:
                message_dict = json.loads(message.replace("'", '"'))

            if 'last_file' in message_dict:
                await self.update_last_file(dcc, message_dict)

            await self.broadcast(message)
        except Exception as e:
            self.log_error("Error al manejar el mensaje del cliente: " + str(e))
            pass

    async def update_last_file(self, dcc, message_dict):
        try:
            for connection in self.connections:
                if connection['dcc'] == dcc and connection['uuid'] == message_dict['uuid']:
                    connection['file'] = message_dict['file']
                    if connection['file'] != message_dict['file']:
                        self.log_message(f"Cambio en {dcc} - Proyecto: {message_dict['last_file']} a {message_dict['file']} ===")
                    await self.broadcast_connections()
        except Exception as e:
            self.log_error("Error al actualizar el último archivo: " + str(e))
            pass

    async def broadcast(self, message):
        try:
            #print(f"Broadcasting: {message}")
            for connection in self.connections:
                try:
                    await connection['ws'].send(message)
                except websockets.exceptions.ConnectionClosed:
                    self.connections.remove(connection)
        except Exception as e:
            self.log_error("Error al enviar mensaje: " + str(e))
            pass

    async def broadcast_connections(self):
        try:
            connections = [{'dcc': c['dcc'], 'file': c['file'], 'uuid': c['uuid']} for c in self.connections]
            await self.broadcast(json.dumps({"type": "dcc_list", "dcc_list": self.dcc_list, "connections": connections, "pid_manager": os.getpid()}))
        except Exception as e:
            self.log_error("Error al enviar la lista de conexiones: " + str(e))
            pass

    async def cleanup_connection(self, websocket):
        try:
            for connection in self.connections:
                if connection['ws'] == websocket:
                    self.dcc_list.remove(connection['dcc'])
                    self.connections.remove(connection)
                    self.log_message(f"{connection['dcc']} - Proyecto: {connection['file']} desconectado -x-")
                    await self.broadcast_connections()
                    break
        except Exception as e:
            self.log_error("Error al limpiar la conexión : " + str(e))
            pass

    def set_log_browser(self, log_browser):
        """Configura el navegador de log para el servidor."""
        self.log_browser = log_browser

    def log_message(self, message):
        """Registra un mensaje usando el navegador de log configurado."""
        if self.log_browser:
            cursor = self.log_browser.textCursor()  # Obtiene el cursor actual del texto
            cursor.movePosition(cursor.Start)  # Mueve el cursor al inicio del texto
            cursor.insertText(message + '\n')  # Inserta el mensaje en la posición actual del cursor
            self.log_browser.setTextCursor(cursor)  # Actualiza el cursor en el widget
        else:
            # Si no hay un log_browser configurado, cae de vuelta al log estándar.
            print(message)

    def log_error(self, message):
        day = datetime.datetime.now().strftime('%Y-%m-%d')
        root_documents = os.path.join(os.environ['USERPROFILE'], 'Documents')
        log_file_path = os.path.join(root_documents, 'Kraken', 'kraken_manager_log.txt')

        if not os.path.exists(os.path.dirname(log_file_path)):
            os.makedirs(os.path.dirname(log_file_path))

        with open(log_file_path, 'a') as log_file:
            log_file.write(f"{day + ' || ' + message}\n")