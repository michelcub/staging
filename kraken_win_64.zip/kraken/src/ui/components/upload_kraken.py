from PyQt5 import QtWidgets, uic
from PyQt5.QtCore import Qt, QPoint, QMimeData
import os
import threading
import requests
import time

def obtener_informacion_ruta(ruta_inicial, base_path):
    # Lista para acumular todos los archivos encontrados
    archivos = []

    # Función interna recursiva para recopilar información de archivos
    def recopilar_archivos(ruta_actual, base_path):
        if not os.path.exists(ruta_actual):
            return {"error": "The path doesn't exist"}

        if os.path.isdir(ruta_actual):
            contenido_directorio = os.listdir(ruta_actual)
            for elemento_nombre in contenido_directorio:
                elemento_ruta = os.path.join(ruta_actual, elemento_nombre)
                # Llama recursivamente para subdirectorios
                recopilar_archivos(elemento_ruta, base_path)
        elif os.path.isfile(ruta_actual):
            # Añade información del archivo a la lista
            archivos.append({
                "nombre": os.path.basename(ruta_actual),
                "size": os.path.getsize(ruta_actual),
                "route": ruta_actual.replace("\\", "/"),
                "relative_route": os.path.relpath(ruta_actual, base_path).replace("\\", "/")
            })


    recopilar_archivos(ruta_inicial, base_path)

    return archivos


class DraggableLabel(QtWidgets.QLabel):
    def __init__(self, modal_upload_kraken=None):
        super(DraggableLabel, self).__init__(modal_upload_kraken)
        self.setAcceptDrops(True)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("color: white;")

        self.modal_upload_kraken = modal_upload_kraken

        self.files = []



    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        self.modal_upload_kraken.loading.show()
        urls = event.mimeData().urls()
        for url in urls:
            path = url.toLocalFile()
            if os.path.isfile(path):
                self.files.append({
                    "name": os.path.basename(path),
                    "size": os.path.getsize(path),
                    "route": path.replace("\\", "/"),
                    "relative_route": os.path.basename(path)
                })
            elif os.path.isdir(path):
                self.files.extend(obtener_informacion_ruta(path, os.path.dirname(path)))

        try:

            self.modal_upload_kraken.render_tree()
            self.modal_upload_kraken.total_file_number.setText(str(len(self.files)))
        except:
            print('No se pudo renderizar el árbol')

class UploadKraken(QtWidgets.QDialog):
    def __init__(self, kraken, folder_key=None):
        super(UploadKraken, self).__init__()
        uic.loadUi('src/ui/components/upload_kraken.ui', self)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)  # Hace el fondo de la ventana transparente
        self.setStyleSheet("background:transparent;")
        self.show()
        self.kraken = kraken
        self.loading.hide()

        self.folder_key = folder_key

        # Botones
        self.detail_btn.clicked.connect(self.switch_detail)
        self.cancel_upload_kraken_btn.clicked.connect(self.closeDropzone)
        self.upload_kraken_btn.clicked.connect(self.uploadFromKraken)

        # Aceptar drag and drop
        self.dropzone = DraggableLabel(self)
        self.dropzone.setStyleSheet('border: 0;')
        self.dropzone.setText('Drop files here')
        self.dropzone_container.layout().addWidget(self.dropzone)

        self.detail_tree.setColumnCount(2)
        self.detail_tree.setHeaderLabels(["Nombre", "Tamaño"])

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.oldPos = event.globalPos()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton:
            delta = QPoint(event.globalPos() - self.oldPos)
            self.move(self.x() + delta.x(), self.y() + delta.y())
            self.oldPos = event.globalPos()


    def save_all_files_in_db(self):
        self.kraken.db.insert_group_task(self.dropzone.files, 'upload', self.folder_key)

    def render_tree(self):
        self.detail_tree.clear()
        root = self.detail_tree.invisibleRootItem()
        path_dict = {}

        for file_info in self.dropzone.files:
            path_parts = file_info["relative_route"].split("/")
            current_dict = path_dict

            for part in path_parts[:-1]:
                if part not in current_dict:
                    current_dict[part] = {}
                current_dict = current_dict[part]

            current_dict[path_parts[-1]] = file_info["size"]

        self.loading.hide()

        def add_items(parent, elements):
            for key, value in elements.items():
                item = QtWidgets.QTreeWidgetItem([key])
                parent.addChild(item)
                if isinstance(value, dict):
                    add_items(item, value)
                else:
                    item.setText(1, str(value))

        add_items(root, path_dict)
        self.detail_tree.expandAll()

    def switch_detail(self):
        if self.container_detail.isHidden():
            self.container_detail.show()
        else:
            self.container_detail.hide()

    def closeDropzone(self):
        self.close()

    def get_upload_link(self, task_list):

        base_url = str(self.kraken.http_url)
        if 'localhost' not in base_url:
            base_url = base_url.replace('http://', 'https://')

        # Construir la URL completa para la solicitud
        url = f"{base_url}/files/dragdrop_files_storage_link/"

        # Construir los datos de la solicitud
        data = {
            "fileList": task_list
        }

        try:
            # Realizar la solicitud POST
            response = requests.post(url, json=data)

            # Verificar si la solicitud fue exitosa
            response.raise_for_status()

            # Retornar la respuesta JSON
            print('Respuesta:', response.json())
            return response.json()

        except requests.exceptions.RequestException as e:
            print(f"Error al hacer la solicitud: {e}")
            return None

    def rate_limiting(self):
        self.task_list = []

        while True:
            self.tasks = self.kraken.db.fetch_pending_group_tasks_by_type('upload', 200)

            for task in self.tasks:
                file_info = task['data']
                file_info['task_id'] = task['id']
                file_info['table_key'] = task['folder_key']
                file_info['table'] = 'folder'
                self.task_list.append(file_info)


            try:
                self.get_upload_link(self.task_list)
            except Exception as e:
                print('Error al intentar obtener el link de subida:', e)
            if len(self.task_list) == 0:
                break
            time.sleep(5)


    def uploadFromKraken(self):
        try:
            execute_thread = threading.Thread(target=self.save_all_files_in_db, daemon=True)
            execute_thread.start()
            execute_thread.join()
        except Exception as e:
            print('Error al intentar subir archivos:', e)

        #threading.Thread(target=self.rate_limiting, daemon=True).start()
        self.rate_limiting()