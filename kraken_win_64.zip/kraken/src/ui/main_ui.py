# -*- coding: utf-8 -*-

from PyQt5.QtWidgets import QMainWindow, QFileDialog
from PyQt5.QtCore import QPropertyAnimation, QEasingCurve, QUrl, Qt
from PyQt5 import QtCore, QtWidgets
from PyQt5.uic import loadUi
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5 import QtGui

import threading
import os
import random
import requests
import json
import sys
import time

import src.pipelinepro.settings as settings

from src.ui.settings_window import SettingsWindow
from src.ui.windows_control import WindowControl
from src.libraries.file_encryp import save_disk, load_disk, encrypt, deencrypt, write_cache_file, delete_cache_file
from src.api.graphql import api_call
from src.libraries.file_basic import save_to_disk

class MainWindow(QMainWindow, WindowControl):
    def __init__(self, kraken):
        super(MainWindow, self).__init__()

        # Conector de mensajes
        self.kraken = kraken
        self.kraken.print_console_ws.connect(self.print_console)
        # Download.print_console_download.connect(self.print_console)

        self.log_console = []

        program_path = str(os.getcwd())
        program_path = program_path.replace('\\', '/')

        loadUi("{}/src/ui/kraken.ui".format(program_path), self)
        self.apiKey = None


        # Iniciamos Connect Contraido
        # self.frame_loginPannel.show()
        self.frame_connect.show()
        self.frame_login_status.hide()


        self.webapp_ready = False
        if self.webapp_ready:
            self.load_webapp(self)

        #select_folder
        self.kraken.select_folder = self.select_folder
        self.kraken.select_file = self.select_file



        # Captura de Clicks de botones
        self.button_send.clicked.connect(self.login_action)

        # Captura de Clicks de allways on top
        self.button_pin.clicked.connect(self.toggle_always_on_top)

        # self.button_settings.clicked.connect(self.insert_log)
        self.button_settings.clicked.connect(self.open_settings)
        self.button_close.clicked.connect(self.close_app)
        # self.button_close.clicked.connect(self.close_app)
        # self.button_close.clicked.connect(self.close)

        # Quitar titulo
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setWindowOpacity(1)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # SizeGrip
        self.gripSize = 10
        self.grip = QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize, self.gripSize)

        # Captura del Click - mover ventana
        self.frame_top.mouseMoveEvent = self.mover_ventana
        self.frame_top.mouseDoubleClickEvent = self.vista_normal

        #ruta a la carpeta de documentos del usuario
        self.documentos_path = os.path.join(os.environ['USERPROFILE'], 'Documents', 'kraken')
        self.file_disk = self.documentos_path + settings.CACHE_FILE

        # Icono en el Systray
        self.systray()

        #minimizar la ventana
        self.min_button.clicked.connect(self.minimize)

        #para hacer logout
        self.button_connected.enterEvent = lambda event: self.on_hover()
        self.button_connected.leaveEvent = lambda event: self.on_leave()
        self.button_connected.clicked.connect(self.logout)

        # seleccion de metodo de login
        self.method_selected = 'email'
        self.select_method('email')
        self.button_select_email.clicked.connect(lambda: self.select_method('email'))
        self.button_select_apikey.clicked.connect(lambda: self.select_method('apikey'))

    def write_sesion_configurations(self, auto_login=True):
        if not hasattr(self, 'sesion_configuration'):
            self.sesion_configuration = {}
        self.sesion_configuration['login_method'] = self.method_selected
        self.sesion_configuration['auto_login'] = auto_login
        self.sesion_configuration_json = os.path.join(self.documentos_path, 'sesion_configuration.json').replace('\\', '/')

        folder_path = os.path.dirname(self.sesion_configuration_json,)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        with open(self.sesion_configuration_json, 'w') as file:
            json.dump(self.sesion_configuration, file)

    def read_sesion_configurations(self):
        # cacheo de la configuracion de la sesion
        self.sesion_configuration_json = os.path.join(self.documentos_path, 'sesion_configuration.json').replace('\\', '/')

        if not os.path.exists(self.sesion_configuration_json):
            # Verificar si el directorio existe. Si no, créalo.
            os.makedirs(os.path.dirname(self.sesion_configuration_json), exist_ok=True)

            self.sesion_configuration = {
                'login_method': 'email',
                'auto_login': True,
            }

            with open(self.sesion_configuration_json, 'w') as file:
                json.dump(self.sesion_configuration, file)

        # leer la configuracion de la sesion
        with open(self.sesion_configuration_json, 'r') as file:
            self.sesion_configuration = json.load(file)
            if self.sesion_configuration['auto_login'] == True:
                self.auto_login = True
            else:
                self.auto_login = False
            if self.sesion_configuration['login_method'] == 'email':
                self.select_method('email')
            elif self.sesion_configuration['login_method'] == 'apikey':
                self.select_method('apikey')

    def systray(self):
        # Crea y configura el ícono del Systray
        self.tray_icon = QtWidgets.QSystemTrayIcon(self)
        self.tray_icon.setIcon(QtGui.QIcon("src/ui/images/kraken_icon.ico"))

        tray_title = 'Kraken Disconnected'

        self.tray_icon.setToolTip(tray_title)

        # Crea un menú para el ícono del Systray
        tray_menu = QtWidgets.QMenu()

        self.title_action = QtWidgets.QAction("Kraken", self)
        self.title_action.setEnabled(False)  # Deshabilitar para que no responda a clics
        tray_menu.addAction(self.title_action)

        exit_action = tray_menu.addAction("Close")
        exit_action.triggered.connect(self.exit_app)

        self.tray_icon.setContextMenu(tray_menu)

        # Muestra el ícono del Systray
        self.tray_icon.show()

        #abre la ventana cuando se pulsa el icono
        self.tray_icon.activated.connect(self.on_tray_icon_activated)




    def select_method(self, method):
        if method == 'email':
            self.button_select_apikey.setChecked(False)
            self.button_select_email.setChecked(True)
            self.method_selected = 'email'
            self.login_method.setCurrentIndex(0)

            self.write_sesion_configurations(auto_login=False)

        else:
            self.button_select_email.setChecked(False)
            self.button_select_apikey.setChecked(True)
            self.method_selected = 'apikey'
            self.login_method.setCurrentIndex(1)
            self.write_sesion_configurations(auto_login=False)


    def load_webapp(self, token_auth):
        self.web_layout = QWebEngineView()
        self.web_layout.setContextMenuPolicy(Qt.NoContextMenu)
        url = self.kraken.http_url + settings. ENDPOINT_WEBAPP
        self.web_layout.setUrl(QUrl(url))
        self.main_layout.addWidget(self.web_layout)

    def removerWebLayout(self):
        # Remover el QWebEngineView del layout principal
        if self.web_layout:
            self.main_layout.removeWidget(self.web_layout)
            self.web_layout.hide()
            self.web_layout.deleteLater()  # Eliminar el widget para liberar recursos
            self.web_layout = None

    def open_settings(self):
        if not hasattr(self,
                       'settings_window') or not self.settings_window or not self.settings_window.is_open_settings:
            self.settings_window = SettingsWindow(self.kraken)
            self.settings_window.show()
            self.settings_window.is_open_settings = True

    def on_tray_icon_activated(self, reason):
        if reason == QtWidgets.QSystemTrayIcon.DoubleClick:
            self.show()

    def exit_app(self):
        # Código para cerrar la aplicación
        #self.kraken.ws.close_connection()
        # self.logout()
        self.kraken.disconnect_ws()
        self.tray_icon.hide()
        self.close()



    def close_app(self):
        # Minimiza al Systray en lugar de cerrar
        self.hide()
        self.tray_icon.showMessage("Kraken", "Kraken is running in the background.")


    def insert_log(self):
        amount = threading.active_count()
        value = random.randint(1, 999999)
        menssage = 'Th ' + str(amount) + ' --- ' + str(value)
        self.print_console(menssage)

    def print_console(self, menssage):
        self.log_console.insert(0, str(menssage))
        s = '\n'.join([str(n) for n in self.log_console])
        self.textBrowser.setText(s)

    def login_action(self):
        """
        Proceso de transformacion de los input de login en las variables transformadas del objeto kraken
        TODO: Llevarlo a una libreria separada con las llamadas
        """
        pmt_url = self.input_url.text()
        user = self.input_user.text()
        password = self.input_password.text()
        apiKey = self.input_apiKey.text()

        if pmt_url:
            pmt_url = pmt_url.rstrip('/')
            self.kraken.http_url = pmt_url.rstrip('/')
            ws_url = self.kraken.http_url.replace('https://', '')
            self.kraken.ws_url = ws_url.replace('http://', '')

        if pmt_url and apiKey and self.method_selected == 'apikey':
            if not apiKey or len(apiKey) < 35:
                print('   No apikey detected')
            else:
                print('   Login from apiKey')

                self.kraken.apiKey = apiKey

                self.kraken.userKey = apiKey # ws_room
                # self.print_console('Server Connected')
                # self.label_urlconnected.setText(self.kraken.http_url)

                self.kraken.connect_ws()
                threading.Thread(target=self.kraken.reconect_manager, daemon=True).start()

                self.frame_connect.hide()
                self.frame_login_status.show()
                self.app_router.hide()
                self.frame_core.setFixedHeight(800)
                self.label_urlconnected.setText(self.kraken.http_url)

                if self.kraken.apiKey:
                    self.tray_icon.setToolTip('Kraken Server ' + self.kraken.version + ' ' + str(self.kraken.http_url))

                self.textBrowser.setFixedHeight(700)
                write_cache_file(self.file_disk, pmt_url, user, password, apiKey)
                self.write_sesion_configurations()
            # TODO: --- Hacer que el login pueda ser por token o por credenciales

        elif pmt_url and user and password and self.method_selected == 'email':
            self.kraken.username = user
            self.kraken.password = password
            self.kraken.http_url = pmt_url.rstrip('/')
            # TODO: Si el servidor al que apunta está muerto no arranca
            try:
                self.kraken.token_auth, self.kraken.userKey = self.login(pmt_url, user, password)
                if self.kraken.token_auth:
                    self.tray_icon.setToolTip('Kraken ' + self.kraken.version + ' - ' + str(self.kraken.http_url))
                    self.title_action.setText(str(self.kraken.username))
            except:
                self.print_console('Login Fail')

            if self.kraken.userKey:
                self.frame_core.setFixedHeight(150)

                self.load_webapp(self.kraken.userKey)

                self.kraken.connect_ws()
                self.app_router.setCurrentIndex(1)
                #self.frame_connect.hide()
                self.frame_login_status.show()
                self.label_urlconnected.setText(self.kraken.http_url)

                write_cache_file(self.file_disk, pmt_url, user, password, apiKey)
                self.write_sesion_configurations()


    def login(self, pmt_url, username, password):
        query_token = f'''
              mutation {{
                tokenAuth(username: "{username}", password: "{password}") {{
                  token
                }}
              }}
            '''
        response = requests.post(pmt_url + '/graphql/', json={'query': query_token})
        response_token = response.text
        response_token = json.loads(response_token)
        token_auth = response_token['data']['tokenAuth']['token']
        userKey = self.userKeyAuth(token_auth)

        cache_path = str(os.getcwd() + '/cache/')
        if not os.path.exists(cache_path):
            os.makedirs(cache_path)
        save_to_disk(token_auth, cache_path + 'token.dt')
        save_to_disk(pmt_url, cache_path + 'url.dt')

        return token_auth, userKey


    def userKeyAuth(self, token):
        query = '''
              query {
                  userKeyAuth(token: "{token}")
                }
            '''
        response = api_call(self.kraken, self.kraken.http_url, query, token)
        response = json.loads(response)
        userKey = response['data']['userKeyAuth']
        self.room = userKey
        return userKey


    def toggle_always_on_top(self):
        always_on_top_active_style = "background-color: #FF9600; border-radius: 3px; max-width: 20px; max-height: 20px"
        always_on_top_inactive_style = "background-color: none; border-radius: 3px; max-width: 20px; max-height: 20px"

        if self.windowFlags() & Qt.WindowStaysOnTopHint:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowStaysOnTopHint)
            self.button_pin.setStyleSheet(always_on_top_inactive_style)
        else:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
            self.button_pin.setStyleSheet(always_on_top_active_style)

        self.show()

    def logout(self):
        #kraken_lnk = os.path.join(os.getcwd(), 'run_Kraken.bat').replace('\\', '/')
        #delete_cache_file(self.file_disk)
        #os.startfile(kraken_lnk)
        self.app_router.setCurrentIndex(0)
        if not self.method_selected == 'apikey':
            self.removerWebLayout()
        else:
            self.app_router.show()
            self.frame_core.setFixedHeight(137)
        self.frame_connect.show()
        self.frame_login_status.hide()


        self.write_sesion_configurations(auto_login=False)
        self.print_console('Sesion closed')
        #self.exit_app()






    def on_hover(self):
        self.button_connected.setText("Logout")

    def on_leave(self):
        self.button_connected.setText("Connected")

    def minimize(self):
        self.showMinimized()

    #es la ventana que abrimos para seleccionar carpetas desde django
    def select_folder(self):
        folderDialog = QFileDialog(self)
        folderDialog.setWindowFlags(Qt.WindowStaysOnTopHint)  # Establece la ventana para que se mantenga encima
        folder = folderDialog.getExistingDirectory(self, "Select Folder")

        if folder:
            # Aquí puedes hacer algo con la carpeta seleccionada
            if self.kraken.ws:
                self.kraken.ws.send_message(json.dumps({
                    "message": {
                        "type": "select_folder",
                        "data": folder
                    }
                }))
            else:
                print("WebSocket connection not established. Unable to send data.")

    def select_file(self):
        file_dialog = QFileDialog(self)
        file_dialog.setWindowFlags(Qt.WindowStaysOnTopHint)  # Establece la ventana para que se mantenga encima
        file = file_dialog.getOpenFileName(self, "Select File")

        if file[0]:
            # Aquí puedes hacer algo con el archivo seleccionado
            selected_file = file[0]
            if self.kraken.ws:
                self.kraken.ws.send_message(json.dumps({
                    "message": {
                        "type": "select_folder",
                        "data": selected_file
                    }
                }))
            else:
                print("WebSocket connection not established. Unable to send data.")