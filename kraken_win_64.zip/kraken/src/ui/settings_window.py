# -*- coding: utf-8 -*-

from PyQt5 import QtCore, QtWidgets
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QFileDialog
import src.pipelinepro.settings as settings

import subprocess
import base64
import json
import os
# import winshell

from src.ui.windows_control import WindowControl
from src.dccs.install_plugins import install_maya, install_blender_go, install_unreal_go, install_nuke, install_houdini
from src.performance.machine import disk_space
from src.install.update_kraken import ckeck_version, update_kraken_version


class SettingsWindow(QtWidgets.QDialog, WindowControl):
    def __init__(self, kraken):
        super(SettingsWindow, self).__init__()

        # Estado de la ventana de settings
        self.is_open_settings = False

        self.kraken = kraken
        loadUi("{}/src/ui/settings.ui".format(self.kraken.pwd), self)

        # Pinta la version
        self.kraken_version.setText(kraken.version)
        # Update
        if ckeck_version(self.kraken.version):
            self.button_update.clicked.connect(lambda: update_kraken_version(self.kraken, self))
        else:
            self.button_update.hide()


        # Pintado de rutas de trabajo
        # if self.kraken.workfolder:
        #     self.input_path_workfolder.setText(self.kraken.workfolder)
        self.label_path_tempfolder.setText(self.kraken.pwd + '/temp/')
        self.label_path_virtualenv.setText(self.kraken.pwd + '/venv_kraken/')

        # Pinta Space Storage
        self.label_space.setText(self.kraken.workFolder)
        space = str(disk_space(self.kraken.workFolder)) + ' Gb'
        self.label_space.setText(space)

        # Captura de Clicks de botones
        self.button_close.clicked.connect(self.close_app)

        # Quitar titulo
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setWindowOpacity(1)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # SizeGrip
        self.gripSize = 10
        self.grip = QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize, self.gripSize)

        # Captura del Click - mover ventana
        self.frame_top.mouseMoveEvent = self.mover_ventana

        self.documentos_path = os.path.join(os.environ['USERPROFILE'], 'Documents', 'kraken')
        self.file_disk = self.documentos_path + settings.CACHE_FILE


        # ==================== DCCs
        # -------------------- TEST
        #self.connect_unreal.clicked.connect(self.kraken_manager_client.send('test'))
        #self.connect_nuke.clicked.connect(self.kraken_manager_client.send('test'))
        #self.connect_maya.clicked.connect(self.kraken_manager_client.send('test'))
        #self.connect_blender.clicked.connect(self.kraken.kraken_manager_client.send('test'))
        #self.connect_blender.clicked.connect(self.kraken.kraken_manager_client.send('test'))

        # -------------------- Maya
        self.update_dcc_status('maya', self.connect_maya)
        self.kraken.btn_install_maya = self.install_maya
        self.kraken.status_maya = self.connect_maya
        self.get_path_by_type(self.exe_path_maya, self.install_maya, 'maya')
        self.install_maya.clicked.connect(lambda: (self.find_folder_installation(self.exe_path_maya), self.save_path_to_installation(self.exe_path_maya.text().replace('\\', '/'),'maya'), install_maya(self.kraken,self.exe_path_maya)))
        self.exe_path_maya.returnPressed.connect(lambda: (self.find_folder_installation(self.exe_path_maya), self.save_path_to_installation(self.exe_path_maya.text().replace('\\', '/'),'maya'), install_maya(self.kraken,self.exe_path_maya)))

        #-------------------- Blender
        self.update_dcc_status('blender', self.connect_blender)
        self.kraken.status_blender = self.connect_blender
        blender_exe = self.exe_path_blender.text()
        self.get_path_by_type(self.exe_path_blender, self.install_blender, 'blender')
        self.kraken.path_installation_blender = blender_exe.replace('\\', '/')
        self.kraken.btn_install_blender = self.install_blender
        self.install_blender.clicked.connect(lambda: (self.find_folder_installation(self.exe_path_blender), self.save_path_to_installation(self.exe_path_blender.text().replace('\\', '/'),'blender'), install_blender_go(self.kraken, self.exe_path_blender)))
        self.exe_path_blender.returnPressed.connect(lambda: (self.find_folder_installation(self.exe_path_blender), self.save_path_to_installation(self.exe_path_blender.text().replace('\\', '/'),'blender'), install_blender_go(self.kraken, self.exe_path_blender)))


        # self.find_path_by_name('blender')

        # -------------------- Unreal
        self.update_dcc_status('unreal', self.connect_unreal)
        self.kraken.status_unreal = self.connect_unreal
        self.get_path_by_type(self.exe_path_unreal, self.install_unreal, 'unreal')
        self.kraken.path_installation_unreal = self.exe_path_unreal.text().replace('\\', '/')
        self.kraken.btn_install_unreal = self.install_unreal
        self.install_unreal.clicked.connect(lambda: (self.find_folder_installation(self.exe_path_unreal), self.save_path_to_installation(self.exe_path_unreal.text().replace('\\', '/'),'unreal'), install_unreal_go( self.kraken, self.exe_path_unreal)))
        self.exe_path_unreal.returnPressed.connect(lambda: (self.find_folder_installation(self.exe_path_unreal), self.save_path_to_installation(self.exe_path_unreal.text().replace('\\', '/'),'unreal'), install_unreal_go( self.kraken, self.exe_path_unreal)))

        # -------------------- Nuke
        self.update_dcc_status('nuke', self.connect_nuke)
        self.kraken.status_nuke = self.connect_nuke
        self.get_path_by_type(self.exe_path_nuke, self.install_nuke, 'nuke')
        self.kraken.path_installation_nuke = self.exe_path_nuke.text().replace('\\', '/')
        self.kraken.btn_install_nuke = self.install_nuke  #es el nombre del boton, no una funcion
        self.install_nuke.clicked.connect(lambda: (self.find_folder_installation(self.exe_path_nuke), self.save_path_to_installation(self.exe_path_nuke.text().replace('\\', '/'),'nuke'), install_nuke(self.kraken, self.exe_path_nuke)))
        self.exe_path_nuke.returnPressed.connect(lambda: (self.find_folder_installation(self.exe_path_nuke), self.save_path_to_installation(self.exe_path_nuke.text().replace('\\', '/'),'nuke'), install_nuke(self.kraken, self.exe_path_nuke)))

        # -------------------- Houdini
        self.update_dcc_status('houdini', self.connect_houdini)
        self.kraken.status_houdini = self.connect_houdini
        self.get_path_by_type(self.exe_path_houdini, self.install_houdini, 'houdini')
        self.kraken.path_installation_houdini = self.exe_path_houdini.text().replace('\\', '/')
        self.kraken.btn_install_houdini = self.install_houdini
        self.install_houdini.clicked.connect(lambda: (self.find_folder_installation(self.exe_path_houdini), self.save_path_to_installation(self.exe_path_houdini.text().replace('\\', '/'),'houdini'), install_houdini(self.kraken, self.exe_path_houdini)))
        self.exe_path_houdini.returnPressed.connect(lambda: (self.find_folder_installation(self.exe_path_houdini), self.save_path_to_installation(self.exe_path_houdini.text().replace('\\', '/'),'houdini'), install_houdini(self.kraken, self.exe_path_houdini)))

        # -------------------- Photoshop
        self.update_dcc_status('photoshop', self.connect_photoshop)
        self.kraken.status_unreal = self.connect_photoshop
        self.get_path_by_type(self.exe_path_photoshop, self.install_photoshop, 'photoshop')
        self.kraken.path_installation_unreal = self.exe_path_photoshop.text().replace('\\', '/')
        self.kraken.btn_install_unreal = self.install_photoshop
        self.install_photoshop.clicked.connect(lambda: (self.find_folder_installation(self.exe_path_photoshop),
                                                     self.save_path_to_installation(
                                                         self.exe_path_photoshop.text().replace('\\', '/'), 'photoshop'), print('Saved path')))
        self.exe_path_photoshop.returnPressed.connect(lambda: (self.find_folder_installation(self.exe_path_photoshop),
                                                            self.save_path_to_installation(
                                                                self.exe_path_photoshop.text().replace('\\', '/'),'photoshop'),
                                                            print('Saved path')))




    def close_app(self):
        self.is_open_settings = False
        self.close()


    def find_folder_installation(self, dcc_path_widget):
        # from pathlib import Path
        # folder_path = dcc_path_widget.text()
        # file_path = Path(folder_path)
        # folder_path = file_path.parent
        # folder_path = str(folder_path) + '/'
        # folder_path = folder_path.replace('\\', '/')
        # print(folder_path)

        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        file_path, _ = QFileDialog.getOpenFileName(self, 'Select *.exe', '', 'Executable Files (*.exe)', options=options)
        # file_path, _ = QFileDialog.getOpenFileName(self, 'Select *.exe', '', 'Executable Files (*.exe)', options=options, directory=str(folder_path))

        if file_path:
            dcc_path_widget.setText(file_path)
            self.kraken.path_installation_blender = file_path.replace('\\', '/')


    def save_path_to_installation(self, new_path, type):
        if not os.path.exists(new_path):
            return
        documentos_path = os.path.join(os.environ['USERPROFILE'], 'Documents')

        # Crear la ruta a la carpeta 'kraken' dentro de Documentos
        kraken_folder_path = os.path.join(documentos_path, 'kraken', 'plugins')
        if not os.path.exists(kraken_folder_path):
            os.makedirs(kraken_folder_path)

        # Definir la ruta al archivo JSON dentro de la carpeta 'kraken'
        json_file_path = os.path.join(kraken_folder_path, 'plugins_installation_paths.json')

        # Cargar los datos existentes o crear una nueva estructura si es necesario
        if os.path.exists(json_file_path):
            with open(json_file_path, 'r') as file:
                installation_paths = json.load(file)
        else:
            installation_paths = {}

        # Actualizar con el nuevo path
        installation_paths[type] = new_path

        # Guardar de nuevo en el archivo JSON
        with open(json_file_path, 'w') as file:
            json.dump(installation_paths, file, indent=4)

        print(f"Saved {type} path in {json_file_path}")

    def get_path_by_type(self, exec_path, btn_intall , type):
        documentos_path = os.path.join(os.environ['USERPROFILE'], 'Documents')

        # Ruta a la carpeta 'kraken' dentro de Documentos
        kraken_folder_path = os.path.join(documentos_path, 'kraken', 'plugins')

        # Ruta al archivo JSON dentro de la carpeta 'kraken'
        json_file_path = os.path.join(kraken_folder_path, 'plugins_installation_paths.json')

        # Verificar si el archivo JSON existe
        if not os.path.exists(json_file_path):
            return

        # Leer los datos del archivo JSON
        with open(json_file_path, 'r') as file:
            installation_paths = json.load(file)

        # Buscar el path por el tipo dado
        if type in installation_paths:
            btn_intall.setStyleSheet("QPushButton { background-color: green; }")
            exec_path.setText(installation_paths[type])
            return installation_paths[type]
        else:
            print(f"No se encontró el tipo '{type}' en el archivo.")
            return

    def update_dcc_status(self, dcc, status):
        if dcc in self.kraken.connection_list:
            status.setStyleSheet("background-color: green")
            status.setText('ON')
        else:
            status.setStyleSheet("background-color: red")
            status.setText('OFF')

    # def find_path_by_name(self, name):
    #     print('a')
    #     desktop_root = os.path.join(os.path.expanduser("~"), "Desktop")
    #
    #     # Buscar en el escritorio
    #     for archivo in os.listdir(desktop_root):
    #         print('b')
    #         if archivo.endswith(".lnk") and name in archivo:
    #             print('c')
    #             # Construir la ruta completa al archivo de acceso directo
    #             ruta_acceso_directo = os.path.join(desktop_root, archivo)
    #
    #             # Obtener la ruta al archivo al que apunta el acceso directo
    #             acceso_directo = winshell.shortcut(ruta_acceso_directo)
    #             self.exe_path_blender.setText(acceso_directo.path)
    #             self.path_installation_blender = acceso_directo.path
    #             print('d')
    #             return
    #         else:
    #             print('e')
    #             self.exe_path_blender.setText('Click me to find path')
