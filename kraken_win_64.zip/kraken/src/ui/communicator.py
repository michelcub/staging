from PyQt5.QtCore import QObject, pyqtSignal


class Communicator(QObject):
    triggerOpenDropZoneKraken = pyqtSignal(str)