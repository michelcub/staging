# -*- coding: utf-8 -*-

from PyQt5.QtCore import QPropertyAnimation, QEasingCurve
from PyQt5 import QtCore

class WindowControl():

    # Resize Event
    def resizeEvent(self, event):
        rect = self.rect()
        self.grip.move(rect.right() - self.gripSize, rect.bottom() - self.gripSize)

    # Mover ventana
    def mousePressEvent(self, event):
        self.clickPosition = event.globalPos()

    def mover_ventana(self, event):
        if self.isMaximized() == False:
            if event.buttons() == QtCore.Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.clickPosition)
                self.clickPosition = event.globalPos()
                event.accept()
            if event.globalPos().y() <= 10:
                self.showMaximized()
                # self.bt_maximizar.hide()
                # self.bt_restaurar.show()
            else:
                self.showNormal()
                # self.bt_maximizar.show()
                # self.bt_restaurar.hide()

    def vista_normal(self, event):
        self.showNormal()
        event.accept()


    def animacion_paginas(self):
        if True:
            width = self.stackedWidget.width()
            x1 = self.frame_connect.rect().right()
            normal = 100
            if width == 100:
                extender = x1
            else:
                extender = normal
            self.animacion1 = QPropertyAnimation(self.stackdWidget, b"maximumWidth")
            self.animacion1.setStartValue(width)
            self.animacion1.setEndValue(extender)
            self.animacion1.setDuration(500)
            self.animacion1.setEasingCurve(QEasingCurve.InOutQuad)
            self.animacion1.start()

    # def control_bt_maximizar(self):
    #     self.showMaximized()
    #     self.bt_maximizar.hide()
    #     self.bt_restaurar.show()