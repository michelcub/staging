# -*- coding: utf-8 -*-
"""
author: Rodrigo Medinilla
company: PipelinePro Software S.L.
date: 2023/08/09
"""

# Import Python Modules
from os.path import expanduser

import uuid

# ----------- Debug Mode

DEBUG = True

#identificador unico para asociar kraken y kraken artistian
kraken_id = str(uuid.uuid4())

# API Setting
API_URL = "https://staging.pipelinepro.io/graphql/"

# OS Settings
HOME_USER_LOCATION = expanduser("~")
MAIN_USER_FOLDER_NAME = ".pipelinepro"
TOKEN_FILENAME = "{}/{}/.token".format(HOME_USER_LOCATION, MAIN_USER_FOLDER_NAME)


# ENDPOINT_WEBAPP = '/kraken/dcc_assets/' + kraken_id + '/'
# ENDPOINT_WEBAPP = '/kraken/dcc_tasks/' + kraken_id + '/'
ENDPOINT_WEBAPP = '/kraken/start/'


# ----------- Credentials
CACHE_FILE = '/data/user_cache.info'

# ----------- File Extensions
EXTENSION_IMAGE = ['png', 'jpg', 'jpeg', 'tif', 'tiff', 'tga', 'bmp', 'webp', 'jfif',]
EXTENSION_VIDEO = ['mp4', 'mov', 'webm', 'mkv', 'avi',]
EXTENSION_PHOTOSHOP = ['psd',]
EXTENSION_MAYA = ['ma', 'mb', 'usd']
EXTENSION_BLENDER = ['blend',]
EXTENSION_HOUDINI = ['hip', 'bgeo', 'geo', 'hipnc', 'picnc', 'yfl', ]
EXTENSION_NUKE = ['nk',]
EXTENSION_UNREAL = ['uproject',]
