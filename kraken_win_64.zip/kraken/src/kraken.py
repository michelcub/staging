# -*- coding: utf-8 -*-

from PyQt5.QtCore import QObject, pyqtSignal

import threading
import os
import time
import json
import subprocess
import signal
from queue import Queue

import src.pipelinepro.settings as settings

from src.ui.main_ui import MainWindow
from src.api.web_socket import WS_comunications
from src.libraries.file_encryp import read_cache_file

from src.dccs.client_connections.client_kraken import KrakenClient
from src.dccs.client_connections.client_connections import listen_messages
from src.install.update_kraken import ckeck_version, update_kraken_version
from src.ui.communicator import Communicator
from src.operations.kraken_db.kraken_db import KrakenDB


class Kraken(QObject):
    print_console_ws = pyqtSignal(str)

    def __init__(self):
        super(Kraken, self).__init__()
        self.communicator = Communicator()
        self.ui = MainWindow(self, self.communicator)

        self.version = '4.23.2'

        """
        4.23.2  Desactivado el apagado
        4.23.1  Resucita el manager si no responde, bug de vfx y upload
        4.19.5  Test Retener login al actualizar
        4.19.4  Retener login al actualizar
        4.19.3  Prueba de update y muerte de anterior
        4.19.2  Los plugin inician el ws dentro de un Try por si kraken estuviera mal no colgaran el dcc
        4.19.1  Al darle a install plugin se cambia la configuracion previa sin insertar añadidos
        4.18.2  Comentario en la instalacion de plugins para que se verifique si kraken ya estaba para no duplicar
        """

        self.userKey = None
        self.apiKey = None
        self.manager_port = 18765

        self.http_url = None
        self.ws = None
        self.data_cache = False

        #PID del proceso de Kraken Manager
        self.pid_manager = None
        self.intentos_reconexion = 0
        self.auto_open_manager = False
        self.reconnect_manager = True

        #Inicializacion de la db
        self.db = KrakenDB()

        # Punto de ejecucion
        program_path = str(os.getcwd())
        program_path = program_path.replace('\\', '/')
        self.pwd = program_path
        self.workFolder = 'C://'

        # Punto ffmpg
        self.ffmpeg_exe = os.path.abspath(os.path.join(self.pwd, "..", "venv_kraken", "ffmpeg", "bin", "ffmpeg.exe"))
        self.ffmpeg_exe = self.ffmpeg_exe.replace('\\', '/')

        # Punto file_disk
        self.documents_path = os.path.join(os.environ['USERPROFILE'], 'Documents', 'Kraken')
        self.file_disk = self.documents_path + settings.CACHE_FILE

        # Iniciando colas de proceso
        self.init_queue()

        # Iniciando carpeta temporal
        self.initialize_work_folders()

        # Iniciando path a dccs
        self.get_dccs_path_to_exe()

        # Conecta con el manager
        self.mannager_is_connected = False

        # threading.Thread(target=self.reconect_manager, daemon=True).start()
        self.connect_to_kraken_mannager()


        if os.path.exists(self.file_disk):
            try:
                pmt_url, http_url, ws_url, user, password, apikey = read_cache_file(self.file_disk)

                #self.http_url = http_url
                self.load_cache(pmt_url, http_url, ws_url, user, password, apikey)

                self.ui.read_sesion_configurations()
                if self.data_cache and self.ui.auto_login == True:
                    self.ui.login_action()
            except Exception as e:
                print(f"Error reading cache file: {e}")

    def reconect_manager(self):
        intentos = 0
        while self.mannager_is_connected is False and intentos < 3:
            try:
                # lista de conexiones
                self.connection_list = []
                self.connect_to_kraken_mannager()
                self.mannager_is_connected = True

            except:
                print('Manager is not connected')
                self.mannager_is_connected = False
                time.sleep(5)
                intentos += 1




    def connect_to_kraken_mannager(self):
        manager_url = 'ws://localhost:' + str(self.manager_port) + '/'
        self.kraken_manager_client = KrakenClient(uri=manager_url, listen_messages=listen_messages, kraken=self)

        self.kraken_manager_client.run()
        # time.sleep(3)
        #asi se envian mensajes a los dcc
        #self.kraken_manager_client.send_message('Hello from kraken ')


    def connect_ws(self):
        # ws = self.start_websocket_thread()
        #self.t_ws = threading.Thread(target=self.start_websocket_thread)
        #self.t_ws.start()
        try:
            self.ws = WS_comunications(url=self.http_url, userKey=self.userKey, apiKey=self.apiKey, kraken=self)


            self.ws.send_message(json.dumps({
                "message": {
                    "message": "Hello from kraken",
                }
            }))
            self.ws.send_message(json.dumps({
                "message": {
                    "message": "Hello from kraken",
                }
            }))
        except Exception as e:
            print("Error al intentar conectar:", e)





    def disconnect_ws(self):
        if hasattr(self, 't_ws'):
            self.t_ws.join()
            print('websocket disconnect')
        else:
            print('Web Socket is disconnected')


    def load_cache(self, pmt_url, http_url, ws_url  , user, password, apikey):
        self.ui.input_url.setText(http_url)
        self.ui.input_user.setText(user)
        self.ui.input_password.setText(password)
        self.ui.input_apiKey.setText(apikey)
        self.data_cache = True

    def initialize_work_folders(self):
        # initializa las carpetas temporales y de descarga final para poder operar

        tempFolder = os.getcwd() + '/temp/'
        self.tempFolder = tempFolder.replace('\\', '/')
        try:
            os.makedirs(self.tempFolder)
        except:
            pass

        return True

    def get_dccs_path_to_exe(self):
        documentos_path = os.path.join(os.environ['USERPROFILE'], 'Documents')

        # Ruta a la carpeta 'kraken' dentro de Documentos
        kraken_folder_path = os.path.join(documentos_path, 'kraken', 'plugins')

        # Ruta al archivo JSON dentro de la carpeta 'kraken'
        json_file_path = os.path.join(kraken_folder_path, 'plugins_installation_paths.json')

        # Verificar si el archivo JSON existe
        if not os.path.exists(json_file_path):
            return

        # Leer los datos del archivo JSON
        with open(json_file_path, 'r') as file:
            installation_paths = json.load(file)

        for dcc in installation_paths:
            setattr(self, dcc, installation_paths[dcc])

    def dcc_is_activated(self, dcc):
        if dcc in self.connection_list:
            # print('preguntarle al manager si', dcc, 'está activo')
            return True
        else:
            return False



    def terminate_process_by_pid(self, pid):
        # print(f"Terminando proceso Kraken Manager con PID {pid}")
        if not self.mannager_is_connected:
            return
        intentos = 0
        while pid is None and intentos < 15:
            intentos += 1
            pid = self.pid_manager
            # print(f"Esperando a que el PID del proceso Kraken Manager sea diferente de None...")
            time.sleep(1)
        if pid:
            if os.name == 'nt':  # Verificar si es Windows
                subprocess.call(f"taskkill /F /PID {pid}", shell=True)
            else:  # Para sistemas Unix (Linux, macOS)
                os.kill(pid, signal.SIGTERM)
            # print(f"Proceso Kraken Manager con PID {pid} terminado.")
        else:
            print(f"No se encontró ningún proceso con el nombre Kraken Manager.")

    def init_queue(self):
        self.print_lock = threading.Lock()
        self.q = Queue()
        self.q_up = Queue()
        self.q_up_episode = None

        self.thread_amount = 50

