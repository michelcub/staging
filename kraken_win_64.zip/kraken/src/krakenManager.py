import websockets
import sys
import asyncio
import os

from src.kraken_manager.manager_connections import WebSocketServer

from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QTextBrowser, QSystemTrayIcon, QMenu, QAction
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QFile
from PyQt5.QtCore import QTimer
import sys

from threading import Thread



class KrakenManager(QMainWindow):
    def __init__(self):
        super().__init__()
        self.version = '4.11.0'
        self.initUI()
        self.server = WebSocketServer(manager=self)
        self.server.set_log_browser(self.log_browser)
        self.start_manager_server()

        if QSystemTrayIcon.isSystemTrayAvailable():
            self.setupTrayIcon()
        else:
            print("System tray no está disponible")

    def setupTrayIcon(self):
        # Añadir icono al system tray
        self.tray_icon = QSystemTrayIcon(self)
        icon_path = 'src/ui/images/Imago_Kraken_Manager.png'  # Asegúrate de que el ícono existe
        if not QFile.exists(icon_path):
            print(f"Ícono no encontrado en la ruta: {icon_path}")
            return
        self.tray_icon.setToolTip("Kraken Manager")
        self.tray_icon.setIcon(QIcon(icon_path))
        self.tray_icon.activated.connect(self.show)

        # Crear y añadir menú al ícono del system tray
        tray_menu = QMenu()
        show_action = QAction("Open", self)
        show_action.triggered.connect(self.show)
        tray_menu.addAction(show_action)

        exit_action = QAction("Close", self)
        exit_action.triggered.connect(sys.exit)
        tray_menu.addAction(exit_action)

        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()
        QTimer.singleShot(1000, lambda: self.tray_icon.showMessage("kraken Manager","Program running in the background, accessible from the system tray icon."))

    def close_app(self):
        self.tray_icon.hide()
        super().close()
        QApplication.instance().quit()

    def closeEvent(self, event):
        """Reimplementa el evento de cierre para minimizar al system tray."""
        event.ignore()
        self.hide()
        self.tray_icon.showMessage(
            "Kraken Manager",
            "Program running in the background, accessible from the system tray icon.",
            QSystemTrayIcon.Information,
            2000
        )

    def initUI(self):
        self.setWindowTitle('Kraken Manager')
        self.setGeometry(100, 100, 400, 200)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        # Establecer el ícono de la ventana principal
        self.setWindowIcon(QIcon(os.path.join(os.getcwd(), 'src/ui/images/Imago_Kraken_Manager.png').replace('\\', '/')))

        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        self.log_browser = QTextBrowser()
        layout.addWidget(self.log_browser)


    def start_manager_server(self):
        host = '127.0.0.1'
        port = 18765

        # Inicializar el servidor WebSocket en un hilo separado
        server_thread = Thread(target=self.run_server, args=(host, port))
        server_thread.daemon = True  # Establecer el hilo como daemon
        server_thread.start()  # Iniciar el hilo del servidor

        print(f"WebSocket server running in {host}:{port}")

    def run_server(self, host, port):
        # Configurar un nuevo bucle de eventos asyncio para el hilo actual
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            start_server = websockets.serve(self.server.on_connect, host, port)
            self.server.set_log_browser(self.log_browser)

            # Intenta iniciar el servidor y captura cualquier excepción aquí
            loop.run_until_complete(start_server)
            self.server.log_message("WebSocket server running.")
            loop.run_forever()

        except Exception as e:
            # Si ocurre un error aquí, es probablemente debido a la inicialización del servidor
            print("======================================")
            print(f"Error al iniciar el servidor WebSocket: {e}")
            print("======================================")
            self.close_app()

