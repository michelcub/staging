# -*- coding: utf-8 -*-

import os
import pickle

def termina_en_barra(path):
    if not path.endswith(("/", "\\")):
        path += "/"
    return path


def folder_file_list(folder_path):
    file_list = []

    for nombre in os.listdir(folder_path):
        ruta_completa = os.path.join(folder_path, nombre)

        if os.path.isfile(ruta_completa):
            file_list.append(nombre)
    return file_list


def save_to_disk(item, file_path):
    with open(file_path, 'wb') as file:
        pickle.dump(item, file)

def read_from_disk(file_path):
    with open(file_path, 'rb') as file:
        return pickle.load(file)


def remove_content_between_markers(file_path, start_marker="# _______________ PipelinePro Setup ___", end_marker="# _______________ end setting ___"):
    """
    Limpia la configuracion previa entre dos marcadores fijados
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.readlines()
        new_content = ''
        borrando = False
        for i, line in enumerate(content):
            if start_marker in line:
                borrando = True
            elif end_marker in line and borrando:
                borrando = False
            if not borrando:
                new_content = new_content + line

        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(new_content)
        print("Contenido reemplazado exitosamente.")

    except Exception as e:
        print(f"Ocurrió un error: {e}")