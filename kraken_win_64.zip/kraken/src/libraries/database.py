import sqlite3

class Sesion:
    def __init__(self, id, host, user, room, apikey, qm):
        self.id = id
        self.host = host
        self.user = user
        self.room = room
        self.apikey = apikey
        self.qm = qm
        self.orders = []
    def __str__(self):
        return self.user

    def create_order(self, type):
        self.qm.cursor.execute("INSERT INTO Orders(sesion_id, type) VALUES (?, ?)", (self.id, type,))
        self.qm.connection.commit()
        order_id = self.qm.cursor.lastrowid
        order = self.qm.get_order(order_id)
        self.add_order(order)


    def add_order(self, order):
        self.orders.append(order)
        return self

    def order_list(self):
        return self.orders
    
    def order_list(self):
        self.qm.cursor.execute("SELECT * FROM Orders WHERE sesion_id=?", (self.id,))
        order_data_list = self.qm.cursor.fetchall()
        order_list = []
        if order_data_list:
            for order_data in order_data_list:
                order = query_to_order(order_data)
                order_list.append(order)
            return order_list
        else:
            return None

    def next_order(self):
        order_list = self.order_list()
        if order_list:
            job_first = order_list[0]
            return job_first
        else:
            return None

    def last_order(self):
        order_list = self.order_list()
        if order_list:
            job_last = order_list[-1]
            return job_last
        else:
            return None


def query_to_sesion(qm, query):
    sesion = Sesion(query[0], query[1], query[2], query[3], query[4], qm)
    return sesion





class Order:
    def __init__(self, id, sesion_id, type, command, estado):
        self.id = id
        self.sesion_id = sesion_id
        self.type = type
        self.command = command
        self.estado = estado
    def __str__(self):
        return str(self.type) + ' ' + str(self.id)

def query_to_order(query):
    order = Order(query[0], query[1], query[2], query[3], query[4])
    return order
                
                


class QueueManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self.connection = sqlite3.connect(self.db_path)
        self.cursor = self.connection.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS Sesions (
                                id INTEGER PRIMARY KEY,
                                host TEXT,
                                user TEXT,
                                room TEXT,
                                apikey TEXT
                                )''')

        self.cursor.execute('''CREATE TABLE IF NOT EXISTS Orders (
                                id INTEGER PRIMARY KEY,
                                sesion_id INTEGER,
                                type TEXT,
                                command TEXT,
                                estado TEXT,
                                FOREIGN KEY (sesion_id) REFERENCES Sesions(id)
                                )''')

        self.connection.commit()

    def create_sesion(self, host, user):
        self.cursor.execute("INSERT INTO Sesions(host, user) VALUES (?, ?)", (host, user))
        self.connection.commit()
        sesion_id = self.cursor.lastrowid
        sesion = self.get_sesion(sesion_id)
        return sesion
    """
    def create_order(self, sesion_id, type):
        self.cursor.execute("INSERT INTO Orders(sesion_id, type) VALUES (?, ?)", (sesion_id, type,))
        self.connection.commit()
        order_id = self.cursor.lastrowid
        order = self.get_order(order_id)

        sesion = self.get_sesion(sesion_id)
        sesion.add_order(order)

        return order
    """



    def get_sesion(self, sesion_id):
        self.cursor.execute("SELECT * FROM Sesions WHERE id=?", (sesion_id,))
        sesion_data = self.cursor.fetchone()
        if sesion_data:
            return query_to_sesion(self, sesion_data)
        else:
            return None

    def get_order(self, order_id):
        self.cursor.execute("SELECT * FROM Orders WHERE id=?", (order_id,))
        order_data = self.cursor.fetchone()
        if order_data:
            return query_to_order(order_data)
        else:
            return None
    """
    def get_order_list(self, sesion_id):
        self.cursor.execute("SELECT * FROM Orders WHERE sesion_id=?", (sesion_id,))
        order_data_list = self.cursor.fetchall()
        order_list = []
        if order_data_list:
            for order_data in order_data_list:
                order = query_to_order(order_data)
                order_list.append(order)
            return order_list
        else:
            return None
    """



    def read_order(self, order_id):
        self.cursor.execute("SELECT * FROM Orders WHERE id=?", (order_id,))
        order_data = self.cursor.fetchone()
        return query_to_order(order_data)

    def read_all(self):
        self.cursor.execute("SELECT * FROM Orders")
        order_data_list = self.cursor.fetchall()
        order_list = []
        for order_data in order_data_list:
            order = query_to_order(order_data)
            order_list.append(order)
        return order_list

    def read_order_type(self, type):
        self.cursor.execute("SELECT * FROM Orders WHERE type LIKE ?", ('%' + type + '%',))
        order_data_list = self.cursor.fetchall()
        order_list = []
        for order_data in order_data_list:
            order = query_to_order(order_data)
            order_list.append(order)
        return order_list

    def update_record(self, order_id, new_order):
        self.cursor.execute("UPDATE Orders SET order=? WHERE id=?", (new_order, order_id))
        self.connection.commit()

    def delete_record(self, order_id):
        self.cursor.execute("DELETE FROM Orders WHERE id=?", (order_id,))
        self.connection.commit()

    def clear_database(self):
        self.cursor.execute("DELETE FROM Orders")
        self.connection.commit()

    def __del__(self):
        self.connection.close()



db_path = 'my_database.sqlite'
queue_manager = QueueManager(db_path)

sesion = queue_manager.create_sesion('https://pipelinepro.io', 'rodrigo.medinilla@gmail.com')
print(sesion)

order = sesion.create_order('Convert File 11')
order = sesion.create_order('Convert File 22')
order = sesion.create_order('Convert File 33')
order = sesion.create_order('Convert File 44')
"""
for data in range(0, 10000, 1):
    print(data)    
    order = sesion.create_order('Convert File ' + str(data))
print(sesion.order_list())
"""
print('---------')
for order in sesion.order_list():
    print(order)

job = sesion.next_order()

print(job)
print('==========')

# print(queue_manager.read_record(1))
#print(queue_manager.read_all())

#order_list = queue_manager.read_order_type('33')
#for order in order_list:
#    print(order)

# queue_manager.update_record(1, 'New data')

# queue_manager.delete_record(1)
