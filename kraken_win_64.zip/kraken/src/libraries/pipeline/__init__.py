import os
import pickle
import requests
import json


def hello_pipeline():
    return '    Hi, nice to meet you!!'


def transport_variable(key, value):
    globals()[key] = value


# kraken_folder = kraken_exec_folder()
# global pipe
# pipe = Pipe(kraken_folder)y

def esta_libreria_cargada(nombre_libreria):
    try:
        __import__(nombre_libreria)
        return True
    except ImportError:
        return False

def file_open():
    if esta_libreria_cargada('maya'):
        # print('es Maya')
        pass
    elif esta_libreria_cargada('bpy'):
        # print('es blender')
        import bpy
        ruta_completa = bpy.data.filepath
        file_name = os.path.basename(ruta_completa)
        return file_name




# def file(file_name):
def file():
    kraken_folder = kraken_exec_folder()
    pipe = Pipe(kraken_folder)
    # file = pipe.task(file_name)
    file = pipe.task(file_open())
    return file


def save_to_disk(item, file_path):
    with open(file_path, 'wb') as file:
        pickle.dump(item, file)

def read_from_disk(file_path):
    with open(file_path, 'rb') as file:
        return pickle.load(file)


def api_call(http_url, query, token, sesion):
    query = query.replace('{token}', token)
    # response = requests.post(http_url + '/graphql/', json={'query': query})
    response = sesion.post(http_url + '/graphql/', json={'query': query})
    return response.text


def kraken_exec_folder():
    ruta_absoluta = os.path.abspath(__file__)
    nivel_arriba_1 = os.path.dirname(ruta_absoluta)
    nivel_arriba_2 = os.path.dirname(nivel_arriba_1)
    nivel_arriba_3 = os.path.dirname(nivel_arriba_2)
    nivel_arriba_4 = os.path.dirname(nivel_arriba_3)
    nivel_arriba_5 = os.path.dirname(nivel_arriba_4)
    nivel_arriba_5 = nivel_arriba_5 + '/kraken/cache/'
    return nivel_arriba_5



class DictToObject:
    def __init__(self, diccionario):
        for clave, valor in diccionario.items():
            if isinstance(valor, dict):
                valor = DictToObject(valor)
            self.__setattr__(clave, valor)

class Pipe():
    def __init__(self, kraken_folder):
        # print('read_cache')
        self.token_auth = None
        self.read_cache(kraken_folder)
        self.sesion = requests.Session()

    def read_cache(self, kraken_folder):
        setting_token_auth = kraken_folder + 'token.dt'
        setting_url = kraken_folder + 'url.dt'
        # print(setting_token_auth)
        if os.path.exists(setting_token_auth):
            self.token_auth = read_from_disk(setting_token_auth)
            self.url = read_from_disk(setting_url)
            # print(self.token_auth)
            # print(self.url)

    def task(self, filename):
        if self.token_auth and self.url:
            query_folder = '''
                query {
                    file(token:"{token}",
                        fileName:"{filename}") {
                        fileName
                        fileExtension
                        folder {
                            code
                            folderLocal
                            version
                            review
                            wip
                            relTaskFolder {
                                name
                                maintask{name}
                                relAssetTask {
                                    tecnicalName
                                }
                                relShotTask {
                                    code
                                    name
                                }
                            }
                        }
                    }
                }
    
                '''
            query_folder = query_folder.replace('{filename}', filename)

            folder_response = api_call(self.url, query=query_folder, token=self.token_auth, sesion=self.sesion)
            folder_response = json.loads(folder_response)
            file_py = DictToObject(folder_response['data']['file'])

            return file_py
        else:
            print(' ====================== No access to API')



