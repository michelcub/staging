# ============== DCC on top

import ctypes
import psutil
from ctypes.wintypes import HWND, LPARAM, DWORD, BOOL

EnumWindows = ctypes.windll.user32.EnumWindows
EnumWindowsProc = ctypes.WINFUNCTYPE(BOOL, HWND, LPARAM)
GetWindowText = ctypes.windll.user32.GetWindowTextW
GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
IsWindowVisible = ctypes.windll.user32.IsWindowVisible
ShowWindow = ctypes.windll.user32.ShowWindow
GetWindowThreadProcessId = ctypes.windll.user32.GetWindowThreadProcessId
SetWindowPos = ctypes.windll.user32.SetWindowPos
SetForegroundWindow = ctypes.windll.user32.SetForegroundWindow



def foreach_window(hwnd, lParam):
    if IsWindowVisible(hwnd):
        length = GetWindowTextLength(hwnd)
        buff = ctypes.create_unicode_buffer(length + 1)
        GetWindowText(hwnd, buff, length + 1)
        title = buff.value
        if title:
            pid = DWORD()
            GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            process = psutil.Process(pid.value)
            executable = process.name()
            print(f"{executable} --- {title}")
    return True

def list_windows():
    EnumWindows(EnumWindowsProc(foreach_window), 0)




SW_RESTORE = 9
SW_SHOW = 5
SW_MAXIMIZE = 3
def create_callback(window_title):
    def foreach_window_foreground(hwnd, lParam):
        if IsWindowVisible(hwnd):
            length = GetWindowTextLength(hwnd)
            buff = ctypes.create_unicode_buffer(length + 1)
            GetWindowText(hwnd, buff, length + 1)
            title = buff.value
            if title:
                pid = DWORD()
                GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                process = psutil.Process(pid.value)
                executable = process.name()
                """
                Limitaciones:
                    1. Que solo haya un DCC
                    2. Que Hiero, Nuke y Nuke Studio son Nuke15.0.exe
                TODO: Hacer proceso desde WS
                """

                dcc = window_title
                if dcc in ['nuke', 'hiero', 'nuke s']:
                    dcc = 'Nuke'
                elif dcc in ['photoshop']:
                    dcc = 'Photoshop'
                # print(dcc + ' ---- ' + executable)

                if dcc in executable:
                    # print(dcc + ' ==== ' + executable)
                    ShowWindow(hwnd, SW_SHOW)
                    SetForegroundWindow(hwnd)
                    # print("=============================")
                    # print(f"{executable} --- {title}")
                    # print("=============================")
                    return False
        return True
    return foreach_window_foreground

def bring_to_front(window_title):
    #print(window_title)
    callback = create_callback(window_title)
    #print(callback)
    EnumWindows(EnumWindowsProc(callback), 0)