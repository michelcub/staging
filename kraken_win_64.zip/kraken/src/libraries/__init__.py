# -*- coding: utf-8 -*-
"""
author: Rodrigo Medinilla
company: PipelinePro Software S.L.
date: 2023/08/09
"""