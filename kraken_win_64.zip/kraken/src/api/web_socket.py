# -*- coding: utf-8 -*-
import threading

from PyQt5.QtCore import pyqtSignal

import json

import websocket
import time

import importlib
import src.operations.orders as orders


from src.operations.orders import order_class, check_conection



class WS_comunications():
    def __init__(self, url=None, userKey=None, apiKey=None, kraken=None):
        self.http_url = url

        if self.http_url:
            if 'http:' in self.http_url:
                self.ws_url = self.http_url.replace('http://', '')
            elif 'https:' in self.http_url:
                self.ws_url = self.http_url.replace('https://', '')
        self.userKey = userKey
        self.apiKey = apiKey
        self.conexion_activa = False
        self.kraken = kraken
        self.print_console_ws = self.kraken.print_console_ws
        self.kraken_manager_client = self.kraken.kraken_manager_client
        self.ws = None
        self.conected = False
        #---------Ejecucion en un hilo secundario
        threading.Thread(target=self.start_websocket_thread, daemon=True).start()


    def start_websocket_thread(self):
        #print('    > WS Connection url --------------------------', self.http_url)
        if 'http:' in self.http_url:
            protocol = 'ws://'
        else:
            protocol = 'wss://'

        # self.room = None
        # self.type = None

        if self.apiKey:
            self.room = self.apiKey
            self.type = 'krs'
            self.mode = 'prk'
            url = protocol + self.ws_url + '/ws/token/' + self.room + '/'
        else:
            # TODO: Ojo que el profile.userKey ahora es profile.room
            self.room = self.userKey
            self.type = 'kra'
            self.mode = 'use'
            url = protocol + self.ws_url + '/ws/user/' + self.room + '/'

        self.conexion_activa = True
        # try: # bucle de reconexion en el caso de caida o error
        self.ws = websocket.WebSocketApp(url,
                                    on_open=self.on_open,
                                    on_message=self.on_message,
                                    on_error=self.on_error,
                                    on_close=self.on_close)

        self.ws.run_forever()
    # except Exception as e:
    #     print("Error al intentar conectar:", e)
    #     self.reconnect()


    def close_connection(self):
        self.conexion_activa = False
        self.conected = False
        if self.ws:
            self.ws.close()


    def reconnect(self):
        if not self.conexion_activa:
            print("Connection closed intentionally, not attempting to reconnect.")
            return

        print("Attempting to reconnect...")
        self.print_console_ws.emit('    Attempting to reconnect...')
        time.sleep(5)  # Espera antes de intentar la reconexión
        self.start_websocket_thread()


    def on_message(self, ws, message):
        print('   WS - >>>>>>> IN')
        diccionario = json.loads(message)
        importlib.reload(orders)

        if 'order' in diccionario:
            #print("Mensaje recibido:", diccionario['message'])
            order_class(self.kraken, ws, diccionario)
        else:
            # print("Received message without 'order' key:", message)
            print("Received message without 'order'")

        if 'message' in diccionario:
            if isinstance(diccionario['message'], dict):
                message = diccionario['message']
                if 'order' in message:
                    order_class(self.kraken, ws, message)

    def on_error(self, ws, error):
        print("Error en WebSocket:", error)
        #self.reconnect()


    def on_close(self, ws, close_status_code, close_msg):
        print("WS closed")
        if self.conexion_activa:
            self.reconnect()
        else:
            print("Connection closed intentionally.")


    def on_open(self, ws): # esto ejecuta cuando se connecta
        self.print_console_ws.emit('    < WS Connection OK')
        print("Opened connection")
        check_conection(self)
        order_class(self, ws, {'order': 'register_kraken'})
        self.conected = True


    def send_message(self, message):
        if self.conexion_activa:
            self.ws.send(message)
            print(f"Sent: {message}")
        else:
            print("No se ha establecido una conexión WebSocket")