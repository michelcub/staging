# -*- coding: utf-8 -*-

import src.pipelinepro.settings as settings

import requests
import json


def loging(kraken, http_url):
    query_token = f'''
          mutation {{
            tokenAuth(username: "{kraken.username}", password: "{kraken.password}") {{
              token
            }}
          }}
        '''
    response = requests.post(http_url + '/graphql/', json={'query': query_token})
    response_token = response.text
    response_token = json.loads(response_token)
    token_auth = response_token['data']['tokenAuth']['token']
    return token_auth


def api_call(kraken, http_url, query, token=None):
    # token = kraken.token_auth
    if not token:
        token = loging(kraken, http_url)
    if token:
        query = query.replace('{token}', token)
    response = requests.post(http_url + '/graphql/', json={'query': query})
    return response.text

