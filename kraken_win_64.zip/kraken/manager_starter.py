# -*- coding: utf-8 -*-

"""
author: Rodrigo Medinilla
company: PipelinePro Software S.L.
date: 2023/08/09
"""

from PyQt5.QtWidgets import QApplication
import sys
import os


from src.krakenManager import KrakenManager

if __name__ == "__main__":



    app = QApplication(sys.argv)
    server_app = KrakenManager()
    #server_app.show()

    # Ejecuta la aplicación principal
    sys.exit(app.exec_())
